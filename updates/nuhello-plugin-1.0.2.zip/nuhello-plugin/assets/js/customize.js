/**
 * Chatbot Customization JavaScript
 * 
 * @package Nuhello_Plugin
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        const CustomizeManager = {
            init: function() {
                this.bindEvents();
                this.loadCurrentSettings();
            },

            bindEvents: function() {
                // Save settings button
                $('#save-settings').on('click', this.saveSettings.bind(this));
                
                // Refresh preview button
                $('#refresh-preview').on('click', this.refreshPreview.bind(this));
                
                // Color input updates
                $('input[type="color"]').on('change', this.updateColorValue.bind(this));
                
                // Real-time preview updates (optional)
                $('#chatbot-customize-form input, #chatbot-customize-form textarea, #chatbot-customize-form select').on('change', this.debounce(this.updatePreview.bind(this), 1000));
            },

            loadCurrentSettings: function() {
                // Settings are already loaded from PHP, but we can add any additional loading logic here
                console.log('Customize page loaded');
            },

            saveSettings: function(e) {
                e.preventDefault();
                
                const $button = $(e.target);
                const originalText = $button.html();
                
                // Show loading state
                $button.html('<i class="dashicons dashicons-update"></i> Saving...').prop('disabled', true);
                
                // Collect form data
                const formData = this.collectFormData();
                
                // Validate required fields
                if (!this.validateForm(formData)) {
                    this.showNotification('Please fill in all required fields.', 'error');
                    $button.html(originalText).prop('disabled', false);
                    return;
                }
                
                // Add nonce and action
                formData.nuhello_customize_nonce = $('#nuhello_customize_nonce').val();
                formData.action = 'nuhello_update_chatbot_settings';
                
                // Make AJAX request
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            CustomizeManager.showNotification(response.data.message, 'success');
                            CustomizeManager.refreshPreview();
                        } else {
                            CustomizeManager.showNotification(response.data.message || 'Failed to save settings.', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', error);
                        CustomizeManager.showNotification('An error occurred while saving settings.', 'error');
                    },
                    complete: function() {
                        $button.html(originalText).prop('disabled', false);
                    }
                });
            },


            refreshPreview: function() {
                const botId = $('#bot-id').val();
                if (botId) {
                    const iframe = document.getElementById('bot-preview');
                    if (iframe) {
                        // Force refresh by adding timestamp
                        const currentSrc = iframe.src.split('?')[0];
                        iframe.src = currentSrc + '?onLoadShowBot=true&botId=' + botId + '&t=' + Date.now();
                    }
                }
            },

            updatePreview: function() {
                // Optional: Update preview in real-time as user types
                // This could be implemented to show live preview changes
                console.log('Preview update triggered');
            },

            updateColorValue: function(e) {
                const colorInput = $(e.target);
                const colorValue = colorInput.siblings('.color-value');
                if (colorValue.length) {
                    colorValue.text(colorInput.val());
                }
            },

            collectFormData: function() {
                const formData = {};
                
                // Basic settings
                formData.displayName = $('#display-name').val();
                formData.initialMessage = $('#initial-message').val();
                formData.inputPlaceholderText = $('#input-placeholder').val();
                
                // Appearance
                formData.accentColor = $('#accent-color').val();
                formData.chatbotProfileImage = $('#chatbot-profile-image').val();
                formData.logoSize = $('#logo-size').val();
                formData.showLogoBorder = $('#show-logo-border').is(':checked');
                
                // Message colors
                formData.userMsgBgColor = $('#user-msg-bg-color').val();
                formData.aiMsgBgColor = $('#ai-msg-bg-color').val();
                formData.chatIconBgColor = $('#chat-icon-bg-color').val();
                
                // Chat icon & welcome
                formData.chatIcon = $('#chat-icon').val();
                formData.welcomeMsgFlag = $('#welcome-msg-flag').is(':checked');
                formData.welcomeMsg = $('#welcome-msg').val();
                
                // Quick replies & text
                formData.quickReplies = $('#quick-replies').val();
                formData.headerText = $('#header-text').val();
                formData.assistantText = $('#assistant-text').val();
                formData.linkLabel = $('#link-label').val();
                formData.toolTipLabel = $('#tooltip-label').val();
                
                // Feature toggles
                formData.allowEmailUs = $('#allow-email-us').is(':checked');
                formData.allowReportBug = $('#allow-report-bug').is(':checked');
                formData.allowChatWithUs = $('#allow-chat-with-us').is(':checked');
                formData.allowLeadForm = $('#allow-lead-form').is(':checked');
                formData.showTabBackground = $('#show-tab-background').is(':checked');
                
                // Advanced settings
                formData.aiMessageIcon = $('#ai-message-icon').val();
                formData.Visibility = $('#visibility').val();
                formData.limitTo = $('#limit-to').val();
                formData.everySeconds = parseInt($('#every-seconds').val());
                formData.limitMessage = $('#limit-message').val();
                formData.statusTitle = $('#status-title').val();
                formData.statusUrl = $('#status-url').val();
                
                return formData;
            },

            validateForm: function(formData) {
                // Basic validation
                if (!formData.displayName.trim()) {
                    this.showNotification('Bot name is required.', 'error');
                    return false;
                }
                
                if (!formData.initialMessage.trim()) {
                    this.showNotification('Welcome message is required.', 'error');
                    return false;
                }
                
                return true;
            },

            showNotification: function(message, type) {
                const notification = $('<div class="nuhello-notification nuhello-notification-' + type + '">' + message + '</div>');
                
                $('#nuhello-customize-notifications').append(notification);
                
                // Auto-remove after 5 seconds
                setTimeout(function() {
                    notification.fadeOut(function() {
                        $(this).remove();
                    });
                }, 5000);
            },

            debounce: function(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }
        };

        // Initialize the customize manager
        CustomizeManager.init();
    });

})(jQuery);
