(function($) {
    'use strict';

    $(document).ready(function() {
        const CustomizeCampaignManager = {
            campaignId: null,

            init: function() {
                const urlParams = new URLSearchParams(window.location.search);
                this.campaignId = urlParams.get('campaign_id');

                // Initialize Select2
                $('#segment-selection').select2({ placeholder: 'Select an option', width: '100%' });

                this.bindEvents();

                // Wait for segments to load before loading campaign details
                $.when(this.loadSegments()).done(() => {
                    if (this.campaignId) {
                        this.loadCampaignDetails();
                    } else {
                        // Handle case where there is no campaign_id
                        this.initializePreview();
                    }
                });
            },

            bindEvents: function() {
                $('#save-campaign-settings').on('click', this.saveCampaignSettings.bind(this));

                // Real-time preview updates
                $('#customize-campaign-form input, #customize-campaign-form textarea').on('input', this.debounce(this.updatePreview.bind(this), 500));

                // Logo preview
                $('#campaign-logo').on('input', this.updateLogoPreview.bind(this));

                // Launch Campaign Modal
                $('#launch-campaign-btn').on('click', this.openLaunchModal.bind(this));
                $('.close-modal-btn').on('click', this.closeLaunchModal.bind(this));
                $('.delivery-option').on('click', this.selectDeliveryMethod.bind(this));
                $('.collapsible-header').on('click', this.toggleCollapsible.bind(this));
                $('#confirm-launch-btn').on('click', this.confirmLaunch.bind(this));
            },

            loadSegments: function() {
                return $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'GET',
                    data: {
                        action: 'nuhello_get_segments',
                        nonce: nuhello_ajax.nonce
                    },
                    dataType: 'json',
                    success: (response) => {
                        if (response.segment_ids) {
                            const $select = $('#segment-selection');
                            $select.append(new Option('All Subscribers', 'all', false, false));
                            response.segment_ids.forEach(segment => {
                                $select.append(new Option(segment.label, segment.value, false, false));
                            });
                        }
                    }
                });
            },

            initializePreview: function() {
                this.updatePreview();
            },

            updatePreview: function() {
                const formData = this.collectFormData();
                this.renderCampaignPreview(formData);
            },

            collectFormData: function() {
                return {
                    title: $('#campaign-title').val(),
                    description: $('#campaign-description').val(),
                    url: $('#campaign-url').val(),
                    logo: $('#campaign-logo').val(),
                    button_title_1: $('#button-title-1').val(),
                    button_url_1: $('#button-url-1').val(),
                    button_title_2: $('#button-title-2').val(),
                    button_url_2: $('#button-url-2').val(),
                };
            },

            loadCampaignDetails: function() {
                $('#campaign-loading').show();

                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'GET',
                    data: {
                        action: 'nuhello_get_campaign_details',
                        nonce: nuhello_ajax.nonce,
                        campaign_id: this.campaignId
                    },
                    dataType: 'json',
                    success: (response) => {
                        if (response.success) {
                            this.populateForm(response.data);
                            this.updatePreview(); // Update preview with loaded data
                            this.updateLogoPreview(); // Update logo preview
                        } else {
                            this.showNotification(response.data.message || 'Failed to load campaign details.', 'error');
                        }
                    },
                    error: () => {
                        this.showNotification('An error occurred while fetching campaign details.', 'error');
                    },
                    complete: () => {
                        $('#campaign-loading').hide();
                        $('.campaign-config .content-row').css('height', 'auto');
                    }
                });
            },

            populateForm: function(campaign) {
                $('#campaign-name').val(campaign.name);
                $('#campaign-title').val(campaign.title);
                $('#campaign-description').val(campaign.description);
                $('#campaign-url').val(campaign.url);
                $('#campaign-logo').val(campaign.image);
                
                if (campaign.settings) {
                    $('#button-title-1').val(campaign.settings.button_title_1);
                    $('#button-url-1').val(campaign.settings.button_url_1);
                    $('#button-title-2').val(campaign.settings.button_title_2);
                    $('#button-url-2').val(campaign.settings.button_url_2);
                }

                // Set segment and subscribers
                if (campaign.segment) {
                    console.clear();
                    console.log('Segment:', campaign.segment);
                    $('#segment-selection').val(campaign.segment).trigger('change');
                }
            },

            updateLogoPreview: function() {
                const imageUrl = $('#campaign-logo').val();
                const $preview = $('#campaign-logo-preview img');
                const $placeholder = $('#campaign-logo-preview .image-placeholder');

                if (imageUrl) {
                    $preview.attr('src', imageUrl).show();
                    $placeholder.hide();
                } else {
                    $preview.hide();
                    $placeholder.show();
                }
            },

            saveCampaignSettings: function(e) {
                e.preventDefault();
                
                const $button = $(e.target);
                const originalText = $button.html();
                $button.html('<i class="dashicons dashicons-update"></i> Saving...').prop('disabled', true);

                const segment = $('#segment-selection').val();

                const formData = {
                    action: 'nuhello_update_campaign_dd',
                    nonce: nuhello_ajax.nonce,
                    campaign_id: this.campaignId,
                    name: $('#campaign-name').val(),
                    title: $('#campaign-title').val(),
                    description: $('#campaign-description').val(),
                    url: $('#campaign-url').val(),
                    segment: segment,
                    image: $('#campaign-logo').val(),
                    button_title_1: $('#button-title-1').val(),
                    button_url_1: $('#button-url-1').val(),
                    button_title_2: $('#button-title-2').val(),
                    button_url_2: $('#button-url-2').val()
                };

                // Prevent saving if campaignId is missing (new campaign)
                if (!this.campaignId) {
                    this.showNotification('Cannot save a new campaign from this page. Please create it from the Campaigns tab.', 'error');
                    $button.html(originalText).prop('disabled', false);
                    return;
                }

                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: (response) => {
                        if (response.success) {
                            this.showNotification('Campaign settings saved successfully!', 'success');
                        } else {
                            this.showNotification(response.data.message || 'Failed to save settings.', 'error');
                        }
                    },
                    error: () => {
                        this.showNotification('An error occurred while saving settings.', 'error');
                    },
                    complete: () => {
                        $button.html(originalText).prop('disabled', false);
                    }
                });
            },

            renderCampaignPreview: function(options) {
                const previewContainer = $('#campaign-widget-preview');
                const widgetHtml = this.createCampaignWidgetHTML(options);
                previewContainer.html(widgetHtml);
                this.applyCampaignWidgetStyles();
            },

            createCampaignWidgetHTML: function(options) {
                const title = options.title || 'Your Campaign Title';
                const description = options.description || 'This is a description of your campaign.';
                const url = options.url;
                const logo = options.logo;
                const buttonTitle1 = options.button_title_1;
                const buttonUrl1 = options.button_url_1;
                const buttonTitle2 = options.button_title_2;
                const buttonUrl2 = options.button_url_2;

                return `
                    <div class="campaign-preview-notice">
                        <div class="campaign-preview-content">
                            <div class="content-inner">
                                ${logo ? `<div class="campaign-logo"><img src="${logo}" alt="Logo" /></div>` : ''}
                                <div class="content">
                                    <h3 class="title">${title}</h3>
                                    <p class="description">
                                        ${description}
                                        ${url ? `<a href="${url}" target="_blank" rel="noopener noreferrer">Learn More</a>` : ''}
                                    </p>
                                    <div class="action-buttons">
                                        ${buttonTitle1 && buttonUrl1 ? `
                                            <a href="${buttonUrl1}" target="_blank" class="nuhello-btn nuhello-btn-primary">${buttonTitle1}</a>
                                        ` : ''}
                                        ${buttonTitle2 && buttonUrl2 ? `
                                            <a href="${buttonUrl2}" target="_blank" class="nuhello-btn nuhello-btn-secondary">${buttonTitle2}</a>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            },

            applyCampaignWidgetStyles: function() {
                if (!$('#campaign-widget-styles').length) {
                    const styles = `
                        <style id="campaign-widget-styles">
                            .campaign-preview-notice {
                                font-family: "Inter", sans-serif;
                                max-width: 415px;
                                width: 100%;
                                z-index: 1000;
                                position: relative;
                                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                                transition: all 0.3s;
                                background-color: #ffffff;
                                border-radius: 8px;
                                border: 1px solid #e2e8f0;
                            }
                            .campaign-logo { flex-shrink: 0; margin-right: 12px; }
                            .campaign-logo img { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
                            .campaign-preview-content { padding: 1rem; }
                            .content-inner { display: flex; align-items: flex-start; gap: 0.75rem; width: 100%; }
                            .content { min-width: 0; flex: 1; width: 100%; }
                            .title { margin-bottom: 0.5rem; margin-top: 0; font-size: 1rem; font-weight: 600; color: #1a202c; }
                            .description { margin-bottom: 1rem; margin-top: 0; font-size: 0.875rem; color: #4a5568; }
                            .description a { color: #3F215B; text-decoration: none; }
                            .description a:hover { text-decoration: underline; }
                            .action-buttons { display: flex; gap: 8px; margin-top: 12px; }
                        </style>
                    `;
                    $('head').append(styles);
                }
            },

            showNotification: function(message, type) {
                const notification = $('<div class="nuhello-notification nuhello-notification-' + type + '">' + message + '</div>');
                $('#nuhello-notification-notifications').append(notification);
                
                setTimeout(function() {
                    notification.fadeOut(function() {
                        $(this).remove();
                    });
                }, 5000);
            },

            debounce: function(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            },

            showError: function(message) {
                this.showNotification(message, 'error');
            },

            openLaunchModal: function() {
                console.log('Opening launch modal for campaign ID:', this.campaignId);
                // Populate modal with current form settings
                $('#modal-is-silent').prop('checked', $('#is-silent').is(':checked'));
                $('#modal-is-auto-hide').prop('checked', $('#is-auto-hide').is(':checked'));
                
                const ttlValue = $('#ttl').val();
                $('#modal-ttl').val(ttlValue);

                // Set timezone
                const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                $('#user-timezone').text(userTimezone);

                // Set default date and time
                const now = new Date();
                const year = now.getFullYear();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                const day = String(now.getDate()).padStart(2, '0');
                const hours = String(now.getHours()).padStart(2, '0');
                const minutes = String(now.getMinutes()).padStart(2, '0');
                
                $('#schedule-date').val(`${year}-${month}-${day}`);
                $('#schedule-time').val(`${hours}:${minutes}`);

                $('#launch-campaign-modal').show();
            },

            closeLaunchModal: function() {
                $('#launch-campaign-modal').hide();
            },

            selectDeliveryMethod: function(e) {
                const $target = $(e.currentTarget);
                const method = $target.data('method');

                $('.delivery-option').removeClass('active');
                $target.addClass('active');

                if (method === 'later') {
                    $('#schedule-delivery-section').slideDown();
                    $('#confirm-launch-btn span').text('Schedule Campaign');
                } else {
                    $('#schedule-delivery-section').slideUp();
                    $('#confirm-launch-btn span').text('Send Immediately');
                }
            },

            toggleCollapsible: function(e) {
                const $header = $(e.currentTarget);
                const $content = $header.next('.collapsible-content');
                $content.slideToggle();
                $header.find('.dashicons').toggleClass('dashicons-arrow-down-alt2 dashicons-arrow-up-alt2');
            },

            confirmLaunch: function(e) {
                const $button = $(e.currentTarget);
                const originalText = $button.find('span').text();
                $button.find('span').text('Processing...').prop('disabled', true);

                const deliveryMethod = $('.delivery-option.active').data('method');
                const isScheduled = deliveryMethod === 'later';
                
                let scheduledDateTime = null;
                if (deliveryMethod === 'later') {
                    const date = $('#schedule-date').val();
                    const time = $('#schedule-time').val();
                    if (date && time) {
                        scheduledDateTime = `${date} ${time}`;
                    } else {
                        this.showNotification('Please select a valid date and time for scheduling.', 'error');
                        $button.find('span').text(originalText).prop('disabled', false);
                        return;
                    }
                } else {
                    const now = new Date();
                    const year = now.getFullYear();
                    const month = String(now.getMonth() + 1).padStart(2, '0');
                    const day = String(now.getDate()).padStart(2, '0');
                    const hours = String(now.getHours()).padStart(2, '0');
                    const minutes = String(now.getMinutes()).padStart(2, '0');
                    scheduledDateTime = `${year}-${month}-${day} ${hours}:${minutes}`;
                }

                const launchData = {
                    action: 'nuhello_launch_campaign',
                    nonce: nuhello_ajax.nonce,
                    campaign_id: this.campaignId,
                    is_silent: $('#modal-is-silent').is(':checked'),
                    is_auto_hide: $('#modal-is-auto-hide').is(':checked'),
                    ttl: $('#modal-ttl').val(),
                    is_scheduled: true,
                    scheduled_datetime: scheduledDateTime,
                    user_timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
                };

                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'POST',
                    data: launchData,
                    dataType: 'json',
                    success: (response) => {
                        if (response.success) {
                            this.showNotification('Campaign launched successfully!', 'success');
                            this.closeLaunchModal();
                        } else {
                            this.showNotification(response.data.message || 'Failed to launch campaign.', 'error');
                        }
                    },
                    error: () => {
                        this.showNotification('An error occurred while launching the campaign.', 'error');
                    },
                    complete: () => {
                        $button.find('span').text(originalText).prop('disabled', false);
                    }
                });
            },
        };

        CustomizeCampaignManager.init();
    });

})(jQuery);
