<?php
/**
 * AJAX Handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Ajax_Handler extends Nuhello_Utils {
    
    public function __construct() {
        add_action('wp_ajax_nuhello_save_step', array($this, 'save_onboarding_step'));
        add_action('wp_ajax_nuhello_complete_onboarding', array($this, 'complete_onboarding'));
        add_action('wp_ajax_save_configuration', array($this, 'save_configuration'));
        add_action('wp_ajax_nuhello_get_chatbots', array($this, 'get_chatbots'));
        add_action('wp_ajax_nuhello_get_website_details_by_chatbot', array($this, 'get_website_details_by_chatbot'));
        add_action('wp_ajax_nuhello_get_seo_audit_by_chatbot', array($this, 'get_seo_audit_by_chatbot'));
        add_action('wp_ajax_nuhello_trigger_manual_seo_audit', array($this, 'trigger_manual_seo_audit_ajax'));
        add_action('wp_ajax_nuhello_get_template', array($this, 'get_template'));
        add_action('wp_ajax_nuhello_send_otp_reverify', array($this, 'send_otp_reverify'));
        add_action('wp_ajax_nuhello_re_verify_otp', array($this, 're_verify_otp_action'));
        add_action('wp_ajax_nuhello_get_analytics_by_chatbot', array($this, 'get_analytics_by_chatbot'));
        add_action('wp_ajax_nuhello_get_ticket_metrics', array($this, 'get_ticket_metrics_ajax'));
        add_action('wp_ajax_nuhello_get_message_desk_tickets', array($this, 'get_message_desk_tickets_ajax'));
        add_action('wp_ajax_nuhello_get_message_desk_ticket', array($this, 'get_message_desk_ticket_ajax'));
        add_action('wp_ajax_nuhello_get_message_desk_conversations', array($this, 'get_message_desk_conversations_ajax'));
        add_action('wp_ajax_nuhello_get_message_desk_conversation', array($this, 'get_message_desk_conversation_ajax'));
        add_action('wp_ajax_nuhello_get_message_desk_leads', array($this, 'get_message_desk_leads_ajax'));
        add_action('wp_ajax_nuhello_get_message_desk_lead', array($this, 'get_message_desk_lead_ajax'));
        add_action('wp_ajax_nuhello_send_message_desk_email', array($this, 'send_message_desk_email_ajax'));
        add_action('wp_ajax_nuhello_get_chat_settings_public', array($this, 'get_chat_settings_public_ajax'));
        add_action('wp_ajax_nuhello_get_upgrade_plans', array($this, 'get_upgrade_plans_ajax'));
        add_action('wp_ajax_nuhello_get_pricing_plans', array($this, 'get_pricing_plans_ajax'));
        add_action('wp_ajax_nuhello_send_onboarding_otp', array($this, 'send_onboarding_otp'));
        add_action('wp_ajax_nuhello_verify_onboarding_otp', array($this, 'verify_onboarding_otp'));
        add_action('wp_ajax_nuhello_validate_session', array($this, 'validate_session_ajax'));
        add_action('wp_ajax_nuhello_clear_registration', array($this, 'clear_registration'));
        add_action('wp_ajax_nuhello_reset_onboarding_progress', array($this, 'reset_onboarding_progress'));
        add_action('wp_ajax_nuhello_update_chatbot_settings', array($this, 'update_chatbot_settings'));
        add_action('wp_ajax_nuhello_update_notification_settings', array($this, 'handle_notification_settings_update'));
        add_action('wp_ajax_nuhello_get_subscriber_widget_settings', array($this, 'subscriber_widget_settings'));
        add_action('wp_ajax_nuhello_get_campaigns', array($this, 'get_campaigns'));
        add_action('wp_ajax_nuhello_create_campaign', array($this, 'handle_create_campaign'));
        add_action('wp_ajax_nuhello_get_campaign_details', array($this, 'campaign_details'));
        add_action('wp_ajax_nuhello_update_campaign_dd', array($this, 'update_campaign_details'));
        add_action('wp_ajax_nuhello_get_segments', array($this, 'get_segments'));
        add_action('wp_ajax_nuhello_launch_campaign', array($this, 'handle_launch_campaign'));
        add_action('wp_ajax_nuhello_check_wpn_file', array($this, 'nuhello_check_wpn_file_callback'));
        // Email verification actions
        add_action('wp_ajax_nuhello_verify_email', array($this, 'verify_email_ajax'));
        add_action('wp_ajax_nuhello_verify_email_bulk', array($this, 'verify_email_bulk_ajax'));
        add_action('wp_ajax_nuhello_verify_email_users_list', array($this, 'verify_email_users_list_ajax'));
        add_action('wp_ajax_nuhello_get_user_email_validation_status', array($this, 'get_user_email_validation_status_ajax'));
    }

    public function send_onboarding_otp() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        if (empty($_POST['email']) || !is_email($_POST['email'])) {
            wp_send_json_error(array('message' => 'Please provide a valid email address.'));
            return;
        }
        $email = sanitize_email($_POST['email']);
        $this->send_otp($email);
    }

    public function verify_onboarding_otp() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        if (empty($_POST['otp'])) {
            wp_send_json_error(array('message' => 'Please provide the OTP.'));
            return;
        }
        if (empty($_POST['email']) || !is_email($_POST['email'])) {
            wp_send_json_error(array('message' => 'Email is missing or invalid.'));
            return;
        }
        $email = sanitize_email($_POST['email']);
        $otp = sanitize_text_field($_POST['otp']);
        $this->verify_otp($email, $otp);
    }

    public function validate_session_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        if (empty($_POST['email']) || !is_email($_POST['email'])) {
            wp_send_json_error(array('message' => 'Email is missing or invalid.'));
            return;
        }
        if (empty($_POST['key'])) {
            wp_send_json_error(array('message' => 'Key is required.'));
            return;
        }
        $email = sanitize_email($_POST['email']);
        $key = sanitize_text_field($_POST['key']);
        $this->validate_session($email, $key);
    }

    public function clear_registration() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        delete_option('nuhello_registration_key');
        delete_option('nuhello_registration_email');
        delete_option('nuhello_registration_timestamp');
        wp_send_json_success(array('message' => 'Registration data cleared.'));
    }

    public function reset_onboarding_progress() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        update_option('nuhello_onboarding_completed', false);
        delete_option('nuhello_auth_token');
        delete_option('nuhello_otp_verified_time');
        delete_option('nuhello_website_details');
        delete_option('nuhello_current_website_url');
        delete_option('nuhello_pixel_key');
        delete_option('nuhello_chatbot_email');

        delete_option('nuhello_registration_key');
        delete_option('nuhello_registration_email');
        delete_option('nuhello_registration_timestamp');

        update_option('nuhello_environment', 'testing');
        delete_option('nuhello_testing_url');
        delete_option('nuhello_production_url');
        delete_option('nuhello_testing_default');
        delete_option('nuhello_production_default');
        update_option('nuhello_display_chatbot', true);
        update_option('nuhello_show_all_pages', true);
        update_option('nuhello_enable_analytics', true);
        update_option('nuhello_enable_notifications', true);

        wp_send_json_success(array('message' => 'Onboarding reset.'));
    }

    public function send_otp_reverify() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        $email = $this->get_user_email();
        if (empty($email)) {
            wp_send_json_error(array('message' => 'User email not found.'));
            return;
        }
        $this->send_otp($email);
    }

    public function re_verify_otp_action() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        $email = $this->get_user_email();
        if (empty($email)) {
            wp_send_json_error(array('message' => 'User email not found.'));
            return;
        }
        $otp = sanitize_text_field($_POST['otp']);
        $this->verify_otp($email, $otp, false);
    }

    /**
     * Save configuration settings via AJAX
     */
    public function save_configuration() {
        check_ajax_referer('nuhello_configuration_nonce', 'nuhello_config_nonce');

        $data = $_POST;
        $is_test_env = isset($data['is_test_env']) && $data['is_test_env'] === 'true';
        $production_url = !empty($data['production_url']) ? esc_url_raw($data['production_url']) : '';
        $test_url = '';

        if ($is_test_env) {
            $test_url = site_url();
        }

        $website_details = $this->get_saved_website_details();
        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }

        // Handle production URL update
        if (!empty($production_url) && $production_url !== get_option('nuhello_current_website_url')) {
            $otp_verified_time = get_option('nuhello_otp_verified_time', 0);
            if (time() - $otp_verified_time > 600) { // 10 minutes
                wp_send_json_error(array('message' => 'The time limit to update the production URL has expired. Please re-verify your email.'));
                return;
            }
            $parsed_url = parse_url($production_url);
            $scheme = $parsed_url['scheme'];
            $host = $parsed_url['host'];

            if (!in_array($scheme, array('http', 'https')) || empty($host)) {
                wp_send_json_error(array('message' => 'Please provide a valid production URL.'));
                return;
            }
        }

        $api_data = $this->save_website_configuration($data, $test_url);
        if ($api_data === null) {
            wp_send_json_error(array('message' => 'Failed to save website configuration.'));
            return;
        }

        // If API call is successful, update WordPress options
        if (!empty($api_data['website_details'])) {
            $this->update_website_details($api_data['website_details']);
        }
        $chat_settings = $this->get_chat_settings_public($chatbot_id);
        $email_setting = $chat_settings['payload']['emailSettings']['email'] ?? '';
        if (!empty($email_setting)) {
            update_option('nuhello_chatbot_email', sanitize_email($email_setting));
        } else {
            delete_option('nuhello_chatbot_email');
        }

        // Save email validation settings
        // Handle checkbox value - can be boolean true, string 'true', '1', or checked state
        $enable_email_validation = false;
        if (isset($data['enable_email_validation'])) {
            $value = $data['enable_email_validation'];
            $enable_email_validation = ($value === true || $value === 'true' || $value === '1' || $value === 1);
        }
        
        // Save allowed statuses (default: Valid only)
        $allowed_statuses = isset($data['email_validation_allowed_statuses']) && is_array($data['email_validation_allowed_statuses']) 
            ? array_map('sanitize_text_field', $data['email_validation_allowed_statuses'])
            : array('Valid');
        update_option('nuhello_email_validation_allowed_statuses', $allowed_statuses);
        
        // Save allowed safe to send values (default: yes only)
        $allowed_safe_to_send = isset($data['email_validation_allowed_safe_to_send']) && is_array($data['email_validation_allowed_safe_to_send']) 
            ? array_map('sanitize_text_field', $data['email_validation_allowed_safe_to_send'])
            : array('yes');
        update_option('nuhello_email_validation_allowed_safe_to_send', $allowed_safe_to_send);
        
        // Save blocked types (default: Free Account only)
        $blocked_types = isset($data['email_validation_blocked_types']) && is_array($data['email_validation_blocked_types']) 
            ? array_map(function($type) {
                // Convert '__empty__' back to empty string
                return $type === '__empty__' ? '' : sanitize_text_field($type);
            }, $data['email_validation_blocked_types'])
            : array('Free Account');
        update_option('nuhello_email_validation_blocked_types', $blocked_types);
        
        // Save custom error message
        $error_message = isset($data['email_validation_error_message']) ? sanitize_text_field($data['email_validation_error_message']) : '';
        update_option('nuhello_email_validation_error_message', $error_message);
        
        update_option('nuhello_enable_email_validation', $enable_email_validation);

        $website_details = $this->get_saved_website_details();

        wp_send_json_success(array(
            'message' => 'Configuration saved successfully!',
            'full_website_url' => $website_details['full_website_url'] ?? '',
            'testing_url' => $website_details['full_test_url'] ?? '',
            'display_chatbot' => $website_details['is_bot_enabled'] ?? false,
            'show_on_all_pages' => $website_details['bot_show_on_all_pages'] ?? false,
            'enable_analytics' => $website_details['is_analytics_enabled'] ?? false,
            'enable_notifications' => $website_details['is_push_notification_enabled'] ?? false,
                'enable_email_validation' => $enable_email_validation,
                'email_validation_allowed_statuses' => $allowed_statuses,
                'email_validation_allowed_safe_to_send' => $allowed_safe_to_send,
                'email_validation_blocked_types' => $blocked_types,
                'email_validation_error_message' => $error_message,
                'otp_verified_time' => get_option('nuhello_otp_verified_time', 0)
        ));
    }
    
    /**
     * Save onboarding step via AJAX
     */
    public function save_onboarding_step() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        
        $step = intval($_POST['step']);
        $data = $_POST['data'];
        
        switch ($step) {
            case 1:
                // This step is now handled by send_onboarding_otp and verify_onboarding_otp
                break;
            case 2:
                $otp_verified_time = get_option('nuhello_otp_verified_time', 0);
                if ($otp_verified_time === 0) {
                    wp_send_json_error(array('message' => 'Please validate the email first.'));
                    return;
                }

                if (!empty($data['chatbot_id'])) {
                    $chatbot_id = sanitize_text_field($data['chatbot_id']);
                    $api_data = $this->update_website_details(null, $chatbot_id);

                    // register_shutdown_function(array($this, 'update_opt_validation_time'));

                    wp_send_json_success(array(
                        'message' => 'Chatbot saved successfully.',
                        'display_chatbot'      => $api_data['is_bot_enabled'] ?? false,
                        'show_on_all_pages'    => $api_data['bot_show_on_all_pages'] ?? false,
                        'enable_analytics'     => $api_data['is_analytics_enabled'] ?? false,
                        'enable_notifications' => $api_data['is_push_notification_enabled'] ?? false,
                        'full_website_url'     => $api_data['full_website_url'] ?? '',
                        'wordpress_site_url'   => site_url(),
                        'otp_verified_time'    => $otp_verified_time,
                    ));
                    return;
                } else {
                    wp_send_json_error(array('message' => 'Please select a chatbot.'));
                    return;
                }

                break;
            case 3:
                $this->handle_step_5_environment($data);
                break;
            case 4:
                $website_details = $this->get_saved_website_details();
                if (empty($website_details)) {
                    wp_send_json_error(array('message' => 'Website details not found. Please complete step 4 first.'));
                    return;
                }

                $chatbot_id = $website_details['chatbot_id'] ?? null;

                $api_data = $this->save_website_features($chatbot_id, $data);
                if ($api_data === null) {
                    wp_send_json_error(array('message' => 'Failed to save website features.'));
                    return;
                }

                // If API call is successful, update WordPress options
                if (!empty($api_data['website_details'])) {
                    $this->update_website_details($api_data['website_details']);
                }

                break;
        }
        
        wp_send_json_success();
    }
    
    private function handle_step_5_environment($data) {
        $is_test_env = isset($data['is_test_env']) && $data['is_test_env'] === 'true';
        $production_url = !empty($data['production_url']) ? esc_url_raw($data['production_url']) : '';

        if ($is_test_env) {
            $testing_url = site_url();
            update_option('nuhello_test_environment', false);
            update_option('nuhello_testing_url', $testing_url);
        } else {
            // If it's not a test environment, we clear the testing URL settings
            delete_option('nuhello_testing_url');
            update_option('nuhello_test_environment', false);
        }

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found. Please complete step 4 first.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;
        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected. Please select a chatbot in step 4.'));
            return;
        }

        // Determine the URL to save to the API
        $test_url = '';
        $prod_url = '';
        if ($is_test_env) {
            $test_url = site_url(); // The WP site is the test env
        }
        
        if (!empty($production_url)) {
            $otp_verified_time = get_option('nuhello_otp_verified_time', 0);
            if (time() - $otp_verified_time > 600) { // 10 minutes
                wp_send_json_error(array('message' => 'The time limit to update the production URL has expired.'));
                return;
            }
            $prod_url = $production_url;
        }

        if (!empty($test_url) || !empty($prod_url)) {
            if ($this->save_website_test_url($chatbot_id, $test_url, $prod_url) === null) {
                wp_send_json_error(array('message' => 'Failed to save website URL to API.'));
                return;
            }
        }
        
        wp_send_json_success(array('message' => 'Environment settings saved.'));
    }

    /**
     * Complete onboarding via AJAX
     */
    public function complete_onboarding() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        
        // Check if this is a restart request
        if (isset($_POST['restart']) && $_POST['restart']) {
            update_option('nuhello_onboarding_completed', false);
            delete_option('nuhello_website_details');
            delete_option('nuhello_auth_token');
            delete_option('nuhello_chatbot_email');
            update_option('nuhello_environment', 'testing');
            delete_option('nuhello_testing_url');
            delete_option('nuhello_production_url');
            delete_option('nuhello_testing_default');
            delete_option('nuhello_production_default');
            update_option('nuhello_display_chatbot', true);
            update_option('nuhello_show_all_pages', true);
            update_option('nuhello_enable_analytics', true);
            update_option('nuhello_enable_notifications', true);
            
            wp_send_json_success();
        }
        
        update_option('nuhello_onboarding_completed', true);
        
        wp_send_json_success(array(
            'redirect_url' => admin_url('admin.php?page=nuhello-dashboard')
        ));
    }

    /**
     * Get chatbots for the current user
     */
    public function get_chatbots() {
        $chatbots = $this->get_user_chatbots();

        if (!empty($chatbots)) {
            wp_send_json_success(array('chatbots' => $chatbots));
            return;
        } else {
            wp_send_json_error(array('message' => 'No chatbots found for this user.'));
            return;
        }
    }

    /**
     * Get website details by chatbot ID
     */
    public function get_website_details_by_chatbot() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_POST['chatbot_id'])) {
            wp_send_json_error(array('message' => 'Chatbot ID is required.'));
            return;
        }

        $chatbot_id = sanitize_text_field($_POST['chatbot_id']);
        $website_details = $this->update_website_details(null, $chatbot_id, false);

        if ($website_details) {
            update_option('nuhello_current_website_url', $website_details['full_website_url']);
            wp_send_json_success(array(
                'full_website_url' => $website_details['full_website_url'] ?? '',
                'testing_url' => $website_details['full_test_url'] ?? '',
                'display_chatbot' => $website_details['is_bot_enabled'] ?? false,
                'show_on_all_pages' => $website_details['bot_show_on_all_pages'] ?? false,
                'enable_analytics' => $website_details['is_analytics_enabled'] ?? false,
                'enable_notifications' => $website_details['is_push_notification_enabled'] ?? false,
                'enable_email_validation' => get_option('nuhello_enable_email_validation', false),
                'email_validation_allowed_statuses' => get_option('nuhello_email_validation_allowed_statuses', array('Valid')),
                'email_validation_allowed_safe_to_send' => get_option('nuhello_email_validation_allowed_safe_to_send', array('yes')),
                'email_validation_blocked_types' => get_option('nuhello_email_validation_blocked_types', array('Free Account')),
                'email_validation_error_message' => get_option('nuhello_email_validation_error_message', ''),
                'website_id' => $website_details['website_id'] ?? false,
                'pixel_key' => $website_details['pixel_key'] ?? false
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch website details.'));
        }
    }

    /**
     * Get SEO audit by chatbot ID
     */
    public function get_seo_audit_by_chatbot() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }
        $seo_audit = $this->get_seo_audit($chatbot_id);

        if ($seo_audit) {
            wp_send_json_success($seo_audit);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch SEO audit details.'));
        }
    }

    /**
     * Trigger manual SEO audit by chatbot ID
     */
    public function trigger_manual_seo_audit_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        $org_id = $website_details['organization_id'] ?? '';
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;
        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }

        if (empty($org_id)) {
            wp_send_json_error(array('message' => 'Organization ID not found.'));
            return;
        }

        $response = $this->trigger_manual_seo_audit($chatbot_id, $org_id);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to trigger SEO audit.'));
        }
    }

    /**
     * Get template content via AJAX
     */
    public function get_template() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_GET['template'])) {
            wp_send_json_error('Template name not provided.', 400);
        }

        $template_name = sanitize_file_name($_GET['template']);
        $template_path = NUHELLO_PLUGIN_PATH . 'admin/views/templates/' . $template_name . '.php';

        if (file_exists($template_path)) {
            ob_start();
            include $template_path;
            $content = ob_get_clean();
            wp_send_json_success($content);
        } else {
            wp_send_json_error('Template not found.', 404);
        }
    }

    public function get_analytics_by_chatbot() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }

        $analytics_data = $this->get_analytics_data($chatbot_id);

        $page_view_data = $this->get_page_views_bounce_rate($chatbot_id);

        $response = $analytics_data;

        if ($page_view_data) {
            $response = array_merge($analytics_data, $page_view_data);
        }

        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch analytics data.'));
        }
    }

    /**
     * Get ticket metrics via AJAX
     */
    public function get_ticket_metrics_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;
        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }

        $response = $this->get_home_analytics_tickets($chatbot_id);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch ticket metrics.'));
        }
    }

    /**
     * Get Message Desk tickets via AJAX
     */
    public function get_message_desk_tickets_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;
        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }

        $take = isset($_GET['take']) ? intval($_GET['take']) : 10;
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

        $response = $this->get_message_desk_tickets($chatbot_id, $take, $page, $search);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch message desk tickets.'));
        }
    }

    /**
     * Get a single Message Desk ticket via AJAX
     */
    public function get_message_desk_ticket_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_GET['ticket_id'])) {
            wp_send_json_error(array('message' => 'Ticket ID is required.'));
            return;
        }

        $ticket_id = sanitize_text_field($_GET['ticket_id']);
        $response = $this->get_message_desk_ticket($ticket_id);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch message desk ticket.'));
        }
    }

    /**
     * Get Message Desk conversations via AJAX
     */
    public function get_message_desk_conversations_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;
        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }

        $take = isset($_GET['take']) ? intval($_GET['take']) : 10;
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

        $response = $this->get_message_desk_conversations($chatbot_id, $take, $page, $search);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch message desk conversations.'));
        }
    }

    /**
     * Get a single Message Desk conversation via AJAX
     */
    public function get_message_desk_conversation_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_GET['conversation_id'])) {
            wp_send_json_error(array('message' => 'Conversation ID is required.'));
            return;
        }

        $conversation_id = sanitize_text_field($_GET['conversation_id']);
        $response = $this->get_message_desk_conversation($conversation_id, 'agent');
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch message desk conversation.'));
        }
    }

    /**
     * Get Message Desk leads via AJAX
     */
    public function get_message_desk_leads_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;
        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }

        $take = isset($_GET['take']) ? intval($_GET['take']) : 10;
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

        $response = $this->get_message_desk_leads($chatbot_id, $take, $page, $search);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch message desk leads.'));
        }
    }

    /**
     * Get a single Message Desk lead via AJAX
     */
    public function get_message_desk_lead_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_GET['lead_id'])) {
            wp_send_json_error(array('message' => 'Lead ID is required.'));
            return;
        }

        $lead_id = sanitize_text_field($_GET['lead_id']);
        $response = $this->get_message_desk_lead($lead_id);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch message desk lead.'));
        }
    }

    /**
     * Send a Message Desk email reply via AJAX
     */
    public function send_message_desk_email_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $ticket_id = isset($_POST['ticket_id']) ? sanitize_text_field($_POST['ticket_id']) : '';
        $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
        $content = isset($_POST['content']) ? wp_kses_post($_POST['content']) : '';
        $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'SUPPORT';
        $reply_to = isset($_POST['replyTo']) ? sanitize_text_field($_POST['replyTo']) : '';
        $channel_raw = isset($_POST['channel']) ? wp_unslash($_POST['channel']) : '';

        if (empty($ticket_id) || empty($email) || empty($title) || empty($content)) {
            wp_send_json_error(array('message' => 'Ticket, email, subject and content are required.'));
            return;
        }

        $channel = array('EMAIL');
        if (!empty($channel_raw)) {
            $decoded = json_decode($channel_raw, true);
            if (is_array($decoded) && !empty($decoded)) {
                $channel = array_map('sanitize_text_field', $decoded);
            }
        }

        $payload = array(
            'ticket_id' => $ticket_id,
            'email'     => $email,
            'title'     => $title,
            'content'   => $content,
            'channel'   => $channel,
            'type'      => $type,
            'replyTo'   => $reply_to
        );

        $response = $this->send_message_desk_email($payload);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to send message desk email.'));
        }
    }

    /**
     * Get public chat settings (email settings)
     */
    public function get_chat_settings_public_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;
        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected.'));
            return;
        }

        $response = $this->get_chat_settings_public($chatbot_id);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch chat settings.'));
        }
    }

    /**
     * Get possible upgrade plans via AJAX
     */
    public function get_upgrade_plans_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $user_data = get_option('nuhello_user', array());
        $current_user_id = $user_data['id'] ?? $user_data['_id'] ?? $user_data['userId'] ?? '';

        if (empty($current_user_id)) {
            wp_send_json_error(array('message' => 'User ID not found. Please complete onboarding first.'));
            return;
        }

        $response = $this->get_upgrade_plans($current_user_id);
        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch upgrade plans.'));
        }
    }

    /**
     * Get pricing plans via AJAX
     */
    public function get_pricing_plans_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $take = isset($_GET['take']) ? max(1, intval($_GET['take'])) : 100;

        $response = $this->get_pricing_plans(array(
            'page' => $page,
            'take' => $take
        ));

        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch pricing plans.'));
        }
    }

    /**
     * Verify single email via Flask API
     */
    public function verify_email_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_POST['email']) || !is_email($_POST['email'])) {
            wp_send_json_error(array('message' => 'Please provide a valid email address.'));
            return;
        }

        $email = sanitize_email($_POST['email']);
        $result = $this->verify_email_api($email);

        if ($result === null) {
            // verify_email_api already sent an error via _make_api_request -> wp_send_json_error
            return;
        }

        wp_send_json_success($result);
    }

    /**
     * Verify bulk emails via Flask API
     */
    public function verify_email_bulk_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $emails = array();
        if (isset($_POST['emails'])) {
            if (is_array($_POST['emails'])) {
                $emails = $_POST['emails'];
            } else {
                // try JSON decode or comma/newline separated
                $raw = trim($_POST['emails']);
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $emails = $decoded;
                } else {
                    $emails = preg_split('/[\r\n,]+/', $raw);
                }
            }
        }

        $sanitized = array();
        foreach ($emails as $e) {
            $e = sanitize_email(trim($e));
            if (!empty($e) && is_email($e)) {
                $sanitized[] = $e;
            }
        }

        if (empty($sanitized)) {
            wp_send_json_error(array('message' => 'Please provide at least one valid email address.'));
            return;
        }

        if (count($sanitized) > 100) {
            wp_send_json_error(array('message' => 'Maximum 100 emails allowed in bulk verification.'));
            return;
        }

        $result = $this->verify_email_bulk_api($sanitized);

        if ($result === null) {
            return;
        }

        wp_send_json_success($result);
    }

    /**
     * Verify email for users list (returns formatted result for popup)
     */
    public function verify_email_users_list_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_POST['email']) || !is_email($_POST['email'])) {
            wp_send_json_error(array('message' => 'Please provide a valid email address.'));
            return;
        }

        $email = sanitize_email($_POST['email']);
        $result = $this->verify_email_api($email);

        if ($result === null) {
            wp_send_json_error(array('message' => 'Failed to verify email. Please try again.'));
            return;
        }

        // Format the result for display
        $formatted_result = $this->format_email_verification_result($result, $email);

        // Store status against user if email matches a user account
        $user = get_user_by('email', $email);
        if ($user && !empty($formatted_result['status'])) {
            update_user_meta($user->ID, 'nuhello_email_validation_status', sanitize_text_field($formatted_result['status']));
        }
        wp_send_json_success($formatted_result);
    }

    /**
     * Get or refresh email validation status for a user
     */
    public function get_user_email_validation_status_ajax() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (!current_user_can('list_users')) {
            wp_send_json_error(array('message' => 'You do not have permission to view users.'));
            return;
        }

        $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
        if (!$user_id) {
            wp_send_json_error(array('message' => 'Invalid user ID.'));
            return;
        }

        $user = get_user_by('id', $user_id);
        if (!$user || empty($user->user_email)) {
            wp_send_json_error(array('message' => 'User not found or missing email.'));
            return;
        }

        $status = get_user_meta($user_id, 'nuhello_email_validation_status', true);

        if (empty($status) || $status === 'Unknown') {
            $result = $this->verify_email_api($user->user_email);
            if ($result === null) {
                wp_send_json_success(array('status' => 'Unknown'));
                return;
            }

            $formatted_result = $this->format_email_verification_result($result, $user->user_email);
            $status = $formatted_result['status'] ?? 'Unknown';
            if (!empty($status)) {
                update_user_meta($user_id, 'nuhello_email_validation_status', sanitize_text_field($status));
            }
        }

        wp_send_json_success(array('status' => $status ?: 'Unknown'));
    }
    
    /**
     * Format email verification result for display (users list modal)
     * Returns only status and safe to send as requested
     */
    private function format_email_verification_result($result, $email) {
        $status = 'Unknown';
        $safetosend = 'Unknown';
        
        if (isset($result['data']) && is_array($result['data']) && !empty($result['data'])) {
            $first_result = $result['data'][0];
            
            if (isset($first_result['response'])) {
                $response = $first_result['response'];
                $status = isset($response['status']) ? $response['status'] : 'Unknown';
                $safetosend_raw = isset($response['safetosend']) ? $response['safetosend'] : 'Unknown';
                
                // Normalize safetosend for display: "Yes"/"yes" -> "Yes", "No"/"no" -> "Risky"
                $safetosend_lower = strtolower($safetosend_raw);
                if ($safetosend_lower === 'no') {
                    $safetosend = 'Risky';
                } elseif ($safetosend_lower === 'yes') {
                    $safetosend = 'Yes';
                } else {
                    $safetosend = $safetosend_raw;
                }
            }
        }
        
        return array(
            'email' => $email,
            'status' => $status,
            'safetosend' => $safetosend
        );
    }

    /**
     * Update chatbot settings via AJAX
     */
    public function update_chatbot_settings() {
        check_ajax_referer('nuhello_customize_nonce', 'nuhello_customize_nonce');

        $website_details = $this->get_saved_website_details();
        
        if (empty($website_details)) {
            wp_send_json_error(array('message' => 'Website details not found. Please complete onboarding first.'));
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;
        $auth_token = get_option('nuhello_auth_token', '');
        $org_id = $website_details['organization_id'] ?? '';

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not selected. Please select a chatbot first.'));
            return;
        }

        if (empty($auth_token)) {
            wp_send_json_error(array('message' => 'Authentication token not found. Please complete onboarding first.'));
            return;
        }

        if (empty($org_id)) {
            wp_send_json_error(array('message' => 'Organization ID not found. Please complete onboarding first.'));
            return;
        }

        // Prepare the data for the API call
        $data = array(
            'displayName' => sanitize_text_field($_POST['displayName'] ?? ''),
            'initialMessage' => sanitize_textarea_field($_POST['initialMessage'] ?? ''),
            'inputPlaceholderText' => sanitize_text_field($_POST['inputPlaceholderText'] ?? ''),
            'accentColor' => sanitize_hex_color($_POST['accentColor'] ?? '#50bc39'),
            'chatbotProfileImage' => esc_url_raw($_POST['chatbotProfileImage'] ?? ''),
            'logoSize' => sanitize_text_field($_POST['logoSize'] ?? 'small'),
            'showLogoBorder' => isset($_POST['showLogoBorder']) ? (bool) $_POST['showLogoBorder'] : true,
            'userMsgBgColor' => sanitize_hex_color($_POST['userMsgBgColor'] ?? '#1d1526'),
            'aiMsgBgColor' => sanitize_hex_color($_POST['aiMsgBgColor'] ?? '#d6e0d5'),
            'chatIconBgColor' => sanitize_hex_color($_POST['chatIconBgColor'] ?? '#8e8794'),
            'chatIcon' => esc_url_raw($_POST['chatIcon'] ?? ''),
            'welcomeMsgFlag' => isset($_POST['welcomeMsgFlag']) ? (bool) $_POST['welcomeMsgFlag'] : true,
            'welcomeMsg' => sanitize_textarea_field($_POST['welcomeMsg'] ?? ''),
            'quickReplies' => array_map('trim', explode(',', sanitize_text_field($_POST['quickReplies'] ?? ''))),
            'headerText' => sanitize_text_field($_POST['headerText'] ?? ''),
            'assistantText' => sanitize_text_field($_POST['assistantText'] ?? ''),
            'linkLabel' => sanitize_text_field($_POST['linkLabel'] ?? ''),
            'toolTipLabel' => sanitize_text_field($_POST['toolTipLabel'] ?? ''),
            'allowEmailUs' => isset($_POST['allowEmailUs']) ? (bool) $_POST['allowEmailUs'] : true,
            'allowReportBug' => isset($_POST['allowReportBug']) ? (bool) $_POST['allowReportBug'] : false,
            'allowChatWithUs' => isset($_POST['allowChatWithUs']) ? (bool) $_POST['allowChatWithUs'] : true,
            'allowLeadForm' => isset($_POST['allowLeadForm']) ? (bool) $_POST['allowLeadForm'] : true,
            'showTabBackground' => isset($_POST['showTabBackground']) ? (bool) $_POST['showTabBackground'] : false,
            'aiMessageIcon' => sanitize_text_field($_POST['aiMessageIcon'] ?? 'ai-icon.png'),
            'Visibility' => sanitize_text_field($_POST['Visibility'] ?? 'public'),
            'limitTo' => sanitize_text_field($_POST['limitTo'] ?? 'internal'),
            'everySeconds' => intval($_POST['everySeconds'] ?? 60),
            'limitMessage' => sanitize_text_field($_POST['limitMessage'] ?? 'You have reached your usage limit.'),
            'statusTitle' => sanitize_text_field($_POST['statusTitle'] ?? 'System Status'),
            'statusUrl' => esc_url_raw($_POST['statusUrl'] ?? '')
        );

        // Make API call to update chatbot settings
        $api_url = NUHELLO_AUTH_API_URL . '/api/v1/chatbot/wordpress-plugin/chat-settings/' . $chatbot_id;
        
        $response = wp_remote_request($api_url, array(
            'method' => 'PUT',
            'headers' => array(
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $auth_token,
                'x-organization-id' => $org_id
            ),
            'body' => json_encode($data),
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Failed to connect to API: ' . $response->get_error_message()));
            return;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        if ($response_code === 200) {
            // Save settings locally for future reference
            update_option('nuhello_chatbot_settings', $data);
            
            wp_send_json_success(array(
                'message' => 'Chatbot settings updated successfully!',
                'settings' => $data
            ));
        } else {
            $error_data = json_decode($response_body, true);
            $error_message = $error_data['message'] ?? 'Failed to update chatbot settings.';
            wp_send_json_error(array('message' => $error_message));
        }
    }

    /**
     * Handle notification settings update
     */
    public function handle_notification_settings_update() {
        // Verify nonce
        if (!isset($_POST['nuhello_notification_nonce']) || !wp_verify_nonce($_POST['nuhello_notification_nonce'], 'nuhello_notification_nonce')) {
            wp_send_json_error(array('message' => 'Nonce verification failed.'));
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
        }

        $website_details = $this->get_saved_website_details();
        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(['message' => 'Chatbot ID not found.']);
            return;
        }

        // Sanitize and collect form data
        $data = array(
            'title' => sanitize_text_field($_POST['title']),
            'description' => sanitize_textarea_field($_POST['description']),
            'learnMoreUrl' => esc_url_raw($_POST['learnMoreUrl']),
            'backgroundColor' => sanitize_hex_color($_POST['backgroundColor']),
            'accentColor' => sanitize_hex_color($_POST['accentColor']),
            'titleColor' => sanitize_hex_color($_POST['titleColor']),
            'textColor' => sanitize_hex_color($_POST['textColor']),
            'position' => sanitize_text_field($_POST['position']),
            'layout' => sanitize_text_field($_POST['layout']),
            'showIcon' => isset($_POST['showIcon']) ? (bool) $_POST['showIcon'] : false,
            'notificationIcon' => esc_url_raw($_POST['notificationIcon']),
            'acceptButtonText' => sanitize_text_field($_POST['acceptButtonText']),
            'rejectButtonText' => sanitize_text_field($_POST['rejectButtonText'])
        );

        // Call the utility function to update the settings
        $response = $this->update_subscriber_widget_settings($chatbot_id, $data);

        if ($response && isset($response['message']) && $response['message']) {
            wp_send_json_success(array('message' => $response['message']));
        } else {
            wp_send_json_error(array('message' => 'Failed to save settings.', 'details' => $response));
        }
    }

    public function subscriber_widget_settings() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        if (empty($website_details)) {
            wp_send_json_error(['message' => 'Website details not found.']);
            return;
        }

        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(['message' => 'Chatbot ID not found.']);
            return;
        }

        $settings = $this->get_subscriber_widget_settings($chatbot_id);

        if ($settings) {
            wp_send_json_success($settings);
        } else {
            wp_send_json_error(['message' => 'Failed to get subscriber widget settings.']);
        }
    }

    public function get_campaigns() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not configured.'));
        }

        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $page_size = isset($_GET['page_size']) ? intval($_GET['page_size']) : 10;

        $campaigns_data = $this->get_campaigns_by_chatbot_id($chatbot_id, $page, $page_size);

        if ($campaigns_data) {
            wp_send_json_success($campaigns_data);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch campaigns.'));
        }
    }

    public function handle_create_campaign() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_details = $this->get_saved_website_details();
        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not configured.'));
        }

        $campaign_name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';

        if (empty($campaign_name)) {
            wp_send_json_error(array('message' => 'Campaign name is required.'));
        }

        $data = array(
            'name' => $campaign_name,
            'title' => 'Your Campaign Title',
            'description' => 'Your campaign description goes here',
            'url' => 'https://example.com',
            'segment' => 'all',
            'settings' => array(
                'is_silent' => false,
                'is_auto_hide' => false,
                'ttl' => 86400,
                'is_scheduled' => false
            )
        );

        $response = $this->create_campaign($chatbot_id, $data);

        if ($response && !empty($response['campaign_id'])) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to create campaign.'));
        }
    }

    public function campaign_details() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_GET['campaign_id'])) {
            wp_send_json_error(array('message' => 'Campaign ID is required.'));
        }

        $website_details = $this->get_saved_website_details();
        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not configured.'));
        }

        $campaign_id = sanitize_text_field($_GET['campaign_id']);
        $campaign_details = $this->get_campaign_details($chatbot_id, $campaign_id);

        update_option('nuhello_campaign_details', $campaign_details);

        if ($campaign_details) {
            wp_send_json_success($campaign_details);
        } else {
            wp_send_json_error(array('message' => 'Failed to fetch campaign details.'));
        }
    }

    public function update_campaign_details() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_POST['campaign_id'])) {
            wp_send_json_error(array('message' => 'Campaign ID is required.'));
        }

        $website_details = $this->get_saved_website_details();
        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not configured.'));
        }

        $campaign_details = get_option('nuhello_campaign_details', array());
        if ($campaign_details['_id'] == $_POST['campaign_id'] && empty($_POST['segment']) && $campaign_details['segment'] == 'custom' ) {
            $_POST['segment'] = 'custom';
            $_POST['subscribers_ids'] = $campaign_details['subscribers_ids'] ?? array();
        }

        $data = array(
            'campaign_id' => sanitize_text_field($_POST['campaign_id']),
            'name' => sanitize_text_field($_POST['name']),
            'title' => sanitize_text_field($_POST['title']),
            'description' => sanitize_textarea_field($_POST['description']),
            'image_url' => esc_url_raw($_POST['image']),
            'url' => esc_url_raw($_POST['url']),
            'segment' => sanitize_text_field($_POST['segment']),
            'subscribers_ids' => isset($_POST['subscribers_ids']) ? $_POST['subscribers_ids'] : array(),
            'button_title_1' => sanitize_text_field($_POST['button_title_1']),
            'button_url_1' => esc_url_raw($_POST['button_url_1']),
            'button_title_2' => sanitize_text_field($_POST['button_title_2']),
            'button_url_2' => esc_url_raw($_POST['button_url_2'])
        );

        $response = $this->update_campaign($chatbot_id, $data);

        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to update campaign.'));
        }
    }

    public function get_segments() {
        check_ajax_referer('nuhello_nonce', 'nonce');
        
        $website_details = $this->get_saved_website_details();
        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not configured.'));
        }
        $response = $this->get_all_segment_ids($chatbot_id);
        
        wp_send_json($response);
    }

    public function handle_launch_campaign() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        if (empty($_POST['campaign_id'])) {
            wp_send_json_error(array('message' => 'Campaign ID is required.'));
        }

        $website_details = $this->get_saved_website_details();
        $chatbot_id = $website_details['chatbot_id'] ?? null;

        if (!$chatbot_id) {
            wp_send_json_error(array('message' => 'Chatbot not configured.'));
        }

        $campaign_id = sanitize_text_field($_POST['campaign_id']);

        $data = array(
            'is_silent' => isset($_POST['is_silent']) ? rest_sanitize_boolean($_POST['is_silent']) : false,
            'is_auto_hide' => isset($_POST['is_auto_hide']) ? rest_sanitize_boolean($_POST['is_auto_hide']) : false,
            'ttl' => isset($_POST['ttl']) ? intval($_POST['ttl']) : 86400,
            'is_scheduled' => isset($_POST['is_scheduled']) ? rest_sanitize_boolean($_POST['is_scheduled']) : false,
            'scheduled_datetime' => isset($_POST['scheduled_datetime']) ? sanitize_text_field($_POST['scheduled_datetime']) : null,
            'user_timezone' => isset($_POST['user_timezone']) ? sanitize_text_field($_POST['user_timezone']) : null,
        );

        $response = $this->launch_campaign($chatbot_id, $campaign_id, $data);

        if ($response) {
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => 'Failed to launch campaign.'));
        }
    }

    function nuhello_check_wpn_file_callback() {
        check_ajax_referer('nuhello_nonce', 'nonce');

        $website_id = isset($_POST['website_id']) ? sanitize_text_field($_POST['website_id']) : '';
        $pixel_key = isset($_POST['pixel_key']) ? sanitize_text_field($_POST['pixel_key']) : '';

        $root_path = ABSPATH . 'nuhello_wpn.js';
        $need_download = true;
        $reason = 'Push notification will not work until you place <b>nuhello_wpn.js</b> in the root folder.';

        if (file_exists($root_path)) {
            $file_content = file_get_contents($root_path);
            $id_match = preg_match("/let\\s+website_id\\s*=\\s*'([^']+)'/", $file_content, $id_matches);
            $key_match = preg_match("/let\\s+website_pixel_key\\s*=\\s*'([^']+)'/", $file_content, $key_matches);
            $actual_id = $id_match ? $id_matches[1] : '';
            $actual_key = $key_match ? $key_matches[1] : '';

            if ($actual_id === $website_id && $actual_key === $pixel_key) {
                $need_download = false;
            } else {
                $reason = 'nuhello_wpn.js exists but does not match your website settings. Please download and replace with the correct file.';
            }
        }

        wp_send_json_success([
            'need_download' => $need_download,
            'reason' => $reason,
        ]);
    }

}