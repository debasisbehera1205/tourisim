<?php
/**
 * Utils functions
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Utils {
    /**
     * Generic API request
     *
     * @param string $url The API endpoint URL.
     * @param array $args Arguments for wp_remote_request.
     * @param string $error_prefix A prefix for error messages.
     * @return array|null The decoded JSON response on success, null on failure.
     */
    protected function _make_api_request($url, $args, $error_prefix = 'API request failed') {
        $response = wp_remote_request($url, $args);
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $error_prefix . ': ' . $response->get_error_message()));
            return null;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        if ($response_code !== 200 && $response_code !== 201) {
            $error_data = json_decode($response_body, true);
            $error_message = $error_data['message'] ?? $error_data['error'] ?? 'API returned status ' . $response_code;
            wp_send_json_error(array('message' => $error_prefix . '. ' . $error_message));
            return null;
        }

        $data = json_decode($response_body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error(array('message' => $error_prefix . '. Invalid JSON response from API.'));
            return null;
        }

        return $data;
    }

    protected function send_otp($email) {
        if (empty($email)) {
            wp_send_json_error(array('message' => 'Email is required.'));
            return;
        }

        $email = sanitize_text_field($email);
        #debug
        // wp_send_json_success(array('message' => 'OTP sent successfully.'));
        // return null;
        #debug

        // Generate a 20-character random key
        $random_key = wp_generate_password(20, false);

        // Build the WordPress admin page URL (onboarding page)
        $identifier = base64_encode(json_encode(['email' => $email, 'key' => $random_key]));
        $wp_admin_url = add_query_arg(array(
            'page' => 'nuhello-dashboard',
            'identifier' => $identifier
        ), admin_url('admin.php'));

        // Build the registration URL
        // Note: add_query_arg automatically handles URL encoding, so we don't need urlencode()
        $registration_url = add_query_arg(array(
            'email' => $email,
            'NUHELLO_WPKEY' => $random_key,
            'NUHELLO_WP_ADDRESS' => $wp_admin_url
        ), 'https://nuhello.dev/register-wpflow/');

        $api_url = NUHELLO_AUTH_API_URL . '/api/v1/auth/wp/send-otp';
        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body'      => json_encode(array(
                'email' => $email,
                'key' => $random_key,
                'registration_url' => $registration_url,
                'website' => get_site_url()
            )),
            'data_format' => 'body',
            'timeout'   => 15,
        );
        $response = $this->_make_api_request($api_url, $api_args, 'OTP sending failed');
        if (!empty($response['success']) && $response['statusCode'] == '200') {
            if (!empty($response['payload']['type']) && $response['payload']['type'] == 'registration') {
                // Store registration key and timestamp (15 minutes = 900 seconds)
                update_option('nuhello_registration_key', $random_key);
                update_option('nuhello_registration_email', $email);
                update_option('nuhello_registration_timestamp', time());
                wp_send_json_success(array(
                    'message' => 'Account not found. Please check your email for the registration link to create your account.',
                    'type' => 'registration',
                    'key' => $random_key
                ));
                return null;
            }
            wp_send_json_success(array('message' => 'OTP sent successfully.'));
            return null;
        } else {
            $message = $response['message'] ?? 'Failed to send OTP.';
            wp_send_json_error(array('message' => $message));
            return null;
        }
    }

    protected function verify_otp($email, $otp, $return_chatbots = true) {
        if (empty($email) || empty($otp)) {
            wp_send_json_error(array('message' => 'Email and OTP are required.'));
            return;
        }

        $email = sanitize_text_field($email);
        $otp = sanitize_text_field($otp);

        #debug
        // $chatbots = $this->get_user_chatbots();
        // wp_send_json_success(array('message' => 'OTP verified successfully.', 'chatbots' => $chatbots));
        // return ['success' => true, 'chatbots' => $chatbots];
        #debug

        $api_url = NUHELLO_AUTH_API_URL . '/api/v1/auth/verify-wp-otp';
        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body'      => json_encode(array('email' => $email, 'otp' => $otp)),
            'data_format' => 'body',
            'timeout'   => 15,
        );
        $response = $this->_make_api_request($api_url, $api_args, 'OTP verification failed');
        if (!empty($response['success']) && $response['statusCode'] == '200' && !empty($response['payload']['accessToken'])) {
            update_option('nuhello_auth_token', sanitize_text_field($response['payload']['accessToken']));
            update_option('nuhello_user', $response['payload']['user']);
            update_option('nuhello_otp_verified_time', time());

            // Register shutdown function to be called after response is sent
            // register_shutdown_function(array($this, 'update_opt_validation_time'));
            if (!$return_chatbots) {
                wp_send_json_success(array('message' => 'OTP verified successfully.'));
                return null;
            }
            $chatbots = $this->get_user_chatbots();
            wp_send_json_success(array('message' => 'OTP verified successfully.', 'chatbots' => $chatbots));
            return null;
        } else {
            $message = $response['message'] ?? 'Failed to verify OTP.';
            wp_send_json_error(array('message' => $message));
            return null;
        }
    }

    protected function validate_session($email, $key, $return_chatbots = true) {
        if (empty($email) || empty($key)) {
            wp_send_json_error(array('message' => 'Email and key are required.'));
            return;
        }

        $email = sanitize_text_field($email);
        $key = sanitize_text_field($key);

        $api_url = NUHELLO_AUTH_API_URL . '/api/v1/auth/wp/validate-session';
        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body'      => json_encode(array('email' => $email, 'key' => $key)),
            'data_format' => 'body',
            'timeout'   => 15,
        );
        $response = $this->_make_api_request($api_url, $api_args, 'Session validation failed');
        if (!empty($response['success']) && $response['statusCode'] == '200' && !empty($response['payload']['accessToken'])) {
            update_option('nuhello_auth_token', sanitize_text_field($response['payload']['accessToken']));
            update_option('nuhello_user', $response['payload']['user']);
            update_option('nuhello_otp_verified_time', time());
            
            // Clear registration data after successful validation
            delete_option('nuhello_registration_key');
            delete_option('nuhello_registration_email');
            delete_option('nuhello_registration_timestamp');

            if (!$return_chatbots) {
                wp_send_json_success(array('message' => 'Account created and verified successfully.'));
                return null;
            }
            $chatbots = $this->get_user_chatbots();
            wp_send_json_success(array('message' => 'Account created and verified successfully.', 'chatbots' => $chatbots));
            return null;
        } else {
            $message = $response['message'] ?? 'Failed to validate session.';
            wp_send_json_error(array('message' => $message));
            return null;
        }
    }

    protected function get_user_email() {
        $user_data = get_option('nuhello_user');
        return $user_data['email'] ?? '';
    }

    protected function get_user_chatbots() {
        $user_email = $this->get_user_email();
        if (empty($user_email)) {
            wp_send_json_error(array('message' => 'User email is required.'));
            return;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return null;
        }

        $api_url = NUHELLO_AUTH_API_URL . '/api/v1/chatbot/wordpress-plugin/bots/'. urlencode($user_email);
        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'timeout'   => 15,
        );

        $auth_data = $this->_make_api_request($api_url, $api_args, 'No chatbot found');
        
        if (!empty($auth_data['success']) && $auth_data['statusCode'] == '200' && !empty($auth_data['payload'])) {
            return $auth_data['payload'];
        }

        return array();
    }

    protected function get_website_by_chatbot_id($chatbot_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/get-website-by-chatbot-id?chatbot_id=' . urlencode($chatbot_id);

        $api_args = array(
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch website details');
    }

    /**
     * Call Flask API to verify a single email
     *
     * @param string $email
     * @return array|null
     */
    protected function verify_email_api($email) {
        if (empty($email)) {
            wp_send_json_error(array('message' => 'Email is required.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/verify_email';

        $token = $this->get_auth_token();

        // Get bot_id from saved website details
        $website_details = $this->get_saved_website_details();
        $bot_id = isset($website_details['chatbot_id']) ? $website_details['chatbot_id'] : '';

        $body_data = array('email' => $email);
        if (!empty($bot_id)) {
            $body_data['bot_id'] = $bot_id;
        }

        $api_args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body' => json_encode($body_data),
            'data_format' => 'body',
            'timeout' => 30,
        );

        // If we have an auth token, attempt to send it
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        return $this->_make_api_request($api_url, $api_args, 'Email verification failed');
    }

    /**
     * Call Flask API to verify bulk emails
     *
     * @param array $emails
     * @return array|null
     */
    protected function verify_email_bulk_api($emails = array()) {
        if (empty($emails) || !is_array($emails)) {
            wp_send_json_error(array('message' => 'Emails array is required.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/verify_email_bulk';

        $token = $this->get_auth_token();

        $api_args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body' => json_encode(array('emails' => array_values($emails))),
            'data_format' => 'body',
            'timeout' => 60,
        );

        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        return $this->_make_api_request($api_url, $api_args, 'Bulk email verification failed');
    }

    protected function get_auth_token() {
        // $current_user = wp_get_current_user();
        // $user_email = $current_user->user_email;
        // if (empty($user_email)) {
        //     wp_send_json_error(array('message' => 'User email is required.'));
        //     return;
        // }

        // if (!empty(get_option('nuhello_auth_token')) && $user_email === get_option('nuhello_user_email')) {
            return get_option('nuhello_auth_token');
        // }

    }

    protected function save_website_test_url($chatbot_id, $website_test_url, $production_url = '') {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return;
        }

        if (!empty($website_test_url)) {
            $parsed_url = parse_url($website_test_url);

            $scheme = ($parsed_url['scheme'] ?? 'https') . '://';
            $host = $parsed_url['host'];

            $test_url = ['scheme' => $scheme, 'host' => $host];
        }

        if (!empty($production_url)) {
            $parsed_url = parse_url($production_url);

            $scheme = ($parsed_url['scheme'] ?? 'https') . '://';
            $host = $parsed_url['host'];

            $prod_url = ['scheme' => $scheme, 'host' => $host];
        }

        $api_url = NUHELLO_FLASK_API_URL . '/save-website-url/' . $chatbot_id;
        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'body'      => json_encode(array(
                'test_url' => $test_url,
                'prod_url' => $prod_url
            )),
            'data_format' => 'body',
            'timeout'   => 15,
        );
        return $this->_make_api_request($api_url, $api_args, 'Failed to save website URL');

        return true;

    }

    protected function save_website_features($chatbot_id, $data) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return;
        }

        $features_payload = array(
            'display_chatbot' => isset($data['display_chatbot']) && $data['display_chatbot'] === 'true',
            'show_on_all_pages' => isset($data['show_on_all_pages']) && $data['show_on_all_pages'] === 'true',
            'enable_analytics' => isset($data['enable_analytics']) && $data['enable_analytics'] === 'true',
            'enable_notifications' => isset($data['enable_notifications']) && $data['enable_notifications'] === 'true',
        );

        $api_url = NUHELLO_FLASK_API_URL . "/save-website-features/{$chatbot_id}";
        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'body'      => json_encode($features_payload),
            'data_format' => 'body',
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to save website features');
    }

    protected function save_website_configuration($data, $test_url = null) {
        $is_test_env = isset($data['is_test_env']) && $data['is_test_env'] === 'true';
        $disable_test_tracking = isset($data['disable_test_tracking']) && $data['disable_test_tracking'] === 'true';

        if ($is_test_env && empty($test_url)) {
            wp_send_json_error(array('message' => 'Test URL is not provided.'));
            return;
        }

        $token = $this->get_auth_token();

        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return;
        }

        $test_url_array = [];
        if ($is_test_env && !empty($test_url)) {
            $parsed_url = parse_url($test_url);
            $test_url_array['scheme'] = ($parsed_url['scheme'] ?? 'https') . '://';
            $test_url_array['host'] = $parsed_url['host'];
        }

        $otp_verified_time = get_option('nuhello_otp_verified_time', 0);
        $production_url = !empty($data['production_url']) ? esc_url_raw($data['production_url']) : '';
        if (!empty($production_url) && (time() - $otp_verified_time <= 600)) {
            $parsed_url = parse_url($production_url);
            $prod_url_array['scheme'] = ($parsed_url['scheme'] ?? 'https') . '://';
            $prod_url_array['host'] = $parsed_url['host'];
        }

        $api_url = NUHELLO_FLASK_API_URL . "/save-website-configuration";
        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'body'      => json_encode(array(
                'chatbot_id' => isset($data['chatbot_id']) ? sanitize_text_field($data['chatbot_id']) : '',
                'disable_test_tracking' => $disable_test_tracking,
                'is_test_env' => $is_test_env,
                'test_url' => ['scheme' => $test_url_array['scheme'] ?? '', 'host' => $test_url_array['host'] ?? ''],
                'prod_url' => !empty($prod_url_array) ? ['scheme' => $prod_url_array['scheme'] ?? '', 'host' => $prod_url_array['host'] ?? ''] : null,
                'display_chatbot'      => isset($data['display_chatbot']) && $data['display_chatbot'] === 'true',
                'show_on_all_pages'    => isset($data['show_all_pages']) && $data['show_all_pages'] === 'true',
                'enable_analytics'     => isset($data['enable_analytics']) && $data['enable_analytics'] === 'true',
                'enable_notifications' => isset($data['enable_notifications']) && $data['enable_notifications'] === 'true',
            )),
            'data_format' => 'body',
            'timeout'   => 15,
        );


        return $this->_make_api_request($api_url, $api_args, 'Failed to save website configuration');
    }

    protected function update_website_details($data = null, $chatbot_id = null, $update_option = true) {
        if (!empty($data)) {
            update_option('nuhello_website_details', json_encode($data));
            return $data;
        }

        $api_data = $this->get_website_by_chatbot_id($chatbot_id);
        if ($api_data === null || empty($api_data['pixel_key'])) {
            wp_send_json_error(array('message' => 'Failed to fetch website details.'));
            return;
        }

        if ($update_option) {
            update_option('nuhello_website_details', json_encode($api_data));
        }

        return $api_data;
    }

    public function get_saved_website_details() {
        $website_details_json = get_option('nuhello_website_details', '{}');
        $website = json_decode($website_details_json, true);

        if (empty($website)) {
            return array();
        }
        return $website;
    }

    protected function get_seo_audit($chatbot_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return null;
        }

        $api_url = NUHELLO_AUTH_API_URL . '/api/v1/seo-audits/chatbot/' . urlencode($chatbot_id);

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch SEO audit details');
    }

    protected function trigger_manual_seo_audit($chatbot_id, $org_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return null;
        }

        $api_url = NUHELLO_AUTH_API_URL . '/api/v1/seo-audits';

        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token,
                'x-organization-id' => $org_id
            ),
            'body'      => json_encode(array(
                'chatbotId' => sanitize_text_field($chatbot_id)
            )),
            'data_format' => 'body',
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to trigger SEO audit');
    }

    protected function get_analytics_data($chatbot_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $token = $this->get_auth_token();

        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/analytics-dashboard?Chatbot_ID=' . urlencode($chatbot_id);

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch analytics data');
    }

    protected function get_home_analytics_tickets($chatbot_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/home-analytics/tickets';
        $api_url = add_query_arg(array('Chatbot_ID' => $chatbot_id), $api_url);

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch ticket metrics');
    }

    protected function get_message_desk_tickets($chatbot_id, $take = 5, $page = 1, $search = '') {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/message-desk/tickets';
        $query = array(
            'Chatbot_ID' => $chatbot_id,
            'take' => max(1, intval($take)),
            'page' => max(1, intval($page))
        );
        if (!empty($search)) {
            $query['searchTerm'] = $search;
        }

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $api_url = add_query_arg($query, $api_url);
        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch message desk tickets');
    }

    protected function get_message_desk_ticket($ticket_id) {
        if (empty($ticket_id)) {
            wp_send_json_error(array('message' => 'Ticket ID is required.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/message-desk/tickets/' . urlencode($ticket_id);
        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch message desk ticket'); 
    }

    protected function send_message_desk_email($payload) {
        if (empty($payload) || !is_array($payload)) {
            wp_send_json_error(array('message' => 'Payload is required.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/message-desk/send/email';
        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
            'body'      => wp_json_encode($payload)
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        return $this->_make_api_request($api_url, $api_args, 'Failed to send message desk email');
    }

    protected function get_message_desk_conversations($chatbot_id, $take = 10, $page = 1, $search = '') {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/get_conversations';
        $query = array(
            'Chatbot_ID' => $chatbot_id,
            'take' => max(1, intval($take)),
            'page' => max(1, intval($page))
        );
        if (!empty($search)) {
            $query['searchTerm'] = $search;
        }

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $api_url = add_query_arg($query, $api_url);
        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch message desk conversations');
    }

    protected function get_message_desk_conversation($conversation_id, $user_type = 'agent') {
        if (empty($conversation_id)) {
            wp_send_json_error(array('message' => 'Conversation ID is required.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/get_conversation';
        $query = array(
            'conversation_id' => $conversation_id,
            'user_type' => $user_type
        );

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $api_url = add_query_arg($query, $api_url);
        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch message desk conversation');
    }

    protected function get_message_desk_leads($chatbot_id, $take = 10, $page = 1, $search = '') {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/get_connections';
        $query = array(
            'Chatbot_ID' => $chatbot_id,
            'connection_type' => 'lead',
            'take' => max(1, intval($take)),
            'page' => max(1, intval($page))
        );
        if (!empty($search)) {
            $query['searchTerm'] = $search;
        }

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $api_url = add_query_arg($query, $api_url);
        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch message desk leads');
    }

    protected function get_message_desk_lead($lead_id) {
        if (empty($lead_id)) {
            wp_send_json_error(array('message' => 'Lead ID is required.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/get_connection';
        $query = array(
            'connection_id' => $lead_id
        );

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $api_url = add_query_arg($query, $api_url);
        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch message desk lead');
    }

    protected function get_chat_settings_public($chatbot_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_AUTH_API_URL, '/') . '/api/v1/chatbot/web/chat-settings-public/' . urlencode($chatbot_id);
        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch chat settings');
    }

    protected function get_upgrade_plans($current_user_id) {
        if (empty($current_user_id)) {
            wp_send_json_error(array('message' => 'User ID is required.'));
            return null;
        }

        $api_url = rtrim(NUHELLO_AUTH_API_URL, '/') . '/api/v1/plans/upgrade/' . urlencode($current_user_id);
        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $website_details = $this->get_saved_website_details();
        $org_id = $website_details['organization_id'] ?? '';
        if (!empty($org_id)) {
            $api_args['headers']['x-organization-id'] = $org_id;
        }

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch upgrade plans');
    }

    protected function get_pricing_plans($options = array()) {
        $api_url = rtrim(NUHELLO_AUTH_API_URL, '/') . '/api/v1/plans/pricing';
        if (!empty($options)) {
            $api_url = add_query_arg($options, $api_url);
        } 

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'timeout'   => 20,
        );

        $token = $this->get_auth_token();
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $website_details = $this->get_saved_website_details();
        $org_id = $website_details['organization_id'] ?? '';
        if (!empty($org_id)) {
            $api_args['headers']['x-organization-id'] = $org_id;
        }

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch pricing plans');
    }

    protected function get_page_views_bounce_rate($chatbot_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $token = $this->get_auth_token();

        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/get-total-page-views-and-bounce-rate/' . urlencode($chatbot_id) . '?request_from=wordpress';

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch analytics data');
    }

    protected function get_session_lengths($chatbot_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(array('message' => 'Chatbot is not selected.'));
            return null;
        }

        $token = $this->get_auth_token();

        if (empty($token)) {
            wp_send_json_error(array('message' => 'Unauthorized access.'));
            return null;
        }

        if (empty($from_date)) {
            $from_date = date('Y-m-d', strtotime('-30 days'));
        }

        if (empty($to_date)) {
            $to_date = date('Y-m-d');
        }

        $api_url = NUHELLO_FLASK_API_URL . '/chat-data-normal/' . urlencode($chatbot_id) . '/dashboard/session_lengths?startDate=' . $from_date . '&endDate=' . $to_date;

        $api_args = array(
            'method'    => 'GET',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch analytics data');
    }

    protected function update_opt_validation_time() {
        $token = $this->get_auth_token();

        if (empty($token)) {
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/update-wp-plugin-otp-validation-time';

        $api_args = array(
            'method'    => 'POST',
            'headers'   => array(
                'Content-Type' => 'application/json; charset=utf-8',
                'Authorization' => 'Bearer ' . $token
            ),
            'timeout'   => 15,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch analytics data');
    }

    protected function get_subscriber_widget_settings($chatbot_id) {
        if (empty($chatbot_id)) {
            wp_send_json_error(['message' => 'Chatbot ID is missing.']);
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            wp_send_json_error(['message' => 'Authentication token is missing.']);
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/notification/subscriber-widget/' . urlencode($chatbot_id);

        $api_args = array(
            'method'  => 'GET',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
            'timeout' => 30,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch subscriber widget settings');
    }

    protected function update_subscriber_widget_settings($chatbot_id, $settings) {
        if (empty($chatbot_id)) {
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/notification/subscriber-widget-update-wordpress/' . urlencode($chatbot_id);

        $api_args = array(
            'method'  => 'PUT',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
            'body'    => json_encode($settings),
            'timeout' => 30,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to update subscriber widget settings');
    }

    protected function get_campaigns_by_chatbot_id($chatbot_id, $page = 1, $page_size = 10) {
        if (empty($chatbot_id)) {
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/notification/campaigns/' . urlencode($chatbot_id) . '?page=' . $page . '&page-size=' . $page_size;

        $api_args = array(
            'method' => 'GET',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            )
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch campaigns');
    }

    protected function create_campaign($chatbot_id, $data) {
        if (empty($chatbot_id)) {
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/notification/campaign/' . urlencode($chatbot_id);

        $api_args = array(
            'method' => 'PUT',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/x-www-form-urlencoded'
            ),
            'body' => http_build_query($data),
            'timeout' => 30,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to create campaign');
    }

    protected function get_campaign_details($chatbot_id, $campaign_id) {
        if (empty($chatbot_id)) {
            return null;
        }

        if (empty($campaign_id)) {
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/notification/campaign/' . urlencode($chatbot_id) . '/' . urlencode($campaign_id);

        $api_args = array(
            'method' => 'GET',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            )
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch campaign details');
    }

    protected function update_campaign($chatbot_id, $data) {
        if (empty($chatbot_id)) {
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/notification/campaign/' . urlencode($chatbot_id);

        $body_parts = [];
        foreach ($data as $key => $value) {
            if ($key === 'subscribers_ids' && is_array($value)) {
                foreach ($value as $id) {
                    $body_parts[] = 'subscribers_ids[][value]=' . urlencode($id['value'] ?? '');
                }
            } else {
                $body_parts[] = urlencode($key) . '=' . urlencode($value);
            }
        }
        $body_string = implode('&', $body_parts);

        $api_args = array(
            'method' => 'PUT',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/x-www-form-urlencoded'
            ),
            'body' => $body_string,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to update campaign');
    }

    public function get_all_segment_ids($chatbot_id) {
        if (empty($chatbot_id)) {
            return array('success' => false, 'message' => 'Chatbot ID is missing.');
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . "/notification/all-segment-ids/{$chatbot_id}";

        $api_args = array(
            'method' => 'GET',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            )
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to fetch segment');
    }

    protected function launch_campaign($chatbot_id, $campaign_id, $data) {
        if (empty($chatbot_id) || empty($campaign_id)) {
            return null;
        }

        $token = $this->get_auth_token();
        if (empty($token)) {
            return null;
        }

        $api_url = NUHELLO_FLASK_API_URL . '/notification/launch-campaign/' . urlencode($chatbot_id) . '/' . urlencode($campaign_id);

        $api_args = array(
            'method' => 'POST',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/x-www-form-urlencoded'
            ),
            'body' => http_build_query($data),
            'timeout' => 30,
        );

        return $this->_make_api_request($api_url, $api_args, 'Failed to launch campaign');
    }
}