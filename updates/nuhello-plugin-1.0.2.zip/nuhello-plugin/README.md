# Nuhello Plugin

A WordPress plugin with dashboard and onboarding wizard, built from modular architecture.

## Plugin Structure

```
nuhello-plugin/
├── nuhello-plugin.php              # Main plugin file
├── includes/                        # PHP classes
│   ├── class-nuhello-plugin.php   # Main plugin class
│   ├── class-admin-menu.php        # Admin menu handler
│   ├── class-onboarding.php        # Onboarding wizard
│   ├── class-dashboard.php         # Dashboard management
│   ├── class-ajax-handler.php      # AJAX request handler
│   └── class-assets.php            # Scripts and styles
├── admin/                          # Admin interface
│   └── views/                      # View templates
│       ├── onboarding-wizard.php   # Onboarding wizard view
│       ├── dashboard.php           # Main dashboard view
│       └── tabs/                   # Tab-specific views
│           └── configuration.php   # Configuration tab
├── assets/                         # Frontend assets
│   ├── css/
│   │   └── admin.css
│   └── js/
│       └── admin.js
└── README.md                       # This file
```

## Key Components

### 1. **Main Plugin Class** (`class-nuhello-plugin.php`)
- Orchestrates all components
- Lightweight and focused

### 2. **Admin Menu Handler** (`class-admin-menu.php`)
- Manages WordPress admin menu
- Handles page routing

### 3. **Onboarding Wizard** (`class-onboarding.php`)
- Dedicated onboarding functionality
- Separate view template

### 4. **Dashboard Management** (`class-dashboard.php`)
- Tab system management
- Dynamic tab loading

### 5. **AJAX Handler** (`class-ajax-handler.php`)
- Centralized AJAX processing
- Security-focused

### 6. **Assets Management** (`class-assets.php`)
- Script and style enqueuing
- Conditional loading

## Usage

The plugin automatically initializes when WordPress loads. The modular structure allows us to:

- **Add new tabs**: Create new view files in `admin/views/tabs/`
- **Extend functionality**: Add new classes in `includes/`
- **Customize styling**: Modify files in `assets/`
- **Add features**: Extend existing classes or create new ones
