<?php
/**
 * Template for the AI Recommendations section in the detailed audit view.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="ai-recs-main-header">
    <h3 class="ai-recs-title">AI Recommendations</h3>
    <p class="ai-recs-subtitle">
        Our AI has identified <span></span> 
        to enhance your website's search engine performance.
    </p>
</div>
<div class="ai-recs-list"></div>
