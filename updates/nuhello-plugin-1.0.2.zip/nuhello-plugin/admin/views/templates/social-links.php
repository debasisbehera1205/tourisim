<?php
/**
 * Template for the Social Media Links section in the detailed audit view.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="detail-section-header">
    <h3 class="detail-section-title">Social Media Links</h3>
    <p class="detail-section-subtitle">
        Your website has <span></span> social media links properly configured.
    </p>
</div>
<div class="detail-section-list"></div>
