<?php
/**
 * Template for a single item in the Technical & Performance section.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="detail-section-item">
    <div class="detail-item-header">
        <div class="detail-item-main-content">
            <div class="detail-item-title-group">
                <span class="dashicons"></span>
                <span class="status-badge"></span>
                <span class="priority-badge" style="display: none;"></span>
            </div>
            <div class="detail-item-text-content">
                <h4 class="detail-item-title"></h4>
                <p class="detail-item-description"></p>
            </div>
        </div>
        <button class="detail-solution-toggle" style="display: none;"><span class="dashicons dashicons-lightbulb"></span></button>
    </div>
    <div class="detail-current-value">
        <span class="detail-current-label">Current:</span>
        <span class="detail-value-content"></span>
        <span class="detail-extra-info" style="display: none;"></span>
    </div>
    <div class="detail-warning" style="display: none;">
        <div class="detail-warning-icon-wrap">
            <span class="dashicons dashicons-warning"></span>
        </div>
        <div class="detail-warning-content">
            <h5 class="detail-warning-title"></h5>
            <p class="detail-warning-text"></p>
        </div>
    </div>
    <div class="detail-solution" style="display: none;">
        <div class="detail-info-box-icon-wrap">
            <span class="dashicons dashicons-lightbulb"></span>
        </div>
        <div class="detail-info-box-content">
            <h5 class="detail-info-box-title">How to fix:</h5>
            <p class="detail-info-box-text"></p>
        </div>
    </div>
</div>
