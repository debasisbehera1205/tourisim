<?php
/**
 * Campaigns Tab View
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="dashboard-layout campaigns-layout">
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-megaphone"></i> Campaigns</h2>
            <p class="header-description">Manage your push notification campaigns.</p>
        </div>
        <div class="header-actions">
            <button type="button" id="create-campaign-btn" class="nuhello-btn nuhello-btn-primary">
                <i class="dashicons dashicons-plus"></i> Create Campaign
            </button>
        </div>
    </div>

    <div class="content-wrapper">
        <div id="campaigns-loading">
            <div class="campaign-loader"></div>
        </div>
        <div class="content-row" style="display: none;">
            <div class="campaigns-table-container">
                <table id="campaigns-table">
                    <thead>
                        <tr>
                            <td id="cb" class="manage-column column-cb check-column"><input id="cb-select-all-1" type="checkbox"></td>
                            <th scope="col" class="manage-column">Campaign</th>
                            <th scope="col" class="manage-column">Segment</th>
                            <th scope="col" class="manage-column">Notifications</th>
                            <th scope="col" class="manage-column">Status</th>
                            <th scope="col" class="manage-column">Dates</th>
                            <th scope="col" class="manage-column">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Campaign rows will be inserted here by JavaScript -->
                    </tbody>
                </table>
                <div class="tablenav bottom">
                    <div class="tablenav-pages" id="campaigns-pagination">
                        <!-- Pagination will be inserted here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Create Campaign Modal -->
<div id="create-campaign-modal" class="nuhello-modal" style="display: none;">
    <div class="modal-content">
        <span class="close-button">&times;</span>
        <h2>Create Campaign</h2>
        <p>Add a new campaign to start sending push notifications.</p>
        <form id="create-campaign-form">
            <div class="form-group">
                <label for="campaign-name">Campaign name</label>
                <input type="text" id="campaign-name" name="campaign_name" placeholder="Enter a name for your campaign" required>
            </div>
            <div class="form-actions">
                <button type="button" class="nuhello-btn nuhello-btn-secondary" id="cancel-create-campaign">Cancel</button>
                <button type="submit" class="nuhello-btn nuhello-btn-primary">Create Campaign</button>
            </div>
        </form>
    </div>
</div>
