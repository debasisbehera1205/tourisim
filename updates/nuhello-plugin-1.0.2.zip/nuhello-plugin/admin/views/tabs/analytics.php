<?php
/**
 * Analytics Audit Tab
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-chart-geo@3.7.0/build/index.umd.min.js"></script>
<script src="https://unpkg.com/topojson-client@3"></script>

<div class="dashboard-layout customize-layout">
    <!-- Unified Header -->
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-chart-bar"></i> Analytics</h2>
            <p class="header-description">Track and analyze your chatbot performance with detailed insights and metrics</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <button type="button" id="refresh-analytics" class="nuhello-btn nuhello-btn-sm nuhello-btn-outline">
                    <i class="dashicons dashicons-update"></i> Refresh Data
                </button>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="content-row">
        <div class="dashboard-left" style="width: 100%; flex: 1;">
            <div class="analytics-wrap">
                <div id="analytics-dashboard-loading" style="display: none;">
                    <div class="analytics-loader"></div>
                </div>
                <div id="analytics-dashboard-content" class="analytics-dashboard" style="display: none;">
        <!-- Stats Overview -->
        <div class="analytics-grid analytics-grid-cols-4">
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-card-icon bg-primary-light">
                        <span class="dashicons dashicons-groups"></span>
                    </div>
                    <div>
                        <p class="stat-card-title">Total Visitors</p>
                        <h3 id="total-visitors" class="stat-card-value">0</h3>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-card-icon bg-blue-light">
                         <span class="dashicons dashicons-backup"></span>
                    </div>
                    <div>
                        <p class="stat-card-title">Sessions</p>
                        <h3 id="total-sessions" class="stat-card-value">0</h3>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-card-icon bg-green-light">
                         <span class="dashicons dashicons-admin-page"></span>
                    </div>
                    <div>
                        <p class="stat-card-title">Total Page Views</p>
                        <h3 id="total-page-views" class="stat-card-value">0</h3>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-card-icon bg-yellow-light">
                        <span class="dashicons dashicons-undo"></span>
                    </div>
                    <div>
                        <p class="stat-card-title">Bounce Rate</p>
                        <h3 id="bounce-rate" class="stat-card-value">0%</h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- Visits Over Time and Pages row -->
        <div class="analytics-grid analytics-grid-cols-4">
            <div class="analytics-col-span-3">
                <div class="chart-card h-430">
                    <div class="chart-card-header">
                        <div class="chart-card-icon-wrapper" style="background-color: rgba(73, 188, 49, 0.1);">
                             <span class="dashicons dashicons-chart-area"></span>
                        </div>
                        <h4 class="chart-card-title">Visits Over Time</h4>
                    </div>
                    <div class="chart-card-body">
                        <canvas id="visitsOverTimeChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="analytics-col-span-1">
                <div id="pages-card" class="list-card h-430 list-card-blue"></div>
            </div>
        </div>

        <!-- Visitor Locations, OS, and Devices row -->
        <div class="analytics-grid analytics-grid-cols-4">
            <div class="analytics-col-span-2">
                <div class="chart-card h-430">
                    <div class="chart-card-header">
                        <div class="chart-card-icon-wrapper" style="background-color: rgba(73, 188, 49, 0.1);">
                            <span class="dashicons dashicons-location-alt"></span>
                        </div>
                        <h4 class="chart-card-title">Visitor Locations</h4>
                    </div>
                    <div class="chart-card-body">
                        <canvas id="visitorMapChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="analytics-col-span-1">
                <div id="os-card" class="list-card h-430 list-card-red"></div>
            </div>
            <div class="analytics-col-span-1">
                <div id="devices-card" class="list-card h-430 list-card-purple"></div>
            </div>
        </div>

        <!-- Browsers, Countries, Screen Resolutions, Browser Languages -->
        <div class="analytics-grid analytics-grid-cols-4">
            <div class="analytics-col-span-1">
                <div id="browsers-card" class="list-card h-430 list-card-blue"></div>
            </div>
            <div class="analytics-col-span-1">
                <div id="countries-card" class="list-card h-430 list-card-green"></div>
            </div>
            <div class="analytics-col-span-1">
                <div id="resolutions-card" class="list-card h-430 list-card-red"></div>
            </div>
            <div class="analytics-col-span-1">
                <div id="languages-card" class="list-card h-430 list-card-purple"></div>
            </div>
        </div>

        <!-- Referrers, UTM, Session Distribution -->
        <div class="analytics-grid analytics-grid-cols-12">
            <div class="analytics-col-span-3">
                <div id="referrers-card" class="list-card h-430 list-card-blue"></div>
            </div>
            <div class="analytics-col-span-6">
                <div id="utm-card" class="list-card h-430 list-card-green"></div>
            </div>
            <div class="analytics-col-span-3">
                <div class="chart-card h-430">
                     <div class="chart-card-header">
                        <div class="chart-card-icon-wrapper" style="background-color: rgba(63, 33, 91, 0.035);">
                            <span class="dashicons dashicons-chart-pie"></span>
                        </div>
                        <h4 class="chart-card-title">Session Distribution</h4>
                    </div>
                    <div class="chart-card-body" style="display: flex; justify-content: center; align-items: center;">
                        <canvas id="sessionDistributionChart" style="max-width: 250px; max-height: 250px;"></canvas>
                    </div>
                </div>
            </div>
        </div>
            </div>
        </div>
    </div>
</div>



