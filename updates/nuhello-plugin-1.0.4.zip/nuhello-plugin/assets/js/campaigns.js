(function($) {
    'use strict';

    $(document).ready(function() {
        const CampaignsManager = {
            currentPage: 1,
            pageSize: 10,

            init: function() {
                if ($('#campaigns-table').length) {
                    this.bindEvents();
                    this.loadCampaigns(this.currentPage);
                }
            },

            bindEvents: function() {
                // Open modal
                $('#create-campaign-btn').on('click', this.openModal.bind(this));

                // Close modal
                $('#create-campaign-modal .close-button, #cancel-create-campaign').on('click', this.closeModal.bind(this));

                // Create campaign form submission
                $('#create-campaign-form').on('submit', this.createCampaign.bind(this));

                // Pagination
                $(document).on('click', '#campaigns-pagination a', this.handlePaginationClick.bind(this));

                // Customize button click
                $(document).on('click', '[data-campaign-id]', this.handleCustomizeClick.bind(this));
            },

            loadCampaigns: function(page) {
                $('#campaigns-loading').show();
                $('.content-row').hide();

                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'GET',
                    data: {
                        action: 'nuhello_get_campaigns',
                        nonce: nuhello_ajax.nonce,
                        page: page,
                        page_size: this.pageSize
                    },
                    dataType: 'json',
                    success: (response) => {
                        if (response.success) {
                            this.renderCampaigns(response.data.campaigns);
                            this.renderPagination(response.data.page, response.data.total, response.data.page_size);
                        } else {
                            this.showError(response.data.message || 'Failed to load campaigns.');
                        }
                    },
                    error: (xhr, status, error) => {
                        this.showError('An error occurred while fetching campaigns.');
                    },
                    complete: () => {
                        $('#campaigns-loading').hide();
                        $('.content-row').show();
                    }
                });
            },

            renderCampaigns: function(campaigns) {
                const tableBody = $('#campaigns-table tbody');
                tableBody.empty();

                if (campaigns.length === 0) {
                    tableBody.append('<tr><td colspan="7" style="text-align:center;">No campaigns found.</td></tr>');
                    return;
                }

                campaigns.forEach(campaign => {
                    const row = `
                        <tr>
                            <td scope="row" class="check-column"><input type="checkbox" name="campaign[]" value="${campaign._id}"></td>
                            <td><strong>${campaign.name}</strong></td>
                            <td>All Subscribers(${campaign.subscribers_ids.length})</td>
                            <td>${campaign.total_push_notifications}</td>
                            <td><span class="campaign-status status-${campaign.status}">${campaign.status}</span></td>
                            <td>${new Date(campaign.datetime).toLocaleDateString()}</td>
                            <td>
                                <button class="button button-secondary" data-campaign-id="${campaign._id}">Customize</button>
                            </td>
                        </tr>
                    `;
                    tableBody.append(row);
                });
            },

            renderPagination: function(currentPage, totalItems, pageSize) {
                const paginationContainer = $('#campaigns-pagination');
                paginationContainer.empty();
                const totalPages = Math.ceil(totalItems / pageSize);

                if (totalPages <= 1) {
                    return;
                }

                let paginationHTML = `<span class="displaying-num">${totalItems} items</span>`;
                paginationHTML += '<span class="pagination-links">';

                // First page and previous page links
                if (currentPage > 1) {
                    paginationHTML += `<a class="first-page button" href="#" data-page="1"><span class="screen-reader-text">First page</span><span aria-hidden="true">«</span></a>`;
                    paginationHTML += `<a class="prev-page button" href="#" data-page="${currentPage - 1}"><span class="screen-reader-text">Previous page</span><span aria-hidden="true">‹</span></a>`;
                } else {
                    paginationHTML += `<span class="tablenav-pages-navspan button disabled" aria-hidden="true">«</span>`;
                    paginationHTML += `<span class="tablenav-pages-navspan button disabled" aria-hidden="true">‹</span>`;
                }

                // Page number links
                paginationHTML += `<span class="paging-input"><label for="current-page-selector" class="screen-reader-text">Current Page</label><input class="current-page" id="current-page-selector" type="text" name="paged" value="${currentPage}" size="1" aria-describedby="table-paging"> of <span class="total-pages">${totalPages}</span></span>`;

                // Next page and last page links
                if (currentPage < totalPages) {
                    paginationHTML += `<a class="next-page button" href="#" data-page="${currentPage + 1}"><span class="screen-reader-text">Next page</span><span aria-hidden="true">›</span></a>`;
                    paginationHTML += `<a class="last-page button" href="#" data-page="${totalPages}"><span class="screen-reader-text">Last page</span><span aria-hidden="true">»</span></a>`;
                } else {
                    paginationHTML += `<span class="tablenav-pages-navspan button disabled" aria-hidden="true">›</span>`;
                    paginationHTML += `<span class="tablenav-pages-navspan button disabled" aria-hidden="true">»</span>`;
                }

                paginationHTML += '</span>';
                paginationContainer.html(paginationHTML);
            },

            handlePaginationClick: function(e) {
                e.preventDefault();
                const page = $(e.currentTarget).data('page');
                if (page) {
                    this.currentPage = page;
                    this.loadCampaigns(this.currentPage);
                }
            },

            handleCustomizeClick: function(e) {
                e.preventDefault();
                const campaignId = $(e.currentTarget).data('campaign-id');
                if (campaignId) {
                    window.location.href = `admin.php?page=nuhello-dashboard&tab=notifications&subtab=customize-campaign&campaign_id=${campaignId}`;
                }
            },

            openModal: function() {
                $('#create-campaign-modal').show();
            },

            closeModal: function() {
                $('#create-campaign-modal').hide();
                $('#create-campaign-form')[0].reset();
            },

            createCampaign: function(e) {
                e.preventDefault();
                const campaignName = $('#campaign-name').val().trim();
                if (!campaignName) {
                    this.showError('Please enter a campaign name.');
                    return;
                }

                const $button = $('#create-campaign-form button[type="submit"]');
                const originalText = $button.html();
                $button.html('Creating...').prop('disabled', true);

                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'nuhello_create_campaign',
                        nonce: nuhello_ajax.nonce,
                        name: campaignName
                    },
                    dataType: 'json',
                    success: (response) => {
                        if (response.success) {
                            this.closeModal();
                            this.loadCampaigns(1); // Go back to the first page
                            // You can add a success notification here
                        } else {
                            this.showError(response.data.message || 'Failed to create campaign.');
                        }
                    },
                    error: () => {
                        this.showError('An error occurred while creating the campaign.');
                    },
                    complete: () => {
                        $button.html(originalText).prop('disabled', false);
                    }
                });
            },

            showError: function(message) {
                // You can implement a more sophisticated notification system
                alert(message);
            }
        };

        CampaignsManager.init();
    });

})(jQuery);
