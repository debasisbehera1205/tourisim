<?php
/**
 * Reusable loader markup
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

$inline = isset($inline) ? (bool) $inline : false;
$loader_id = isset($loader_id) ? $loader_id : '';
$loader_class = 'nuhello-loading' . ($inline ? ' inline' : '');
$loader_id_attr = !empty($loader_id) ? ' id="' . esc_attr($loader_id) . '"' : '';
?>

<div class="<?php echo esc_attr($loader_class); ?>"<?php echo $loader_id_attr; ?> aria-hidden="true">
    <svg class="pl" viewBox="0 0 64 64" width="64" height="64" xmlns="http://www.w3.org/2000/svg">
        <circle class="pl__inner" cx="32" cy="32" r="13" fill="none" stroke="#3F215B" stroke-width="14" stroke-linecap="round" />
        <circle class="pl__ring" cx="32" cy="32" r="27" fill="none" stroke="#49BC31" stroke-width="8" stroke-dasharray="127 82" stroke-linecap="round" transform="rotate(215)" />
    </svg>
</div>
