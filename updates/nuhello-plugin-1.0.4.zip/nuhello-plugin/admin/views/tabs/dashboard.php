<?php
/**
 * Dashboard Tab
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-chart-geo@3.7.0/build/index.umd.min.js"></script>
<script src="https://unpkg.com/topojson-client@3"></script>

<div class="dashboard-layout">
    <!-- Unified Header -->
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-dashboard"></i> Dashboard</h2>
            <p class="header-description">Overview of your chatbot performance and key metrics</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <button type="button" id="refresh-dashboard" class="nuhello-btn nuhello-btn-sm nuhello-btn-outline">
                    <i class="dashicons dashicons-update"></i> Refresh Data
                </button>
                <button type="button" id="run-seo-audit" class="nuhello-btn nuhello-btn-sm nuhello-btn-outline">
                    <i class="dashicons dashicons-update"></i> Run Brand Health Check
                </button>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="content-row">
        <div class="dashboard-left" style="width: 100%; flex: 1;">
            <div id="dashboard-loading">
                <?php
                    $inline = false;
                    $loader_id = '';
                    include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
                ?>
                <div class="loading-text">Loading dashboard data...</div>
            </div>
            <div id="dashboard-content" class="dashboard-content" style="display: none;">

                    <!-- Tickets Metric Cards -->
                    <div id="tickets-metrics" class="brand-tickets-metrics">
                        <div class="metric-card">
                            <div class="metric-card-content">
                                <div class="metric-card-left">
                                    <div class="metric-card-label-wrapper">
                                        <div class="metric-card-label">Total Tickets</div>
                                        <a href="<?php echo esc_url($tickets_link); ?>" class="tickets-arrow-link" title="View Tickets Details">
                                            <i class="dashicons dashicons-arrow-right-alt"></i>
                                        </a>
                                    </div>
                                    <div class="metric-card-value-wrapper">
                                        <div class="metric-card-value" id="total-tickets-value">0</div>
                                        <div class="metric-card-change positive" id="total-tickets-change">
                                            <svg class="trend-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div class="metric-card-compared">Compared to last week</div>
                                </div>
                                <div class="metric-card-chart" id="total-tickets-chart"></div>
                            </div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-card-content">
                                <div class="metric-card-left">
                                    <div class="metric-card-label-wrapper">
                                        <div class="metric-card-label">Open Tickets</div>
                                        <a href="<?php echo esc_url($tickets_link); ?>" class="tickets-arrow-link" title="View Open Tickets Details">
                                            <i class="dashicons dashicons-arrow-right-alt"></i>
                                        </a>
                                    </div>
                                    <div class="metric-card-value-wrapper">
                                        <div class="metric-card-value" id="open-tickets-value">0</div>
                                        <div class="metric-card-change negative" id="open-tickets-change">
                                            <svg class="trend-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"></path></svg>
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div class="metric-card-compared">Compared to last week</div>
                                </div>
                                <div class="metric-card-chart" id="open-tickets-chart"></div>
                            </div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-card-content">
                                <div class="metric-card-left">
                                    <div class="metric-card-label-wrapper">
                                        <div class="metric-card-label">Resolved Tickets</div>
                                        <a href="<?php echo esc_url($tickets_link); ?>" class="tickets-arrow-link" title="View Resolved Tickets Details">
                                            <i class="dashicons dashicons-arrow-right-alt"></i>
                                        </a>
                                    </div>
                                    <div class="metric-card-value-wrapper">
                                        <div class="metric-card-value" id="resolved-tickets-value">0</div>
                                        <div class="metric-card-change positive" id="resolved-tickets-change">
                                            <svg class="trend-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div class="metric-card-compared">Compared to last week</div>
                                </div>
                                <div class="metric-card-chart" id="resolved-tickets-chart"></div>
                            </div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-card-content">
                                <div class="metric-card-left">
                                    <div class="metric-card-label-wrapper">
                                        <div class="metric-card-label">Spam Score</div>
                                    </div>
                                    <div class="metric-card-value-wrapper">
                                        <div class="metric-card-value" id="spam-score-value">0</div>
                                        <div class="metric-card-change negative" id="spam-score-change">
                                            <svg class="trend-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"></path></svg>
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div class="metric-card-compared">Compared to last week</div>
                                </div>
                                <div class="metric-card-chart" id="spam-score-chart"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Analytics Stats Overview -->
                    <div class="brand-tickets-metrics">
                        <div class="metric-card">
                            <div class="metric-card-content">
                                <div class="metric-card-left">
                                    <div class="metric-card-label-wrapper">
                                        <div class="metric-card-label">Total Visitors</div>
                                    </div>
                                    <div class="metric-card-value-wrapper">
                                        <div class="metric-card-value" id="total-visitors">0</div>
                                        <div class="metric-card-change positive" id="total-visitors-change">
                                            <svg class="trend-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div class="metric-card-compared">Compared to last week</div>
                                </div>
                                <div class="metric-card-chart" id="total-visitors-chart"></div>
                            </div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-card-content">
                                <div class="metric-card-left">
                                    <div class="metric-card-label-wrapper">
                                        <div class="metric-card-label">Sessions</div>
                                    </div>
                                    <div class="metric-card-value-wrapper">
                                        <div class="metric-card-value" id="total-sessions">0</div>
                                        <div class="metric-card-change positive" id="total-sessions-change">
                                            <svg class="trend-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div class="metric-card-compared">Compared to last week</div>
                                </div>
                                <div class="metric-card-chart" id="total-sessions-chart"></div>
                            </div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-card-content">
                                <div class="metric-card-left">
                                    <div class="metric-card-label-wrapper">
                                        <div class="metric-card-label">Page Views</div>
                                    </div>
                                    <div class="metric-card-value-wrapper">
                                        <div class="metric-card-value" id="total-page-views">0</div>
                                        <div class="metric-card-change positive" id="total-page-views-change">
                                            <svg class="trend-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div class="metric-card-compared">Compared to last week</div>
                                </div>
                                <div class="metric-card-chart" id="total-page-views-chart"></div>
                            </div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-card-content">
                                <div class="metric-card-left">
                                    <div class="metric-card-label-wrapper">
                                        <div class="metric-card-label">Bounce Rate</div>
                                    </div>
                                    <div class="metric-card-value-wrapper">
                                        <div class="metric-card-value" id="bounce-rate">0%</div>
                                        <div class="metric-card-change negative" id="bounce-rate-change">
                                            <svg class="trend-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"></path></svg>
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div class="metric-card-compared">Compared to last week</div>
                                </div>
                                <div class="metric-card-chart" id="bounce-rate-chart"></div>
                            </div>
                        </div>
                    </div>

                    <!-- SEO Dashboard Layout -->
                    <div class="seo-dashboard" id="seo-dashboard-section">
                        <!-- Left Column: Overall Score -->
                        <div class="seo-left-column">
                            <div class="card">
                                <!-- Header -->
                                <div class="card-header">
                                    <div class="card-header-title">
                                        <div class="card-header-icon" style="background-color: var(--indigo-100);">
                                            <svg style="color: var(--indigo-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                                        </div>
                                        <span class="card-header-text">Brand Score</span>
                                    </div>
                                    <span id="overall-score-badge" class="badge"></span>
                                </div>
                                <!-- Score Display -->
                                <div class="score-display">
                                    <div class="score-circle">
                                        <svg viewBox="0 0 100 100">
                                            <circle class="score-circle-bg" cx="50" cy="50" r="45" stroke-width="4" fill="transparent"></circle>
                                            <circle id="score-circle-progress" class="score-circle-progress" cx="50" cy="50" r="45" stroke-width="4" fill="transparent" stroke-dasharray="282.7" stroke-dashoffset="282.7"></circle>
                                        </svg>
                                        <div id="overall-score-text" class="score-circle-text"></div>
                                    </div>
                                </div>
                                <!-- Website Info -->
                                <div class="domain-info">
                                    <h4 class="domain-info-header">Domain</h4>
                                    <div class="domain-info-url">
                                        <img id="favicon-img" src="" alt="favicon" width="16" height="16"/>
                                        <div class="separator"></div>
                                        <span id="domain-url"></span>
                                    </div>
                                </div>
                                <!-- Audit Results -->
                                <div class="audit-results">
                                    <div class="audit-results-header">
                                        <div style="display: flex; align-items: center; gap: 0.rem;">
                                            <h4 class="audit-results-header-title">Audit Results</h4>
                                            <a href="<?php echo admin_url('admin.php?page=nuhello-dashboard&tab=seo&view=full-report'); ?>" class="seo-report-arrow-link" title="View Full SEO Report">
                                                <i class="dashicons dashicons-arrow-right-alt"></i>
                                            </a>
                                        </div>
                                        <span id="total-tests-info" class="total-tests"></span>
                                    </div>
                                    <div class="audit-results-grid">
                                        <div class="audit-result-box passed">
                                            <div id="passed-tests" class="count"></div>
                                            <div class="label">Passed</div>
                                        </div>
                                        <div class="audit-result-box failed">
                                            <div id="failed-tests" class="count"></div>
                                            <div class="label">Failed</div>
                                        </div>
                                        <div class="audit-result-box warnings">
                                            <div id="warning-tests" class="count"></div>
                                            <div class="label">Warnings</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Right Column: SEO Metrics -->
                        <div class="seo-metrics-column">
                            <div class="metrics-grid">
                    <!-- Performance -->
                    <div class="card">
                        <div class="card-header">
                            <div class="card-header-title">
                                <div class="card-header-icon" style="background-color: var(--blue-100);">
                                    <svg style="color: var(--blue-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                                </div>
                                <span class="card-header-text">Brand Performance</span>
                            </div>
                            <span id="performance-score" class="badge badge-performance"></span>
                        </div>
                        <div class="metric-list">
                            <div class="metric-item"><span class="label">Load Time</span><span id="load-time" class="value"></span></div>
                            <div class="metric-item"><span class="label">TTFB</span><span id="ttfb" class="value"></span></div>
                            <div class="metric-item"><span class="label">Page Size</span><span id="page-size" class="value"></span></div>
                        </div>
                        <div class="progress-bar"><div id="performance-progress" class="progress-bar-inner progress-bar-performance"></div></div>
                    </div>
                    
                    <!-- Accessibility -->
                    <div class="card">
                        <div class="card-header">
                            <div class="card-header-title">
                                <div class="card-header-icon" style="background-color: var(--green-100);">
                                    <svg style="color: var(--green-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                                </div>
                                <span class="card-header-text">Brand Accessibility</span>
                            </div>
                            <span id="accessibility-score" class="badge badge-accessibility"></span>
                        </div>
                        <div class="metric-list">
                            <div class="metric-item"><span class="label">DOM Size</span><span id="dom-size" class="value"></span></div>
                            <div class="metric-item"><span class="label">Word Count</span><span id="word-count" class="value"></span></div>
                            <div class="metric-item"><span class="label">Text/HTML Ratio</span><span id="text-html-ratio" class="value"></span></div>
                        </div>
                        <div class="progress-bar"><div id="accessibility-progress" class="progress-bar-inner progress-bar-accessibility"></div></div>
                    </div>
                    
                    <!-- Best Practices -->
                    <div class="card">
                        <div class="card-header">
                            <div class="card-header-title">
                                <div class="card-header-icon" style="background-color: var(--purple-100);">
                                    <svg style="color: var(--purple-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                </div>
                                <span class="card-header-text">Best Practices</span>
                            </div>
                            <span id="best-practices-score" class="badge badge-practices"></span>
                        </div>
                        <div class="metric-list">
                            <div class="metric-item"><span class="label">HTTPS</span><span id="https-status" class="value"></span></div>
                            <div class="metric-item"><span class="label">Meta Description</span><span id="meta-desc-status" class="value"></span></div>
                            <div class="metric-item"><span class="label">Title</span><span id="title-status" class="value"></span></div>
                        </div>
                        <div class="progress-bar"><div id="best-practices-progress" class="progress-bar-inner progress-bar-practices"></div></div>
                    </div>
                    
                    <!-- Security -->
                    <div class="card">
                        <div class="card-header">
                            <div class="card-header-title">
                                <div class="card-header-icon" style="background-color: var(--orange-100);">
                                    <svg style="color: var(--orange-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                                </div>
                                <span class="card-header-text">Brand Security</span>
                            </div>
                            <span id="security-badge" class="badge badge-security"></span>
                        </div>
                        <div class="metric-list">
                            <div class="metric-item"><span class="label">SSL Certificate</span><span id="ssl-status" class="value"></span></div>
                            <div class="metric-item"><span class="label">HTTP Requests</span><span id="http-requests" class="value"></span></div>
                            <div class="metric-item"><span class="label">Download Speed</span><span id="download-speed" class="value"></span></div>
                        </div>
                        <div class="progress-bar"><div id="security-progress" class="progress-bar-inner progress-bar-security"></div></div>
                    </div>
                            </div>
                        </div>
                    </div>

                    <!-- Upgrade Card -->
                    <div class="upgrade-card-wrapper" style="display: none;">
                        <div class="upgrade-card">
                            <div class="upgrade-card-header">
                                <div class="upgrade-card-logo">
                                    <img src="<?php echo NUHELLO_PLUGIN_URL . 'assets/images/favicon-logo.png'; ?>" alt="Nuhello" width="32" height="32">
                                </div>
                                <div class="upgrade-card-title">
                                    <h3>Upgrade your nuhello experience</h3>
                                    <p>Unlock advanced features and grow your business faster</p>
                                </div>
                            </div>
                            <div class="upgrade-card-features">
                                <div class="feature-column">
                                    <div class="feature-item">
                                        <span class="feature-check">✓</span>
                                        <span>Resolve support and sales queries with AI chatbots</span>
                                    </div>
                                    <div class="feature-item">
                                        <span class="feature-check">✓</span>
                                        <span>Rank higher on search engines with AI SEO insights</span>
                                    </div>
                                    <div class="feature-item">
                                        <span class="feature-check">✓</span>
                                        <span>Improve customer experiences with behavioural tracking</span>
                                    </div>
                                </div>
                                <div class="feature-column">
                                    <div class="feature-item">
                                        <span class="feature-check">✓</span>
                                        <span>Engage with customers across all platforms with push notifications</span>
                                    </div>
                                    <div class="feature-item">
                                        <span class="feature-check">✓</span>
                                        <span>Grow your business faster with an AI business assistant</span>
                                    </div>
                                    <div class="feature-item">
                                        <span class="feature-check">✓</span>
                                        <span>Get more control with multi-user and white-labeling</span>
                                    </div>
                                </div>
                            </div>
                            <div class="upgrade-card-cta">
                                <button id="upgrade-plan-btn" class="upgrade-btn">
                                    <span>Upgrade Now</span>
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M5 12h14M12 5l7 7-7 7"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Visits Over Time and Pages row -->
                    <div class="analytics-grid analytics-grid-cols-4">
                        <div class="analytics-col-span-3">
                            <div class="chart-card h-430">
                                <div class="chart-card-header">
                                    <div class="chart-card-icon-wrapper" style="background-color: var(--blue-100);">
                                         <span class="dashicons dashicons-chart-area" style="color: var(--blue-600);"></span>
                                    </div>
                                    <h4 class="chart-card-title">Visits Over Time</h4>
                                </div>
                                <div class="chart-card-body">
                                    <canvas id="visitsOverTimeChart"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="analytics-col-span-1">
                            <div id="devices-card" class="list-card h-430 list-card-blue"></div>
                        </div>
                    </div>

                    <!-- Visitor Locations, OS, and Devices row -->
                    <div class="analytics-grid analytics-grid-cols-4">
                        <div class="analytics-col-span-2">
                            <div class="chart-card h-430">
                                <div class="chart-card-header">
                                    <div class="chart-card-icon-wrapper" style="background-color: var(--green-100);">
                                        <span class="dashicons dashicons-location-alt" style="color: var(--green-600);"></span>
                                    </div>
                                    <h4 class="chart-card-title">Visitor Locations</h4>
                                </div>
                                <div class="chart-card-body">
                                    <canvas id="visitorMapChart"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="analytics-col-span-2">
                            <div id="pages-card" class="list-card h-430 list-card-purple"></div>
                        </div>
                    </div>

                    <!-- Browsers, Countries, Screen Resolutions, Browser Languages -->
                    <div class="analytics-grid analytics-grid-cols-4">
                        <div class="analytics-col-span-1">
                            <div id="browsers-card" class="list-card h-430 list-card-blue"></div>
                        </div>
                        <div class="analytics-col-span-1">
                            <div id="countries-card" class="list-card h-430 list-card-green"></div>
                        </div>
                        <div class="analytics-col-span-1">
                            <div id="resolutions-card" class="list-card h-430 list-card-red"></div>
                        </div>
                        <div class="analytics-col-span-1">
                            <div id="languages-card" class="list-card h-430 list-card-purple"></div>
                        </div>
                    </div>

                    <!-- Referrers, UTM -->
                    <div class="analytics-grid analytics-grid-cols-12">
                        <div class="analytics-col-span-3">
                            <div id="os-card" class="list-card h-430 list-card-red"></div>
                        </div>
                        <div class="analytics-col-span-3">
                            <div id="referrers-card" class="list-card h-430 list-card-blue"></div>
                        </div>
                        <div class="analytics-col-span-6">
                            <div id="utm-card" class="list-card h-430 list-card-green"></div>
                        </div>
                    </div>

            </div>
        </div>
    </div>
</div>

