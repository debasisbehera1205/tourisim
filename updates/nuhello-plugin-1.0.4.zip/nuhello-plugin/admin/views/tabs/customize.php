<?php
/**
 * Customize Tab View
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

$utils = new Nuhello_Utils();
$website = $utils->get_saved_website_details();
$chatbot_id = $website['chatbot_id'] ?? '';
$auth_token = get_option('nuhello_auth_token', '');
$org_id = $website['organization_id'] ?? '';

// Get current chatbot settings (you might want to fetch these from API)
$current_settings = get_option('nuhello_chatbot_settings', array());
?>

<div class="dashboard-layout">
    <!-- Single Header for Both Panels -->
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-admin-appearance"></i> Chatbot Customization</h2>
            <p class="header-description">Customize your chatbot's appearance and behavior to match your brand</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <button type="button" id="save-settings" class="nuhello-btn nuhello-btn-sm nuhello-btn-primary">
                    <i class="dashicons dashicons-saved"></i> Save Changes
                </button>
                <button type="button" id="refresh-preview" class="nuhello-btn nuhello-btn-sm nuhello-btn-outline">
                    <i class="dashicons dashicons-update"></i> Refresh Preview
                </button>
            </div>
        </div>
    </div>

    <div id="nuhello-customize-loading" hidden>
        <?php
            $inline = true;
            $loader_id = '';
            include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
        ?>
    </div>

    <!-- Content Row -->
    <div class="content-row">
        <!-- Left Side - Customization Form -->
        <div class="dashboard-left">
        <div class="settings-panel">
            
            <form id="chatbot-customize-form">
                <?php wp_nonce_field('nuhello_customize_nonce', 'nuhello_customize_nonce'); ?>
                <input type="hidden" id="auth-token" value="<?php echo esc_attr($auth_token); ?>">
                <input type="hidden" id="org-id" value="<?php echo esc_attr($org_id); ?>">
                <input type="hidden" id="bot-id" value="<?php echo esc_attr($chatbot_id); ?>">
                
                <details class="nuhello-accordion-item" open>
                    <summary class="nuhello-accordion-header">
                        <div class="nuhello-accordion-title">
                            <i class="dashicons dashicons-admin-generic"></i>
                            <div>
                                <h3>Basic Settings</h3>
                                <p class="section-description">Configure the fundamental chatbot settings.</p>
                            </div>
                        </div>
                        <span class="nuhello-accordion-chevron" aria-hidden="true"></span>
                    </summary>
                    <div class="nuhello-accordion-body">
                        <div class="form-grid">
                        <div class="setting-item">
                            <label for="display-name">Bot Name</label>
                            <div class="field-wrapper">
                                <input type="text" id="display-name" name="displayName" value="<?php echo esc_attr($current_settings['displayName'] ?? 'Nuhello Assistant'); ?>" placeholder="Enter bot name">
                                <small class="field-description">This will be visible on the chat widget's main page</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="initial-message">Welcome Message</label>
                            <div class="field-wrapper">
                                <textarea id="initial-message" name="initialMessage" rows="3" placeholder="Enter welcome message"><?php echo $current_settings['initialMessage'] ?? 'Welcome to our service! How can I help you today?'; ?></textarea>
                                <small class="field-description">This is the first message users will see when they open the chat</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="input-placeholder">Input Placeholder</label>
                            <div class="field-wrapper">
                                <input type="text" id="input-placeholder" name="inputPlaceholderText" value="<?php echo esc_attr($current_settings['inputPlaceholderText'] ?? 'Type your message here...'); ?>" placeholder="Enter placeholder text">
                                <small class="field-description">This text appears in the input field before the user types</small>
                            </div>
                        </div>
                    </div>
                </div>
            </details>
            
            <details class="nuhello-accordion-item">
                <summary class="nuhello-accordion-header">
                    <div class="nuhello-accordion-title">
                        <i class="dashicons dashicons-admin-appearance"></i>
                        <div>
                            <h3>Appearance</h3>
                            <p class="section-description">Customize the visual appearance of your chatbot.</p>
                        </div>
                    </div>
                    <span class="nuhello-accordion-chevron" aria-hidden="true"></span>
                </summary>
                <div class="nuhello-accordion-body">
                    <div class="form-grid">
                        <div class="setting-item">
                            <label for="accent-color">Accent Color</label>
                            <div class="field-wrapper">
                                <div class="color-input-wrapper">
                                    <input type="color" id="accent-color" name="accentColor" value="<?php echo esc_attr($current_settings['accentColor'] ?? '#50bc39'); ?>">
                                    <span class="color-value"><?php echo esc_attr($current_settings['accentColor'] ?? '#50bc39'); ?></span>
                                </div>
                                <small class="field-description">Primary color for buttons and highlights</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="chatbot-profile-image">Bot Logo</label>
                            <div class="field-wrapper">
                                <div class="image-input-wrapper">
                                    <input type="url" id="chatbot-profile-image" name="chatbotProfileImage" value="<?php echo esc_attr($current_settings['chatbotProfileImage'] ?? 'https://nuhello.nyc3.digitaloceanspaces.com/development/images/1755084929496-nuhelloapp.com.ico.png'); ?>" placeholder="Enter image URL">
                                    <div class="image-preview" id="chatbot-profile-preview">
                                        <img src="<?php echo esc_attr($current_settings['chatbotProfileImage'] ?? 'https://nuhello.nyc3.digitaloceanspaces.com/development/images/1755084929496-nuhelloapp.com.ico.png'); ?>" alt="Bot Logo Preview" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                        <div class="image-placeholder" style="display: none;">
                                            <i class="dashicons dashicons-format-image"></i>
                                            <span>No image</span>
                                        </div>
                                    </div>
                                </div>
                                <small class="field-description">Avatar image for your chatbot</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="logo-size">Logo Size</label>
                            <div class="field-wrapper">
                                <select id="logo-size" name="logoSize">
                                    <option value="small" <?php selected($current_settings['logoSize'] ?? 'small', 'small'); ?>>Small</option>
                                    <option value="medium" <?php selected($current_settings['logoSize'] ?? 'small', 'medium'); ?>>Medium</option>
                                    <option value="large" <?php selected($current_settings['logoSize'] ?? 'small', 'large'); ?>>Large</option>
                                </select>
                                <small class="field-description">Size of the chatbot logo</small>
                            </div>
                        </div>
                        
                        <div class="setting-item checkbox-item">
                            <label for="show-logo-border">Show Logo Border</label>
                            <div class="field-wrapper">
                                <label class="checkbox-label">
                                    <input type="checkbox" id="show-logo-border" name="showLogoBorder" <?php checked($current_settings['showLogoBorder'] ?? true, true); ?>>
                                    <span class="checkmark"></span>
                                    Add a border around the chatbot logo
                                </label>
                                <small class="field-description">Add a border around the chatbot logo</small>
                            </div>
                        </div>
                    </div>
                </div>
            </details>

            <details class="nuhello-accordion-item">
                <summary class="nuhello-accordion-header">
                    <div class="nuhello-accordion-title">
                        <i class="dashicons dashicons-art"></i>
                        <div>
                            <h3>Message Colors</h3>
                            <p class="section-description">Define the color scheme for user and AI messages.</p>
                        </div>
                    </div>
                    <span class="nuhello-accordion-chevron" aria-hidden="true"></span>
                </summary>
                <div class="nuhello-accordion-body">
                    <div class="form-grid form-grid-3">
                        <div class="setting-item">
                            <label for="user-msg-bg-color">User Message Color</label>
                            <div class="field-wrapper">
                                <div class="color-input-wrapper">
                                    <input type="color" id="user-msg-bg-color" name="userMsgBgColor" value="<?php echo esc_attr($current_settings['userMsgBgColor'] ?? '#1d1526'); ?>">
                                    <span class="color-value"><?php echo esc_attr($current_settings['userMsgBgColor'] ?? '#1d1526'); ?></span>
                                </div>
                                <small class="field-description">Background color for user messages</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="ai-msg-bg-color">AI Message Color</label>
                            <div class="field-wrapper">
                                <div class="color-input-wrapper">
                                    <input type="color" id="ai-msg-bg-color" name="aiMsgBgColor" value="<?php echo esc_attr($current_settings['aiMsgBgColor'] ?? '#d6e0d5'); ?>">
                                    <span class="color-value"><?php echo esc_attr($current_settings['aiMsgBgColor'] ?? '#d6e0d5'); ?></span>
                                </div>
                                <small class="field-description">Background color for AI messages</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="chat-icon-bg-color">Chat Icon Background</label>
                            <div class="field-wrapper">
                                <div class="color-input-wrapper">
                                    <input type="color" id="chat-icon-bg-color" name="chatIconBgColor" value="<?php echo esc_attr($current_settings['chatIconBgColor'] ?? '#8e8794'); ?>">
                                    <span class="color-value"><?php echo esc_attr($current_settings['chatIconBgColor'] ?? '#8e8794'); ?></span>
                                </div>
                                <small class="field-description">Background color for the chat icon</small>
                            </div>
                        </div>
                    </div>
                </div>
            </details>

                <details class="nuhello-accordion-item">
                    <summary class="nuhello-accordion-header">
                        <div class="nuhello-accordion-title">
                            <i class="dashicons dashicons-format-chat"></i>
                            <div>
                                <h3>Chat Icon & Welcome</h3>
                                <p class="section-description">Configure the chat entry icon and welcome experience.</p>
                            </div>
                        </div>
                        <span class="nuhello-accordion-chevron" aria-hidden="true"></span>
                    </summary>
                    <div class="nuhello-accordion-body">
                        <div class="form-grid">
                        <div class="setting-item">
                            <label for="chat-icon">Chat Icon</label>
                            <div class="field-wrapper">
                                <div class="image-input-wrapper">
                                    <input type="url" id="chat-icon" name="chatIcon" value="<?php echo esc_attr($current_settings['chatIcon'] ?? 'https://nuhello.nyc3.digitaloceanspaces.com/development/images/1755084929496-nuhelloapp.com.ico.png'); ?>" placeholder="Enter icon URL">
                                    <div class="image-preview" id="chat-icon-preview">
                                        <img src="<?php echo esc_attr($current_settings['chatIcon'] ?? 'https://nuhello.nyc3.digitaloceanspaces.com/development/images/1755084929496-nuhelloapp.com.ico.png'); ?>" alt="Chat Icon Preview" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                        <div class="image-placeholder" style="display: none;">
                                            <i class="dashicons dashicons-format-image"></i>
                                            <span>No image</span>
                                        </div>
                                    </div>
                                </div>
                                <small class="field-description">Icon shown in the chat widget</small>
                            </div>
                        </div>
                        
                        <div class="setting-item checkbox-item">
                            <label for="welcome-msg-flag">Enable Welcome Popup</label>
                            <div class="field-wrapper">
                                <label class="checkbox-label">
                                    <input type="checkbox" id="welcome-msg-flag" name="welcomeMsgFlag" <?php checked($current_settings['welcomeMsgFlag'] ?? true, true); ?>>
                                    <span class="checkmark"></span>
                                    Show a welcome popup when chat opens
                                </label>
                                <small class="field-description">Show a welcome popup when chat opens</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="welcome-msg">Popup Message</label>
                            <div class="field-wrapper">
                                <textarea id="welcome-msg" name="welcomeMsg" rows="3" placeholder="Enter popup message"><?php echo $current_settings['welcomeMsg'] ?? "Hi there! I'm here to assist you. What can I do for you today?"; ?></textarea>
                                <small class="field-description">Message shown in the welcome popup</small>
                            </div>
                        </div>
                    </div>
                </div>
            </details>

            <details class="nuhello-accordion-item">
                <summary class="nuhello-accordion-header">
                    <div class="nuhello-accordion-title">
                        <i class="dashicons dashicons-format-quote"></i>
                        <div>
                            <h3>Text & Labels</h3>
                            <p class="section-description">Customize text labels and quick reply options.</p>
                        </div>
                    </div>
                    <span class="nuhello-accordion-chevron" aria-hidden="true"></span>
                </summary>
                <div class="nuhello-accordion-body">
                    <div class="form-grid">
                        <div class="setting-item">
                            <label for="quick-replies">Quick Actions and Replies</label>
                            <div class="field-wrapper">
                                <input type="text" id="quick-replies" name="quickReplies" value="<?php echo esc_attr($current_settings['quickReplies'] ?? 'Help,Contact Support,FAQ'); ?>" placeholder="Help,Contact Support,FAQ">
                                <small class="field-description">Enter quick action options separated by commas (,)</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="header-text">Header Text</label>
                            <div class="field-wrapper">
                                <input type="text" id="header-text" name="headerText" value="<?php echo esc_attr($current_settings['headerText'] ?? 'Hi there 👋, how can we help?'); ?>" placeholder="Enter header text">
                                <small class="field-description">Main header text in the chat window</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="assistant-text">Assistant Text</label>
                            <div class="field-wrapper">
                                <input type="text" id="assistant-text" name="assistantText" value="<?php echo esc_attr($current_settings['assistantText'] ?? 'I am here to assist you with your queries.'); ?>" placeholder="Enter assistant text">
                                <small class="field-description">This is the text displayed about the assistant</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="link-label">Link Label</label>
                            <div class="field-wrapper">
                                <input type="text" id="link-label" name="linkLabel" value="<?php echo esc_attr($current_settings['linkLabel'] ?? 'Chat with us'); ?>" placeholder="Enter link label">
                                <small class="field-description">Text for chat link button</small>
                            </div>
                        </div>
                        
                        <div class="setting-item">
                            <label for="tooltip-label">Popup Button Text</label>
                            <div class="field-wrapper">
                                <input type="text" id="tooltip-label" name="toolTipLabel" value="<?php echo esc_attr($current_settings['toolTipLabel'] ?? 'Let\'s Chat'); ?>" placeholder="Enter popup button text">
                                <small class="field-description">What text should appear on the popup button?</small>
                            </div>
                        </div>
                    </div>
                </div>
            </details>

            </form>
        </div>
    </div>

    <!-- Right Side - Live Preview -->
    <div class="dashboard-right">
        <div class="widget-panel">
            <div class="widget-container">
                <div id="preview-container" class="preview-container">
                    <?php if (!empty($chatbot_id)): ?>
                        <iframe id="bot-preview" src="<?= NUHELLO_FRONT_URL ?>/live?onLoadShowBot=true&botId=<?php echo esc_attr($chatbot_id); ?>" frameborder="0"></iframe>
                    <?php else: ?>
                        <div class="preview-placeholder">
                        <i class="dashicons dashicons-admin-appearance"></i>
                            <h3>No Chatbot Selected</h3>
                            <p>Please select a chatbot in the Configuration tab to see the live preview.</p>
                            <div class="preview-actions">
                                <a href="?page=nuhello-dashboard&tab=configuration" class="nuhello-btn nuhello-btn-primary">
                                    <i class="dashicons dashicons-admin-settings"></i> Go to Configuration
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

<div id="nuhello-customize-notifications" class="nuhello-notifications"></div> 