<?php
/**
 * Onboarding Wizard Handler
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Onboarding {
    
    public function __construct() {
        // Constructor for future initialization if needed
    }
    
    /**
     * Render onboarding wizard
     */
    public function render() {
        $current_user = wp_get_current_user();
        $user_email = $current_user->user_email;
        $current_url = admin_url('admin.php?page=nuhello-onboarding');
        $registration_url = 'https://nuhelloapp.com/registration-cfwpr/?url=' . $current_url;

        // Check if auth token already exists (user has already verified OTP or validated session)
        $existing_auth_token = get_option('nuhello_auth_token', '');
        $has_auth_token = !empty($existing_auth_token);
        
        // Check for registration return parameters (from registration link)
        $identifier = isset($_GET['identifier']) ? sanitize_text_field($_GET['identifier']) : '';
        $url_email = isset($_GET['email']) ? sanitize_email($_GET['email']) : '';
        $url_key = isset($_GET['NUHELLO_WPKEY']) ? sanitize_text_field($_GET['NUHELLO_WPKEY']) : '';
        
        $registration_email = '';
        $registration_key = '';
        
        if (!empty($identifier)) {
            // Decode identifier parameter (base64 encoded email+key)
            $decoded_identifier = base64_decode($identifier);
            $identifier_data = json_decode($decoded_identifier, true);
            if (is_array($identifier_data)) {
                $registration_email = isset($identifier_data['email']) ? sanitize_email($identifier_data['email']) : '';
                $registration_key = isset($identifier_data['key']) ? sanitize_text_field($identifier_data['key']) : '';
            }
        } elseif (!empty($url_email) && !empty($url_key)) {
            // Direct URL parameters (email and NUHELLO_WPKEY)
            $registration_email = $url_email;
            $registration_key = $url_key;
        }
        
        // Check for existing registration session
        $stored_registration_email = get_option('nuhello_registration_email', '');
        $stored_registration_key = get_option('nuhello_registration_key', '');
        $stored_registration_timestamp = get_option('nuhello_registration_timestamp', 0);
        
        // Calculate remaining time (15 minutes = 900 seconds)
        $remaining_time = 0;
        if ($stored_registration_timestamp > 0) {
            $elapsed = time() - $stored_registration_timestamp;
            $remaining_time = max(0, 900 - $elapsed); // 15 minutes in seconds
        }
        
        include NUHELLO_PLUGIN_PATH . 'admin/views/onboarding-wizard.php';

        // Only reset options if onboarding is being explicitly restarted (not if auth token exists)
        // If auth token exists, user has already verified, so preserve their progress
        if (!$has_auth_token) {
            // Only reset if no auth token exists (first time or restarting)
            update_option('nuhello_onboarding_completed', false);
            delete_option('nuhello_website_details');
            update_option('nuhello_environment', 'testing');
            delete_option('nuhello_testing_url');
            delete_option('nuhello_production_url');
            delete_option('nuhello_testing_default');
            delete_option('nuhello_production_default');
            delete_option('nuhello_pixel_key');
            delete_option('nuhello_chatbot_email');
            update_option('nuhello_display_chatbot', true);
            update_option('nuhello_show_all_pages', true);
            update_option('nuhello_enable_analytics', true);
            update_option('nuhello_enable_notifications', true);
            delete_option('nuhello_enable_email_validation');
            delete_option('nuhello_email_validation_allowed_statuses');
            delete_option('nuhello_email_validation_allowed_safe_to_send');
            delete_option('nuhello_email_validation_blocked_types');
            delete_option('nuhello_email_validation_error_message');
        }

        //For test purpose by default set the variables
        // add_option('nuhello_auth_token', 'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2N2NkNjc3NjQ3ZTZlNjdhYzQ1YzZmZSIsInJvbGVzIjpbIklORElWSURVQUwiLCJTVUJTQ1JJQkVSIl0sImlhdCI6MTc2Nzk3NjQ1OCwiZXhwIjoyNjMxOTc2NDU4fQ.xGBM4kC-D89ulxqkw-lW_35yrPFS9S4Vmho8avDkirXjD3lT5zXBJwcyVP0DJ3kh3zxUGzwnk1vtMc3J-p13lQ');
        // add_option('nuhello_onboarding_completed', 1);
        // add_option('nuhello_environment', 'testing');
        // add_option('nuhello_testing_url', '');
        // add_option('nuhello_production_url', '');
        // add_option('nuhello_testing_default', true);
        // add_option('nuhello_production_default', false);
        // add_option('nuhello_display_chatbot', true);
        // add_option('nuhello_show_all_pages', true);
        // add_option('nuhello_enable_analytics', true);
        // add_option('nuhello_enable_notifications', true);
    }
} 