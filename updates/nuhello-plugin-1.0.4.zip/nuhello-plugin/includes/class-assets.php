<?php
/**
 * Assets Handler
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Assets {
    
    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_nuhello-dashboard') {
            return;
        }

        $current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';

        $this->enqueue_base_assets();
        $this->enqueue_tab_assets($current_tab);
        // $this->enqueue_shared_assets();
        $this->enqueue_select2_assets();
        $this->enqueue_localized_data();
        $this->enqueue_email_verification_assets();
    }

    private function enqueue_base_assets() {
        wp_enqueue_script(
            'nuhello-admin-js',
            NUHELLO_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_style(
            'nuhello-admin-css',
            NUHELLO_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_style(
            'nuhello-layout-css',
            NUHELLO_PLUGIN_URL . 'assets/css/layout.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        $this->enqueue_upgrade_plan_modal_assets();
    }

    private function enqueue_tab_assets($current_tab) {
        if ($current_tab == 'dashboard') {
            $this->enqueue_dashboard_assets();
        }

        if ($current_tab == 'customize') {
            $this->enqueue_customize_assets();
        }

        if ($current_tab == 'configuration') {
            $this->enqueue_configuration_assets();
        }

        if ($current_tab === 'seo') {
            $this->enqueue_seo_assets();
        }

        if ($current_tab === 'message-desk') {
            $this->enqueue_message_desk_assets();
        }
    }

    private function enqueue_dashboard_assets() {
        wp_enqueue_style(
            'nuhello-dashboard-css',
            NUHELLO_PLUGIN_URL . 'assets/css/dashboard.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_style(
            'nuhello-analytics-css',
            NUHELLO_PLUGIN_URL . 'assets/css/analytics.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'nuhello-dashboard-utils-js',
            NUHELLO_PLUGIN_URL . 'assets/js/dashboard/utils.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-dashboard-analytics-js',
            NUHELLO_PLUGIN_URL . 'assets/js/dashboard/analytics.js',
            array('jquery', 'nuhello-dashboard-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-dashboard-seo-js',
            NUHELLO_PLUGIN_URL . 'assets/js/dashboard/seo.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-dashboard-tickets-js',
            NUHELLO_PLUGIN_URL . 'assets/js/dashboard/tickets.js',
            array('jquery', 'nuhello-dashboard-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-dashboard-core-js',
            NUHELLO_PLUGIN_URL . 'assets/js/dashboard/core.js',
            array(
                'jquery',
                'nuhello-dashboard-analytics-js',
                'nuhello-dashboard-seo-js',
                'nuhello-dashboard-tickets-js'
            ),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-dashboard-js',
            NUHELLO_PLUGIN_URL . 'assets/js/dashboard.js',
            array('jquery', 'nuhello-dashboard-core-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );
    }

    private function enqueue_customize_assets() {
        wp_enqueue_style(
            'nuhello-customize-css',
            NUHELLO_PLUGIN_URL . 'assets/css/customize.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );
        wp_enqueue_script(
            'nuhello-customize-js',
            NUHELLO_PLUGIN_URL . 'assets/js/customize.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );
    }

    private function enqueue_configuration_assets() {
        wp_enqueue_style(
            'nuhello-configuration-css',
            NUHELLO_PLUGIN_URL . 'assets/css/configuration.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );
    }

    private function enqueue_seo_assets() {
        wp_enqueue_style(
            'nuhello-seo-css',
            NUHELLO_PLUGIN_URL . 'assets/css/seo.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'nuhello-seo-utils-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/utils.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-detail-header-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/details/header.js',
            array('jquery', 'nuhello-seo-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-detail-basic-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/details/basic-document-setup.js',
            array('jquery', 'nuhello-seo-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-detail-on-page-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/details/on-page-seo.js',
            array('jquery', 'nuhello-seo-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-detail-technical-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/details/technical-performance.js',
            array('jquery', 'nuhello-seo-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-detail-content-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/details/content-quality.js',
            array('jquery', 'nuhello-seo-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-detail-links-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/details/links-analysis.js',
            array('jquery', 'nuhello-seo-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-detail-social-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/details/social-links.js',
            array('jquery', 'nuhello-seo-utils-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-recommendations-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/recommendations.js',
            array(
                'jquery',
                'nuhello-seo-utils-js',
                'nuhello-seo-detail-header-js',
                'nuhello-seo-detail-basic-js',
                'nuhello-seo-detail-on-page-js',
                'nuhello-seo-detail-technical-js',
                'nuhello-seo-detail-content-js',
                'nuhello-seo-detail-links-js',
                'nuhello-seo-detail-social-js'
            ),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-audit-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo/audit.js',
            array('jquery', 'nuhello-seo-utils-js', 'nuhello-seo-recommendations-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'nuhello-seo-js',
            NUHELLO_PLUGIN_URL . 'assets/js/seo.js',
            array('jquery', 'nuhello-seo-audit-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );
    }

    private function enqueue_message_desk_assets() {
        wp_enqueue_style(
            'nuhello-message-desk-css',
            NUHELLO_PLUGIN_URL . 'assets/css/message-desk.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : '';

        if ($view === 'ticket') {
            wp_enqueue_style(
                'nuhello-message-desk-ticket-css',
                NUHELLO_PLUGIN_URL . 'assets/css/message-desk-ticket.css',
                array('nuhello-message-desk-css'),
                NUHELLO_PLUGIN_VERSION
            );
            wp_enqueue_script(
                'nuhello-message-desk-ticket-js',
                NUHELLO_PLUGIN_URL . 'assets/js/message-desk-ticket.js',
                array('jquery'),
                NUHELLO_PLUGIN_VERSION,
                true
            );
            return;
        }

        if ($view === 'message') {
            wp_enqueue_style(
                'nuhello-message-desk-message-css',
                NUHELLO_PLUGIN_URL . 'assets/css/message-desk-message.css',
                array('nuhello-message-desk-css'),
                NUHELLO_PLUGIN_VERSION
            );
            wp_enqueue_script(
                'nuhello-message-desk-message-js',
                NUHELLO_PLUGIN_URL . 'assets/js/message-desk-message.js',
                array('jquery'),
                NUHELLO_PLUGIN_VERSION,
                true
            );
            return;
        }

        if ($view === 'lead') {
            wp_enqueue_style(
                'nuhello-message-desk-lead-css',
                NUHELLO_PLUGIN_URL . 'assets/css/message-desk-lead.css',
                array('nuhello-message-desk-css'),
                NUHELLO_PLUGIN_VERSION
            );
            wp_enqueue_script(
                'nuhello-message-desk-lead-js',
                NUHELLO_PLUGIN_URL . 'assets/js/message-desk-lead.js',
                array('jquery'),
                NUHELLO_PLUGIN_VERSION,
                true
            );
            return;
        }

        wp_enqueue_script(
            'nuhello-message-desk-js',
            NUHELLO_PLUGIN_URL . 'assets/js/message-desk.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );
    }

    private function enqueue_upgrade_plan_modal_assets() {
        wp_enqueue_style(
            'nuhello-upgrade-plan-modal-css',
            NUHELLO_PLUGIN_URL . 'assets/css/upgrade-plan-modal.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'nuhello-upgrade-plan-modal-js',
            NUHELLO_PLUGIN_URL . 'assets/js/upgrade-plan-modal.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );
    }

    private function enqueue_shared_assets() {
        wp_enqueue_script(
            'nuhello-analytics-js',
            NUHELLO_PLUGIN_URL . 'assets/js/analytics.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_style(
            'nuhello-analytics-css',
            NUHELLO_PLUGIN_URL . 'assets/css/analytics.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_style(
            'nuhello-notifications-css',
            NUHELLO_PLUGIN_URL . 'assets/css/notifications.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'nuhello-notifications-js',
            NUHELLO_PLUGIN_URL . 'assets/js/notifications.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_style(
            'nuhello-campaigns-css',
            NUHELLO_PLUGIN_URL . 'assets/css/campaigns.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'nuhello-campaigns-js',
            NUHELLO_PLUGIN_URL . 'assets/js/campaigns.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_style(
            'nuhello-customize-campaign-css',
            NUHELLO_PLUGIN_URL . 'assets/css/customize-campaign.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'nuhello-customize-campaign-js',
            NUHELLO_PLUGIN_URL . 'assets/js/customize-campaign.js',
            array('jquery', 'select2-js'),
            NUHELLO_PLUGIN_VERSION,
            true
        );
    }

    private function enqueue_select2_assets() {
        // Enqueue Select2 from CDN
        wp_enqueue_style(
            'select2-css',
            'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css',
            array(),
            '4.0.13'
        );

        wp_enqueue_script(
            'select2-js',
            'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.full.min.js',
            array('jquery'),
            '4.0.13',
            true
        );
    }

    private function enqueue_localized_data() {
        wp_localize_script('nuhello-admin-js', 'nuhello_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nuhello_nonce'),
            'config_nonce' => wp_create_nonce('nuhello_configuration_nonce'),
            'customize_nonce' => wp_create_nonce('nuhello_customize_nonce'),
            'notification_nonce' => wp_create_nonce('nuhello_notification_nonce')
        ));

        wp_localize_script('nuhello-customize-js', 'nuhello_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nuhello_nonce'),
            'config_nonce' => wp_create_nonce('nuhello_configuration_nonce'),
            'customize_nonce' => wp_create_nonce('nuhello_customize_nonce')
        ));

        wp_localize_script('nuhello-campaigns-js', 'nuhello_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nuhello_nonce')
        ));

        wp_localize_script('nuhello-analytics-js', 'nuhello_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nuhello_nonce')
        ));

        wp_localize_script('nuhello-customize-campaign-js', 'nuhello_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nuhello_nonce')
        ));
    }

    private function enqueue_email_verification_assets() {
        // Email verification assets
        wp_enqueue_style(
            'nuhello-email-verification-css',
            NUHELLO_PLUGIN_URL . 'assets/css/email-verification.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'nuhello-email-verification-js',
            NUHELLO_PLUGIN_URL . 'assets/js/email-verification.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );

        wp_localize_script('nuhello-email-verification-js', 'nuhello_email_verification_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nuhello_nonce'),
            // re-use some settings if needed
        ));
    }
}