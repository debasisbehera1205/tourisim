(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.details = Seo.details || {};
    Seo.state = Seo.state || {
        originalRecommendations: [],
        allAudits: [],
        shouldScrollToTabs: false
    };

    Seo.details.renderAuditDetailsHeader = function(auditItem, container) {
        const audit = auditItem.auditData;
        const score = audit.score || 0;

        const getScoreLabel = (scoreValue) => {
            if (scoreValue >= 80) return 'Good';
            if (scoreValue >= 50) return 'Average';
            return 'Poor';
        };

        const getScoreStrokeColor = (scoreValue) => {
            if (scoreValue >= 80) return 'var(--green-500)';
            if (scoreValue >= 50) return 'var(--orange-500)';
            return 'var(--red-600)';
        };

        const getHealthIcon = (scoreValue) => {
            const iconClass = scoreValue >= 80 ? 'dashicons-yes-alt' : scoreValue >= 60 ? 'dashicons-warning' : 'dashicons-no';
            const color = scoreValue >= 80 ? 'var(--green-500)' : scoreValue >= 60 ? 'var(--orange-500)' : 'var(--red-600)';
            return $('<span>').addClass(`dashicons ${iconClass}`).css('color', color);
        };

        const host = audit.data?.parsed_url?.host || new URL(audit.url).host;
        const faviconSrc = audit.data?.favicon || `https://www.google.com/s2/favicons?domain=${audit.url}`;

        Seo.utils.fetchTemplate('audit-details-header', function(response) {
            const $loader = $('#audit-details-loader');
            if ($loader.length) {
                $loader.remove();
            }

            const $auditHeader = $(response.data);
            $auditHeader.find('.audit-header-title').text(`SEO Audit Report - ${host}`);
            $auditHeader.find('.audit-header-favicon').attr({ src: faviconSrc, alt: 'Site favicon' });
            $auditHeader.find('.audit-header-url').text(audit.url);
            $auditHeader.find('.audit-header-date').text(`Date: ${new Date(auditItem.auditDate).toLocaleDateString()}`);
            $auditHeader.find('.audit-header-health-status').append(getHealthIcon(score), getScoreLabel(score));

            const circumference = 2 * Math.PI * 45;
            const offset = circumference - (score / 100) * circumference;
            const $circleFg = $auditHeader.find('.audit-header-score-circle-fg');
            $circleFg.attr({ 'stroke-dasharray': circumference, 'stroke-dashoffset': offset });
            $circleFg.css('stroke', getScoreStrokeColor(score));
            $auditHeader.find('.audit-header-score-text').text(`${score}/100`);

            const passedTests = audit.passed_tests || 0;
            const totalTests = audit.total_tests || 1;
            const majorIssues = audit.issues?.potential_major_issues || 0;
            const moderateIssues = audit.issues?.potential_moderate_issues || 0;
            const minorIssues = audit.issues?.potential_minor_issues || 0;

            $auditHeader.find('.audit-header-progress-bar-healthy').css('width', `${(passedTests / totalTests) * 100}%`);
            $auditHeader.find('.audit-header-progress-bar-major').css('width', `${(majorIssues / totalTests) * 100}%`);
            $auditHeader.find('.audit-header-progress-bar-moderate').css('width', `${(moderateIssues / totalTests) * 100}%`);
            $auditHeader.find('.audit-header-progress-bar-minor').css('width', `${(minorIssues / totalTests) * 100}%`);

            $auditHeader.find('.audit-header-legend-healthy').text(`Healthy (${passedTests})`);
            $auditHeader.find('.audit-header-legend-major').text(`Major (${majorIssues})`);
            $auditHeader.find('.audit-header-legend-moderate').text(`Moderate (${moderateIssues})`);
            $auditHeader.find('.audit-header-legend-minor').text(`Minor (${minorIssues})`);

            const totalIssues = audit.total_issues || 0;
            const recommendationsCount = (audit.total_tests || 0) - (audit.passed_tests || 0);
            const httpRequests = audit.data?.http_requests || 0;

            $auditHeader.find('.audit-header-stat-value-issues').text(totalIssues);
            $auditHeader.find('.audit-header-stat-value-recs').text(recommendationsCount);
            $auditHeader.find('.audit-header-stat-value-http').text(httpRequests);

            container.append($auditHeader);

            if (Seo.state.shouldScrollToTabs) {
                setTimeout(function() {
                    Seo.utils.scrollToSeoTabsNav();
                    setTimeout(function() {
                        $('#seo-dashboard-loading').hide();
                        $('#seo-dashboard-content').show();
                        Seo.state.shouldScrollToTabs = false;
                    }, 600);
                }, 800);
            }
        });
    };
})(window, jQuery);
