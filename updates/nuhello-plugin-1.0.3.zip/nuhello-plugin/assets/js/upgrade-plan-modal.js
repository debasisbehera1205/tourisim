 (function ($) {
    const defaultModalSelector = "#nuhello-upgrade-modal";
    const openSelector = "[data-upgrade-modal-open], #nuhello-upgrade-open";
 
    const upgradeState = {
        allPlans: [],
        currentPlan: null,
        nextPlan: null,
        currentPlanId: null,
        nextPlanId: null,
        selectedPlanId: null,
        yearly: false,
        selectedCurrency: "USD"
    };
 
    function normalizePayload(response) {
        const base = response && response.success ? response.data : response;
        return base?.payload ?? base?.data ?? base;
    }
 
    function getPlanTypeOld(plan) {
        const raw = plan?.subscriptionType || "".toString().toLowerCase();
        return raw || "monthly";
    }

    function getPlanType(plan) {
        const raw = (plan?.subscriptionType || "").toString().toLowerCase();
        return raw || "monthly";
    }

    function getPlanIdentifier(plan) {
        return plan?._id;
    }

    function getPlanDisplayName(plan) {
        return plan?.name || '';
    }

    function resolveCurrentPlan() {
        if (!upgradeState.allPlans.length) {
            return upgradeState.currentPlan || null;
        }
        if (upgradeState.currentPlanId) {
            const byId = upgradeState.allPlans.find(
                (plan) => getPlanIdentifier(plan) === upgradeState.currentPlanId
            );
            if (byId) return byId;
        }
        return upgradeState.currentPlan || null;
    }

    function extractPlans(payload) {
        if (Array.isArray(payload)) return payload;
        // if (Array.isArray(payload?.plans)) return payload.plans;
        return [];
    }
 
    function normalizePriceAmount(amount) {
        const value = Number(amount);
        if (!Number.isFinite(value)) return null;
        if (value >= 1000) return value / 100;
        return value;
    }

    function formatPlanPrice(amount, currency) {
        const normalized = normalizePriceAmount(amount);
        if (normalized === null) return "—";
         try {
             return new Intl.NumberFormat("en-US", {
                 style: "currency",
                 currency: currency || "USD"
            }).format(normalized);
         } catch (e) {
            return `$${normalized.toFixed(2)}`;
         }
    }
 
    function getPlanBenefits(plan) {
        if (!plan) return [];
        if (Array.isArray(plan.displayBenefits)) {
            return plan.displayBenefits.slice(0, 4);
        }
        return [];
    }
 
    function getAvailablePlans() {
        const currentPlanId = upgradeState.currentPlanId || getPlanIdentifier(upgradeState.currentPlan);
        return upgradeState.allPlans.filter((plan) => {
            const planId = getPlanIdentifier(plan);
            if (plan.isFree) return false;
            if (currentPlanId && planId && planId === currentPlanId) return false;
            const type = getPlanType(plan);
            if (type !== "monthly" && type !== "yearly") return false;
            return upgradeState.yearly ? type === "yearly" : type === "monthly";
        });
    }
 
    function updateUpgradeToggleLabels() {
        $("#nuhello-upgrade-monthly-label").toggleClass("is-active", !upgradeState.yearly);
        $("#nuhello-upgrade-yearly-label").toggleClass("is-active", upgradeState.yearly);
    }
 
    function renderUpgradeBenefits(plan) {
        const benefits = getPlanBenefits(plan);
        const rows = benefits
            .filter((benefit) => benefit && benefit.label && benefit.value)
            .map((benefit) => {
            return `<div class="nuhello-upgrade-benefit"><span>${benefit.label}</span><span>${benefit.value}</span></div>`;
            });
        $("#nuhello-upgrade-benefits").html(rows.join(""));
    }
 
    function renderHighestPlan(plan) {
        const planName = getPlanDisplayName(plan);
        $("#nuhello-upgrade-max-plan").text(planName || "Free");
        const planType = getPlanType(plan);
        if (planType === "yearly" || planType === "monthly") {
            $("#nuhello-upgrade-max-billing")
                .text(planType === "yearly" ? "(Yearly)" : "(Monthly)")
                .removeAttr("hidden");
        } else {
            $("#nuhello-upgrade-max-billing").attr("hidden", "hidden").text("");
        }
        const benefits = getPlanBenefits(plan);
        const rows = benefits
            .filter((benefit) => benefit && benefit.label && benefit.value)
            .map((benefit) => {
                return `<div class="nuhello-upgrade-benefit"><span>${benefit.label}</span><span>${benefit.value}</span></div>`;
            });
        $("#nuhello-upgrade-max-benefits").html(rows.join(""));
    }

    function renderUpgradePrice(plan) {
        const $price = $("#nuhello-upgrade-price");
        if (!plan) {
            $price.text("—");
            return;
        }
        if (plan.isFree) {
            $price.text("Free");
            return;
        }
        const priceEntry = Array.isArray(plan.prices)
            ? plan.prices.find((item) => (item.currency || "").toLowerCase() === upgradeState.selectedCurrency.toLowerCase())
            : null;
        if (!priceEntry) {
            $price.text("—");
            return;
        }
        const period = getPlanType(plan) === "yearly" ? "year" : "month";
        $price.text(`${formatPlanPrice(priceEntry.amount, upgradeState.selectedCurrency)}/${period}`);
    }

    function renderUpgradeSelection() {
        const availablePlans = getAvailablePlans();
        const $select = $("#nuhello-upgrade-plan-select");
        $select.empty();
        $select.append('<option value="">Select a plan</option>');

        const uniquePlans = availablePlans.reduce((acc, plan) => {
            const normalizedName = plan?.normalizedName || "";
            if (!normalizedName) {
                acc.push(plan);
                return acc;
            }
            if (!acc.find((p) => (p?.normalizedName || "") === normalizedName)) {
                acc.push(plan);
            }
            return acc;
        }, []);

        uniquePlans.forEach((plan) => {
            const planId = getPlanIdentifier(plan);
            const typeLabel = getPlanType(plan) === "yearly" ? "Yearly" : "Monthly";
            const planName = getPlanDisplayName(plan);
            const isRecommended = upgradeState.nextPlanId && planId === upgradeState.nextPlanId;
            const recommendedLabel = isRecommended ? " - Recommended" : "";
            $select.append(`<option value="${planId || ""}">${planName} (${typeLabel})${recommendedLabel}</option>`);
        });

        if (!upgradeState.selectedPlanId || !availablePlans.find((plan) => getPlanIdentifier(plan) === upgradeState.selectedPlanId)) {
            if (upgradeState.nextPlanId) {
                const match = availablePlans.find((plan) => getPlanIdentifier(plan) === upgradeState.nextPlanId);
                if (match) {
                    upgradeState.selectedPlanId = getPlanIdentifier(match);
                }
            }
            if (!upgradeState.selectedPlanId && availablePlans.length > 0) {
                upgradeState.selectedPlanId = getPlanIdentifier(availablePlans[0]);
            }
        }
        $select.val(upgradeState.selectedPlanId || "");
        $select.prop("disabled", availablePlans.length === 0);
        if (availablePlans.length === 0) {
            $("#nuhello-upgrade-error")
                .removeAttr("hidden")
                .text("No upgrade plans available at this time.");
        }
        const selectedPlan = upgradeState.selectedPlanId
        ? availablePlans.find((plan) => getPlanIdentifier(plan) === upgradeState.selectedPlanId)
        : null;
        renderUpgradeBenefits(selectedPlan);
        renderUpgradePrice(selectedPlan);
        $("#nuhello-upgrade-change-btn").prop("disabled", !selectedPlan);
    }
 
    function openUpgradeModal($modal, infoMessage) {
        if (!$modal.length) return;

        // Ensure modal isn't inside a hidden tab/container.
        if (!$modal.parent().is('body')) {
            $modal.appendTo(document.body);
        }

        $modal.removeAttr("hidden");
        $("#nuhello-upgrade-loading").removeAttr("hidden");
        $("#nuhello-upgrade-error").attr("hidden", "hidden").text("");
        if (infoMessage) {
            $("#nuhello-upgrade-error").removeAttr("hidden").text(infoMessage);
        }
        $("#nuhello-upgrade-benefits").html("");
        $("#nuhello-upgrade-max-benefits").html("");
        $("#nuhello-upgrade-price").text("—");
        $("#nuhello-upgrade-plan-select").prop("disabled", true).html('<option value="">Loading...</option>');
        $("#nuhello-upgrade-change-btn").prop("disabled", true);
         updateUpgradeToggleLabels();
 
         const pricingRequest = $.ajax({
             url: nuhello_ajax.ajax_url,
             type: "GET",
             data: {
                 action: "nuhello_get_pricing_plans",
                 nonce: nuhello_ajax.nonce,
                 page: 1,
                 take: 100
             }
         });
 
         const upgradeRequest = $.ajax({
             url: nuhello_ajax.ajax_url,
             type: "GET",
             data: {
                 action: "nuhello_get_upgrade_plans",
                 nonce: nuhello_ajax.nonce
             }
         });
 
         $.when(pricingRequest, upgradeRequest)
             .done(function (pricingResult, upgradeResult) {
                const pricingPayload = normalizePayload(pricingResult[0]);
                const upgradePayload = normalizePayload(upgradeResult[0]) || {};

                upgradeState.allPlans = extractPlans(pricingPayload);
                upgradeState.currentPlanId = upgradePayload.currentPlanId || null;
                upgradeState.nextPlanId = upgradePayload.nextPlanId || null;
                upgradeState.currentPlan = upgradeState.allPlans.find(
                    (plan) => getPlanIdentifier(plan) === upgradeState.currentPlanId
                ) || null;
                upgradeState.nextPlan = upgradeState.allPlans.find(
                    (plan) => getPlanIdentifier(plan) === upgradeState.nextPlanId
                ) || null;
                 upgradeState.selectedPlanId = null;
 
                const currentPlan = resolveCurrentPlan();
                const currentPlanName = getPlanDisplayName(currentPlan) || "Free";
                $("#nuhello-upgrade-current-plan").text(currentPlanName);
                const currentPlanType = getPlanType(currentPlan);
                if (currentPlanType === "yearly" || currentPlanType === "monthly") {
                    $("#nuhello-upgrade-current-billing")
                        .text(currentPlanType === "yearly" ? "(Yearly)" : "(Monthly)")
                        .removeAttr("hidden");
                } else {
                    $("#nuhello-upgrade-current-billing").attr("hidden", "hidden").text("");
                }
 
                const isOnHighestPlan = upgradeState.currentPlanId && !upgradeState.nextPlanId;
                if (isOnHighestPlan) {
                    $("#nuhello-upgrade-standard").attr("hidden", "hidden");
                    $("#nuhello-upgrade-highest").removeAttr("hidden");
                    renderHighestPlan(currentPlan);
                } else {
                    $("#nuhello-upgrade-highest").attr("hidden", "hidden");
                    $("#nuhello-upgrade-standard").removeAttr("hidden");
                    renderUpgradeSelection();
                }
             })
             .fail(function () {
                $("#nuhello-upgrade-error")
                     .removeAttr("hidden")
                     .text("Failed to load pricing plans. Please try again.");
             })
             .always(function () {
                $("#nuhello-upgrade-loading").attr("hidden", "hidden");
                $("#nuhello-upgrade-plan-select").prop("disabled", false);
             });
     }
 
     function closeUpgradeModal($modal) {
         $modal.attr("hidden", "hidden");
     }
 
     function resolveModal($trigger) {
         const target = $trigger?.data("upgrade-modal-target") || defaultModalSelector;
         return $(target);
     }
 
    function openUpgradeModalFromCode(message) {
        const $modal = $(defaultModalSelector);
        openUpgradeModal($modal, message);
    }

     $(document).ready(function () {
         $(document).on("click", openSelector, function () {
             const $modal = resolveModal($(this));
             openUpgradeModal($modal);
         });
 
         $(document).on("click", `${defaultModalSelector} [data-close]`, function () {
             closeUpgradeModal($(defaultModalSelector));
         });
 
        $(document).on("change", "#nuhello-upgrade-yearly", function () {
             upgradeState.yearly = $(this).is(":checked");
             updateUpgradeToggleLabels();
             upgradeState.selectedPlanId = null;
             renderUpgradeSelection();
         });
 
        $(document).on("change", "#nuhello-upgrade-plan-select", function () {
             upgradeState.selectedPlanId = $(this).val() || null;
             renderUpgradeSelection();
         });
 
        $(document).on("click", "#nuhello-upgrade-change-btn", function () {
             const availablePlans = getAvailablePlans();
            const selectedPlan = availablePlans.find((plan) => getPlanIdentifier(plan) === upgradeState.selectedPlanId);
             if (!selectedPlan) return;
            const planId = getPlanIdentifier(selectedPlan);
             if (!planId) return;
            const $modal = $(defaultModalSelector);
            const baseUrl = ($modal.data("front-url") || "").toString().replace(/\/$/, "");
            const authToken = ($modal.data("auth-token") || "").toString();
            const returnUrl = ($modal.data("return-url") || "").toString();
            const tokenParam = authToken ? `&token=${encodeURIComponent(authToken)}` : "";
            const returnParam = returnUrl ? `&continue=${encodeURIComponent(returnUrl)}` : "";
            const url = `${baseUrl}/payment/checkout?plan=${encodeURIComponent(planId)}&currency=${encodeURIComponent(upgradeState.selectedCurrency)}${tokenParam}${returnParam}`;
            window.open(url, "_blank");
         });

        $(document).on("click", "#nuhello-upgrade-contact-sales", function () {
            window.open("https://nuhello.com/contact-us/", "_blank");
        });
 
         $(document).on("keydown", function (event) {
             if (event.key === "Escape") {
                 closeUpgradeModal($(defaultModalSelector));
             }
         });
 
         updateUpgradeToggleLabels();
     });

    window.NuhelloUpgradeModal = {
        open: openUpgradeModalFromCode
    };
 })(jQuery);
