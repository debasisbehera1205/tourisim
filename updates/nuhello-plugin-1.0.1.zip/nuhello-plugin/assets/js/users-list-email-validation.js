(function($) {
    'use strict';

    $(document).ready(function() {
        // Populate email validation status column for each user
        $('.wp-list-table.users tbody tr').each(function() {
            var $row = $(this);
            var rowId = $row.attr('id') || '';
            var userId = rowId.replace('user-', '');
            var $statusCell = $row.find('.column-nuhello_email_validation_status');

            if (!userId || !$statusCell.length) {
                return;
            }

            var currentStatus = $.trim($statusCell.text());
            if (currentStatus && currentStatus !== 'Unknown') {
                return;
            }

            $statusCell.text('Checking...');

            $.ajax({
                url: nuhello_email_validation.ajax_url,
                type: 'POST',
                data: {
                    action: 'nuhello_get_user_email_validation_status',
                    user_id: userId,
                    nonce: nuhello_email_validation.nonce
                },
                success: function(response) {
                    if (response.success && response.data && response.data.status) {
                        $statusCell.text(response.data.status);
                    } else {
                        $statusCell.text('Unknown');
                    }
                },
                error: function() {
                    $statusCell.text('Unknown');
                }
            });
        });

        // Handle click on email validation icon
        $(document).on('click', '.nuhello-email-validation-icon', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            var $icon = $(this);
            var email = $icon.data('email');
            
            if (!email) {
                return;
            }
            
            // Show modal immediately with loader
            showLoadingModal(email);
            
            // Call AJAX to verify email
            $.ajax({
                url: nuhello_email_validation.ajax_url,
                type: 'POST',
                data: {
                    action: 'nuhello_verify_email_users_list',
                    email: email,
                    nonce: nuhello_email_validation.nonce
                },
                success: function(response) {
                    if (response.success && response.data) {
                        showEmailValidationModal(response.data);
                        var $row = $icon.closest('tr');
                        var $statusCell = $row.find('.column-nuhello_email_validation_status');
                        if ($statusCell.length && response.data.status) {
                            $statusCell.text(response.data.status);
                        }
                    } else {
                        showErrorModal(response.data && response.data.message ? response.data.message : 'Failed to verify email.');
                    }
                },
                error: function() {
                    showErrorModal('An error occurred while verifying the email.');
                }
            });
        });
        
        // Close modal when clicking outside
        $(document).on('click', '.nuhello-email-validation-modal', function(e) {
            if ($(e.target).hasClass('nuhello-email-validation-modal')) {
                closeModal();
            }
        });
        
        // Close modal on close button click
        $(document).on('click', '.nuhello-email-validation-modal-close', function() {
            closeModal();
        });
        
        // Close modal on Escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $('.nuhello-email-validation-modal').is(':visible')) {
                closeModal();
            }
        });
    });
    
    /**
     * Show loading modal
     */
    function showLoadingModal(email) {
        var modalHtml = `
            <div class="nuhello-email-validation-modal">
                <div class="nuhello-email-validation-modal-content">
                    <div class="nuhello-email-validation-modal-header">
                        <h2>${escapeHtml(email)}</h2>
                        <button class="nuhello-email-validation-modal-close" aria-label="Close">&times;</button>
                    </div>
                    <div class="nuhello-email-validation-modal-body">
                        <div class="nuhello-email-validation-loading">
                            <div class="nuhello-spinner"></div>
                            <p>Verifying email address...</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing modal if any
        $('.nuhello-email-validation-modal').remove();
        
        // Add modal to body
        $('body').append(modalHtml);
        
        // Show modal
        $('.nuhello-email-validation-modal').fadeIn(200);
    }

    function getStatusDescription (status){
        switch (status?.toLowerCase()) {
          case "valid":
            return "Server accepted the mailbox; messages should deliver.";
          case "invalid":
            return "Mailbox rejected during verification; sending will likely bounce.";
          case "catch all":
          case "catch-all":
            return "Domain accepts all addresses, so this mailbox can't be confirmed.";
          case "unknown":
            return "Server gave no definitive answer; delivery is uncertain.";
          default:
            return "Delivery status could not be confirmed.";
        }
    };

    function getSafeToSendDescription (safeToSend) {
        var safeToSendLower = (safeToSend || '').toLowerCase();
        if (safeToSendLower === 'yes') {
            return 'This email is safe to send to.';
        }
        else if (safeToSendLower === 'risky' || safeToSendLower === 'no') {
            return 'Sending to this email may result in bounces.';
        }
        else {
            return 'Unable to determine if safe to send.';
        }
    }

    /**
     * Show email validation result modal (only status and safe to send)
     */
    function showEmailValidationModal(data) {
        var statusClass = (data.status === 'Valid') ? 'valid' : (data.status === 'Invalid') ? 'invalid' : 'unknown';
        var safeToSendClass = (data.safetosend === 'Yes' || data.safetosend === 'yes') ? 'yes' : (data.safetosend === 'Risky' || data.safetosend === 'risky') ? 'risky' : 'unknown';
        var statusText = data.status || 'Unknown';
        var statusIcon = (data.status === 'Valid') ? 'dashicons-yes' : (data.status === 'Invalid') ? 'dashicons-no' : 'dashicons-unknown';
        var safeToSendText = data.safetosend || 'Unknown';
        var safeToSendIcon = (data.safetosend === 'Yes' || data.safetosend === 'yes') ? 'dashicons-yes' : (data.safetosend === 'Risky' || data.safetosend === 'risky') ? 'dashicons-warning' : 'dashicons-unknown';
        
        var modalHtml = `
            <div class="nuhello-email-validation-modal">
                <div class="nuhello-email-validation-modal-content">
                    <div class="nuhello-email-validation-modal-header">
                        <h2>${escapeHtml(data.email)}</h2>
                        <button class="nuhello-email-validation-modal-close" aria-label="Close">&times;</button>
                    </div>
                    <div class="nuhello-email-validation-modal-body">
                        <div class="nuhello-email-validation-details-grid">
                            <div class="nuhello-email-validation-detail">
                                <span class="nuhello-email-validation-detail-label">Status</span>
                                <span class="nuhello-email-validation-status-badge ${statusClass}">
                                    <span class="dashicons ${statusIcon}"></span>${escapeHtml(statusText)}
                                </span>
                                <small class="nuhello-email-validation-status-description">${getStatusDescription(data.status)}</small>
                            </div>

                            <div class="nuhello-email-validation-detail">
                                <span class="nuhello-email-validation-detail-label">Safe to Send</span>
                                <span class="nuhello-email-validation-safe-to-send-badge ${safeToSendClass}">
                                    <span class="dashicons ${safeToSendIcon}"></span>${escapeHtml(safeToSendText)}
                                </span>
                                <small class="nuhello-email-validation-safe-to-send-description">${getSafeToSendDescription(data.safetosend)}</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing modal if any
        $('.nuhello-email-validation-modal').remove();
        
        // Add modal to body
        $('body').append(modalHtml);
        
        // Show modal
        $('.nuhello-email-validation-modal').fadeIn(200);
    }
    
    /**
     * Show error modal
     */
    function showErrorModal(message) {
        var modalHtml = `
            <div class="nuhello-email-validation-modal">
                <div class="nuhello-email-validation-modal-content">
                    <div class="nuhello-email-validation-modal-header">
                        <h2>Error</h2>
                        <button class="nuhello-email-validation-modal-close" aria-label="Close">&times;</button>
                    </div>
                    <div class="nuhello-email-validation-modal-body">
                        <div class="nuhello-email-validation-error">
                            ${escapeHtml(message)}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing modal if any
        $('.nuhello-email-validation-modal').remove();
        
        // Add modal to body
        $('body').append(modalHtml);
        
        // Show modal
        $('.nuhello-email-validation-modal').fadeIn(200);
    }
    
    /**
     * Close modal
     */
    function closeModal() {
        $('.nuhello-email-validation-modal').fadeOut(200, function() {
            $(this).remove();
        });
    }
    
    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
})(jQuery);

