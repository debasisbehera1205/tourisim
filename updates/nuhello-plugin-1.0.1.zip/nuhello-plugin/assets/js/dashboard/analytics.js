(function(window, $) {
    const Dashboard = window.NuhelloDashboard = window.NuhelloDashboard || {};
    let visitorMapRenderToken = 0;
    let isVisitorMapRendering = false;

    const analyticsChartData = {
        totalVisitors: [0, 0, 0, 0, 0, 0],
        totalSessions: [0, 0, 0, 0, 0, 0],
        totalPageViews: [0, 0, 0, 0, 0, 0],
        bounceRate: [0, 0, 0, 0, 0, 0]
    };

    function percentChange(currentValue, previousValue) {
        const current = Number(currentValue) || 0;
        const previous = Number(previousValue) || 0;
        if (previous === 0) {
            return current > 0 ? 100 : 0;
        }
        return ((current - previous) / previous) * 100;
    }

    function cumulativeFromBaseline(baseline, dailySeries) {
        const base = Number(baseline) || 0;
        const series = Array.isArray(dailySeries) ? dailySeries : [];
        let run = base;
        return series.map(value => {
            run += Number(value) || 0;
            return run;
        });
    }

    Dashboard.updateAnalyticsStats = function(data) {
        console.log('updateAnalyticsStats called with data:', data);

        const hasCounts = data && data.counts && data.series;
        let visitors = 0;
        let sessions = 0;
        let pageViews = 0;
        let bounceRate = 0;
        let visitorsChange = 0;
        let sessionsChange = 0;
        let pageviewsChange = 0;
        let bounceRateChange = 0;
        let visitorsChartData = analyticsChartData.totalVisitors;
        let sessionsChartData = analyticsChartData.totalSessions;
        let pageViewsChartData = analyticsChartData.totalPageViews;
        let bounceRateChartData = analyticsChartData.bounceRate;

        if (hasCounts) {
            const counts = data.counts || {};
            const series = data.series || {};

            visitors = Number(counts.value?.total_visitors) || 0;
            sessions = Number(counts.value?.total_sessions) || 0;
            pageViews = Number(counts.value?.total_pageviews) || 0;
            bounceRate = Number(counts.value?.bounce_rate) || 0;

            visitorsChange = percentChange(counts.periodValue?.total_visitors, counts.previousPeriodValue?.total_visitors);
            sessionsChange = percentChange(counts.periodValue?.total_sessions, counts.previousPeriodValue?.total_sessions);
            pageviewsChange = percentChange(counts.periodValue?.total_pageviews, counts.previousPeriodValue?.total_pageviews);
            bounceRateChange = percentChange(counts.periodValue?.bounce_rate, counts.previousPeriodValue?.bounce_rate);

            visitorsChartData = cumulativeFromBaseline(counts.previousPeriodValue?.total_visitors, series.total_visitors || []);
            sessionsChartData = cumulativeFromBaseline(counts.previousPeriodValue?.total_sessions, series.total_sessions || []);
            pageViewsChartData = cumulativeFromBaseline(counts.previousPeriodValue?.total_pageviews, series.total_pageviews || []);
            bounceRateChartData = Array.isArray(series.bounce_rate) && series.bounce_rate.length
                ? series.bounce_rate
                : analyticsChartData.bounceRate;
        } else {
            const allTimeMetrics = data.dashboard_data?.value?.find(item => item.name === 'all_time_metrics');
            visitors = allTimeMetrics?.visitors || 0;
            sessions = allTimeMetrics?.sessions || 0;
            pageViews = allTimeMetrics?.pageviews || data.total_pageviews || 0;
            bounceRate = data.bounce_rate || 0;

            const visitorsChangeObj = data.dashboard_data?.value?.find(item => item.name === 'visitors');
            const sessionsChangeObj = data.dashboard_data?.value?.find(item => item.name === 'sessions');
            const pageviewsChangeObj = data.dashboard_data?.value?.find(item => item.name === 'pageviews');

            visitorsChange = visitorsChangeObj ?
                (visitorsChangeObj.condition === 'increase' ? visitorsChangeObj.change : -visitorsChangeObj.change) : 0;
            sessionsChange = sessionsChangeObj ?
                (sessionsChangeObj.condition === 'increase' ? sessionsChangeObj.change : -sessionsChangeObj.change) : 0;
            pageviewsChange = pageviewsChangeObj ?
                (pageviewsChangeObj.condition === 'increase' ? pageviewsChangeObj.change : -pageviewsChangeObj.change) : 0;

            bounceRateChange = -5.2;

            const visitsData = data.visits_over_time?.value || {};
            const visitsDates = Object.keys(visitsData).sort();
            const visitsValues = visitsDates.map(date => visitsData[date]);

            visitorsChartData = visitsValues.length > 0 ? visitsValues.slice(-6) : analyticsChartData.totalVisitors;
            sessionsChartData = visitsValues.length > 0 ? visitsValues.slice(-6) : analyticsChartData.totalSessions;
            pageViewsChartData = visitsValues.length > 0 ? visitsValues.slice(-6) : analyticsChartData.totalPageViews;
            bounceRateChartData = visitsValues.length > 0
                ? visitsValues.slice(-6).map((v, i, arr) => {
                    const maxVisits = Math.max(...arr);
                    return 50 - ((v / maxVisits) * 10);
                })
                : analyticsChartData.bounceRate;
        }

        const $visitors = $('#total-visitors');
        const $sessions = $('#total-sessions');
        const $pageViews = $('#total-page-views');
        const $bounceRate = $('#bounce-rate');

        if ($visitors.length) {
            $visitors.text(visitors.toLocaleString());
        }
        if ($('#total-visitors-change').length) {
            Dashboard.updateMetricChange('#total-visitors-change', visitorsChange);
        }
        if ($('#total-visitors-chart').length) {
            Dashboard.renderMiniChart('#total-visitors-chart', visitorsChartData, '#3b82f6');
        }

        if ($sessions.length) {
            $sessions.text(sessions.toLocaleString());
        }
        if ($('#total-sessions-change').length) {
            Dashboard.updateMetricChange('#total-sessions-change', sessionsChange);
        }
        if ($('#total-sessions-chart').length) {
            Dashboard.renderMiniChart('#total-sessions-chart', sessionsChartData, '#f59e0b');
        }

        if ($pageViews.length) {
            $pageViews.text(pageViews.toLocaleString());
        }
        if ($('#total-page-views-change').length) {
            Dashboard.updateMetricChange('#total-page-views-change', pageviewsChange);
        }
        if ($('#total-page-views-chart').length) {
            Dashboard.renderMiniChart('#total-page-views-chart', pageViewsChartData, '#22c55e');
        }

        if ($bounceRate.length) {
            $bounceRate.text(Number(bounceRate).toFixed(1) + '%');
        }
        if ($('#bounce-rate-change').length) {
            Dashboard.updateMetricChange('#bounce-rate-change', bounceRateChange);
        }
        if ($('#bounce-rate-chart').length) {
            Dashboard.renderMiniChart('#bounce-rate-chart', bounceRateChartData, '#f97316');
        }
    };

    function getIconForItem(cardTitle, itemName) {
        if (!itemName) return null;
        const normalizedName = itemName.toLowerCase().replace(/\s+/g, '');
        switch (cardTitle.toLowerCase()) {
            case 'browsers':
                return 'dashicons dashicons-admin-site-alt3';
            case 'operating systems':
                if (normalizedName.includes('ios') || normalizedName.includes('android')) return 'dashicons dashicons-smartphone';
                return 'dashicons dashicons-admin-generic';
            case 'devices':
                if (normalizedName.includes('mobile')) return 'dashicons dashicons-smartphone';
                if (normalizedName.includes('tablet')) return 'dashicons dashicons-tablet';
                return 'dashicons dashicons-desktop';
            case 'countries':
                if (itemName && itemName.length === 2) {
                    return `https://flagcdn.com/w20/${itemName.toLowerCase()}.png`;
                }
                return null;
            default:
                return null;
        }
    }

    function getIconForTitle(title) {
        switch (title.toLowerCase()) {
            case "operating systems": return 'dashicons dashicons-admin-generic';
            case "devices": return 'dashicons dashicons-desktop';
            case "browsers": return 'dashicons dashicons-admin-site-alt3';
            case "pages": return 'dashicons dashicons-admin-page';
            case "referrers": return 'dashicons dashicons-admin-links';
            case "countries": return 'dashicons dashicons-location-alt';
            case "screen resolutions": return 'dashicons dashicons-desktop';
            case "browser languages": return 'dashicons dashicons-translation';
            default: return 'dashicons dashicons-chart-bar';
        }
    }

    function getIconBackgroundColor(color) {
        switch (color) {
            case 'blue': return 'var(--blue-100)';
            case 'green': return 'var(--green-100)';
            case 'purple': return 'var(--purple-100)';
            case 'red': return 'var(--red-100)';
            default: return 'var(--gray-100)';
        }
    }

    function getIconColor(color) {
        switch (color) {
            case 'blue': return 'var(--blue-600)';
            case 'green': return 'var(--green-600)';
            case 'purple': return 'var(--purple-600)';
            case 'red': return 'var(--red-600)';
            default: return 'var(--gray-600)';
        }
    }

    function renderListCard(cardId, cardData, color) {
        const card = $(`#${cardId}`);
        if (!card.length) return;

        const iconClass = getIconForTitle(cardData.title);
        const iconBgColor = getIconBackgroundColor(color);

        let itemsHtml = '';
        if (cardData.data && cardData.data.length > 0) {
            cardData.data.forEach(item => {
                let itemIconHtml = '';
                if (item.icon) {
                    if (item.icon.startsWith('https://')) {
                        itemIconHtml = `<img src="${item.icon}" alt="${item.label}" class="item-icon">`;
                    } else {
                        itemIconHtml = `<span class="${item.icon} item-icon"></span>`;
                    }
                }
                itemsHtml += `
                    <div class="list-item">
                        <div class="list-item-progress-bar" style="width: ${item.percentage}%;"></div>
                        <div class="list-item-content">
                            <div class="list-item-label">
                                ${itemIconHtml}
                                <span>${item.label}</span>
                            </div>
                            <span class="list-item-value">${item.value}</span>
                        </div>
                    </div>
                `;
            });
        } else {
            itemsHtml = '<p>No data available.</p>';
        }

        const iconColor = getIconColor(color);
        const cardHtml = `
            <div class="list-card-header">
                <div class="list-card-icon-wrapper" style="background-color: ${iconBgColor};">
                    <span class="${iconClass}" style="color: ${iconColor};"></span>
                </div>
                <h4 class="list-card-title">${cardData.title}</h4>
            </div>
            <div class="list-items">
                ${itemsHtml}
            </div>
        `;
        card.html(cardHtml);
    }

    function renderVisitsOverTimeChart(data) {
        const canvas = document.getElementById('visitsOverTimeChart');
        if (!canvas) {
            console.warn('visitsOverTimeChart canvas not found');
            return;
        }

        const ctx = canvas.getContext('2d');
        if (window.visitsOverTimeChart instanceof Chart) {
            window.visitsOverTimeChart.destroy();
        }

        const labels = Object.keys(data.value);
        const values = Object.values(data.value);

        window.visitsOverTimeChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Conversations',
                    data: values,
                    backgroundColor: '#49BC31'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                layout: {
                    padding: { left: 10, right: 10, top: 10, bottom: 10 }
                },
                scales: {
                    x: {
                        title: { display: true, text: 'Date' },
                        grid: { display: false },
                        ticks: {
                            maxRotation: 45,
                            minRotation: 45,
                            autoSkip: true,
                            maxTicksLimit: 10,
                            font: { size: 11 },
                            callback: function(value) {
                                const label = this.getLabelForValue(value);
                                const date = new Date(label);
                                return date.toLocaleDateString('en-US', {day: '2-digit', month: 'short'});
                            }
                        }
                    },
                    y: {
                        title: { display: true, text: 'Number of Visits' },
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#22281E',
                        titleColor: 'white',
                        bodyColor: 'white',
                        callbacks: {
                            title: function(context) {
                                return new Date(context[0].label).toLocaleDateString('en-US', { day: '2-digit', month: 'long', year: 'numeric' });
                            },
                            label: function(context) {
                                return `${context.raw.toLocaleString()}`;
                            }
                        }
                    }
                }
            }
        });
    }

    function renderVisitorMapChart(data) {
        const canvas = document.getElementById('visitorMapChart');
        if (!canvas) {
            console.warn('visitorMapChart canvas not found');
            return;
        }

        if (typeof ChartGeo === 'undefined') {
            console.warn('ChartGeo is not loaded. Retrying...');
            isVisitorMapRendering = false;
            setTimeout(() => renderVisitorMapChart(data), 200);
            return;
        }

        const currentRenderToken = ++visitorMapRenderToken;
        isVisitorMapRendering = true;

        const ctx = canvas.getContext('2d');
        const existingChart = Chart.getChart ? Chart.getChart(canvas) : window.visitorMapChart;
        if (existingChart) {
            existingChart.destroy();
        }

        let tooltipEl = document.getElementById('chartjs-tooltip-visitor-map');
        if (!tooltipEl) {
            tooltipEl = document.createElement('div');
            tooltipEl.id = 'chartjs-tooltip-visitor-map';
            tooltipEl.style.opacity = 0;
            tooltipEl.style.position = 'absolute';
            tooltipEl.style.pointerEvents = 'none';
            tooltipEl.style.transition = 'opacity 0.2s ease';
            tooltipEl.style.zIndex = 10;
            tooltipEl.style.transform = 'translate(-50%, -100%)';
            tooltipEl.style.background = '#22281E';
            tooltipEl.style.color = 'white';
            tooltipEl.style.padding = '8px';
            tooltipEl.style.borderRadius = '4px';
            tooltipEl.style.fontSize = '12px';
            canvas.parentNode.appendChild(tooltipEl);
        }

        const countryCodeToName = {
            'IN': 'India',
            'US': 'United States of America',
            'GB': 'United Kingdom',
            'CA': 'Canada',
            'AU': 'Australia',
            'DE': 'Germany',
            'FR': 'France',
            'IT': 'Italy',
            'ES': 'Spain',
            'NL': 'Netherlands',
            'BE': 'Belgium',
            'CH': 'Switzerland',
            'AT': 'Austria',
            'SE': 'Sweden',
            'NO': 'Norway',
            'DK': 'Denmark',
            'FI': 'Finland',
            'PL': 'Poland',
            'CZ': 'Czech Republic',
            'IE': 'Ireland',
            'PT': 'Portugal',
            'GR': 'Greece',
            'RO': 'Romania',
            'HU': 'Hungary',
            'BG': 'Bulgaria',
            'HR': 'Croatia',
            'SK': 'Slovakia',
            'SI': 'Slovenia',
            'EE': 'Estonia',
            'LV': 'Latvia',
            'LT': 'Lithuania',
            'LU': 'Luxembourg',
            'MT': 'Malta',
            'CY': 'Cyprus',
            'JP': 'Japan',
            'CN': 'China',
            'KR': 'South Korea',
            'SG': 'Singapore',
            'MY': 'Malaysia',
            'TH': 'Thailand',
            'ID': 'Indonesia',
            'PH': 'Philippines',
            'VN': 'Vietnam',
            'NZ': 'New Zealand',
            'BR': 'Brazil',
            'MX': 'Mexico',
            'AR': 'Argentina',
            'CL': 'Chile',
            'CO': 'Colombia',
            'PE': 'Peru',
            'ZA': 'South Africa',
            'EG': 'Egypt',
            'NG': 'Nigeria',
            'KE': 'Kenya',
            'MA': 'Morocco',
            'AE': 'United Arab Emirates',
            'SA': 'Saudi Arabia',
            'IL': 'Israel',
            'TR': 'Turkey',
            'RU': 'Russia',
            'UA': 'Ukraine',
            'PK': 'Pakistan',
            'BD': 'Bangladesh',
            'LK': 'Sri Lanka',
            'NP': 'Nepal',
            'MM': 'Myanmar',
            'KH': 'Cambodia',
            'LA': 'Laos',
            'BN': 'Brunei',
            'MO': 'Macau',
            'HK': 'Hong Kong',
            'TW': 'Taiwan'
        };

        fetch('https://unpkg.com/world-atlas/countries-50m.json')
            .then(r => r.json())
            .then(world => {
                if (currentRenderToken !== visitorMapRenderToken) {
                    isVisitorMapRendering = false;
                    return;
                }
                const countries = ChartGeo.topojson.feature(world, world.objects.countries)
                    .features.filter(d => d.properties.name !== 'Antarctica');

                const countryData = {};
                if (data.value && Array.isArray(data.value)) {
                    data.value.forEach(item => {
                        const countryCode = item.name;
                        const countryName = countryCodeToName[countryCode] || countryCode;
                        countryData[countryName] = {
                            count: item.count || 0,
                            percentage: item.percentage || 0,
                            code: countryCode
                        };
                    });
                }

                const maxVisitors = Math.max(0, ...(data.value || []).map(c => c.count || 0));
                const chartData = countries.map(d => {
                    const countryName = d.properties.name;
                    const value = countryData[countryName] || { count: 0, code: '', percentage: 0 };
                    return {
                        feature: d,
                        value: value,
                        flagUrl: value.code ? `https://flagcdn.com/w20/${value.code.toLowerCase()}.png` : ''
                    };
                });

                const isMobile = window.innerWidth < 768;
                const chartToReplace = Chart.getChart ? Chart.getChart(canvas) : window.visitorMapChart;
                if (chartToReplace) {
                    chartToReplace.destroy();
                }

                window.visitorMapChart = new Chart(ctx, {
                    type: 'choropleth',
                    data: {
                        labels: countries.map(d => d.properties.name),
                        datasets: [{
                            label: 'Countries',
                            data: chartData,
                            backgroundColor: chartData.map(d => {
                                const count = d.value.count || 0;
                                if (count === 0) return 'rgb(230,230,230)';
                                const intensity = maxVisitors > 0 ? count / maxVisitors : 0;
                                return `rgba(73, 188, 49, ${0.2 + 0.8 * intensity})`;
                            }),
                            borderColor: 'rgba(255,255,255,1)',
                            borderWidth: isMobile ? 0.5 : 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        layout: {
                            padding: {
                                left: isMobile ? 0 : 10,
                                right: isMobile ? 0 : 10,
                                top: isMobile ? 0 : 10,
                                bottom: isMobile ? 0 : 10
                            }
                        },
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                enabled: false,
                                external: function(context) {
                                    const tooltipModel = context.tooltip;

                                    if (tooltipModel.opacity === 0) {
                                        tooltipEl.style.opacity = "0";
                                        return;
                                    }

                                    if (!tooltipModel.dataPoints || tooltipModel.dataPoints.length === 0) {
                                        tooltipEl.style.opacity = "0";
                                        return;
                                    }

                                    const dataIndex = tooltipModel.dataPoints[0].dataIndex;
                                    const tooltipData = chartData[dataIndex];

                                    const countryName = tooltipData.feature.properties.name;
                                    const flagUrl = tooltipData.flagUrl;
                                    const visitors = tooltipData.value.count || 0;

                                    const fontSize = isMobile ? '12px' : '14px';
                                    const padding = isMobile ? '6px' : '8px';

                                    const innerHtml = `
                                        <div style="background: #22281E; color: white; padding: ${padding}; border-radius: 4px; font-family: Arial, sans-serif;">
                                            <div style="display: flex; align-items: center; margin-bottom: 3px;">
                                                ${flagUrl ? `<img src="${flagUrl}" width="${isMobile ? '16' : '20'}" height="${isMobile ? '12' : '15'}" alt="${countryName} flag" style="margin-right: 5px;">` : ""}
                                                <span style="font-size: ${fontSize}; font-weight: bold;">${countryName}</span>
                                            </div>
                                            <div style="font-size: ${fontSize};">Visitors: ${visitors.toLocaleString()}</div>
                                        </div>`;

                                    tooltipEl.innerHTML = innerHtml;

                                    const position = context.chart.canvas.getBoundingClientRect();
                                    const containerWidth = context.chart.canvas.parentElement.offsetWidth;

                                    const tooltipX = isMobile ?
                                        Math.min(Math.max(tooltipModel.caretX, 100), containerWidth - 100) :
                                        tooltipModel.caretX;

                                    tooltipEl.style.opacity = "1";
                                    tooltipEl.style.position = "absolute";
                                    tooltipEl.style.left = `${tooltipX}px`;
                                    tooltipEl.style.top = `${tooltipModel.caretY}px`;
                                    tooltipEl.style.pointerEvents = "none";
                                }
                            }
                        },
                        scales: {
                            xy: { projection: "equalEarth" },
                            color: { axis: "x", display: false }
                        },
                        hover: { mode: null },
                        elements: {
                            geodata: { hover: { mode: null } }
                        }
                    }
                });
                isVisitorMapRendering = false;
            })
            .catch(error => {
                console.error('Error loading world map data:', error);
                const chartContainer = canvas.parentElement;
                if (chartContainer) {
                    chartContainer.innerHTML = '<p style="padding: 20px; text-align: center; color: #666;">Failed to load map data. Please refresh the page.</p>';
                }
                isVisitorMapRendering = false;
            });
    }

    function renderUtmCard(data) {
        const card = $('#utm-card');
        if (!card.length) return;

        const utmTypes = [
            { key: 'utm_source', label: 'Source' },
            { key: 'utm_medium', label: 'Medium' },
            { key: 'utm_campaign', label: 'Campaign' },
            { key: 'utm_content', label: 'Content' },
            { key: 'utm_term', label: 'Term' }
        ];

        const hasData = (type) => data[type]?.value && data[type].value.length > 0;
        const availableUtmTypes = utmTypes.filter(type => hasData(type.key));
        let activeTab = availableUtmTypes.length > 0 ? availableUtmTypes[0].key : null;

        const renderContent = () => {
            let itemsHtml = '';
            const activeData = activeTab ? (data[activeTab]?.value || []) : [];

            if (activeData.length > 0) {
                activeData.forEach(item => {
                    itemsHtml += `
                        <div class="list-item">
                            <div class="list-item-progress-bar" style="width: ${item.percentage}%;"></div>
                            <div class="list-item-content">
                                <span class="list-item-label">${item.name || 'Not set'}</span>
                                <span class="list-item-value">${item.count}</span>
                            </div>
                        </div>
                    `;
                });
            } else {
                itemsHtml = '<p>No data available.</p>';
            }

            const tabsHtml = utmTypes.map(type => `
                <button class="utm-tab ${activeTab === type.key ? 'active' : ''}" data-key="${type.key}" ${!hasData(type.key) ? 'disabled' : ''}>
                    <span>${type.label}</span>
                </button>
            `).join('');

            const cardHtml = `
                <div class="list-card-header">
                    <div class="list-card-icon-wrapper" style="background-color: rgba(73, 188, 49, 0.1);">
                        <span class="dashicons dashicons-tag"></span>
                    </div>
                    <h4 class="list-card-title">UTM Analytics</h4>
                </div>
                <div class="utm-tabs">${tabsHtml}</div>
                <div class="list-items">${itemsHtml}</div>
            `;
            card.html(cardHtml);

            card.find('.utm-tab').off('click').on('click', function() {
                const key = $(this).data('key');
                if (hasData(key)) {
                    activeTab = key;
                    renderContent();
                }
            });
        };

        renderContent();
    }

    Dashboard.renderAnalyticsData = function(data) {
        const renderWhenReady = function() {
            if (!$('#dashboard-content').is(':visible')) {
                setTimeout(renderWhenReady, 100);
                return;
            }

            const cardsData = [
                { id: 'pages-card', data: data.paths, title: "Pages", left: "PAGE", right: "PAGEVIEWS", color: "blue" },
                { id: 'os-card', data: data.operating_systems, title: "Operating Systems", left: "OS", right: "VISITORS", color: "red" },
                { id: 'devices-card', data: data.device_types, title: "Devices", left: "DEVICE TYPE", right: "VISITORS", color: "purple" },
                { id: 'browsers-card', data: data.browser_names, title: "Browsers", left: "BROWSER", right: "VISITORS", color: "blue" },
                { id: 'countries-card', data: data.countries, title: "Countries", left: "COUNTRY", right: "VISITORS", color: "green" },
                { id: 'resolutions-card', data: data.screen_resolutions, title: "Screen Resolutions", left: "RESOLUTION", right: "VISITORS", color: "red" },
                { id: 'languages-card', data: data.browser_languages, title: "Browser Languages", left: "LANGUAGE", right: "VISITORS", color: "purple" },
                { id: 'referrers-card', data: data.referrers, title: "Referrers", left: "DOMAIN", right: "VISITORS", color: "blue" }
            ];

            cardsData.forEach(cardInfo => {
                if (cardInfo.data && cardInfo.data.value) {
                    renderListCard(cardInfo.id, {
                        title: cardInfo.title,
                        leftColumnLabel: cardInfo.left,
                        rightColumnLabel: cardInfo.right,
                        data: cardInfo.data.value.map(item => ({
                            label: item.name || "Unknown",
                            value: item.count,
                            percentage: item.percentage,
                            icon: getIconForItem(cardInfo.title, item.name)
                        }))
                    }, cardInfo.color);
                }
            });

            if (data.visits_over_time && data.visits_over_time.value) {
                renderVisitsOverTimeChart(data.visits_over_time);
            }
            if (data.countries && data.countries.value) {
                renderVisitorMapChart(data.countries);
            }

            const utmData = {
                utm_source: data.utms_source,
                utm_medium: data.utm_medium,
                utm_campaign: data.utm_campaign,
                utm_content: data.utm_content,
                utm_term: data.utm_term
            };
            renderUtmCard(utmData);

            const $grids = $('.analytics-grid');

            if ($grids.eq(0).length) {
                Dashboard.manageRowVisibility($grids.eq(0), [
                    { data: data.dashboard_data?.value?.[0]?.visitors || 0, type: 'stat' },
                    { data: data.dashboard_data?.value?.[0]?.sessions || 0, type: 'stat' },
                    { data: data.total_pageviews || 0, type: 'stat' },
                    { data: data.bounce_rate || 0, type: 'stat' }
                ]);
            }

            if ($grids.eq(1).length) {
                Dashboard.manageRowVisibility($grids.eq(1), [
                    { data: data.visits_over_time, type: 'chart' },
                    { data: data.paths, type: 'list' }
                ]);
            }

            if ($grids.eq(2).length) {
                Dashboard.manageRowVisibility($grids.eq(2), [
                    { data: data.countries, type: 'map' },
                    { data: data.operating_systems, type: 'list' },
                    { data: data.device_types, type: 'list' }
                ]);
            }

            if ($grids.eq(3).length) {
                Dashboard.manageRowVisibility($grids.eq(3), [
                    { data: data.browser_names, type: 'list' },
                    { data: data.countries, type: 'list' },
                    { data: data.screen_resolutions, type: 'list' },
                    { data: data.browser_languages, type: 'list' }
                ]);
            }

            if ($grids.eq(4).length) {
                Dashboard.manageRowVisibility($grids.eq(4), [
                    { data: data.referrers, type: 'list' },
                    { data: utmData, type: 'utm' }
                ]);
            }
        };

        renderWhenReady();
    };
})(window, jQuery);
