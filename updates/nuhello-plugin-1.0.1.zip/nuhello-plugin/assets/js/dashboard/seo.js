(function(window, $) {
    const Dashboard = window.NuhelloDashboard = window.NuhelloDashboard || {};

    Dashboard.updateSeoUI = function(audit) {
        const data = audit.data || {};

        const overallScore = audit.score || 0;
        const scoreLabel = overallScore >= 80 ? 'Good' : (overallScore >= 50 ? 'Average' : 'Poor');
        const scoreBadge = $('#overall-score-badge');
        scoreBadge.text(scoreLabel);
        scoreBadge.removeClass('badge-good badge-average badge-poor')
            .addClass(overallScore >= 80 ? 'badge-good' : (overallScore >= 50 ? 'badge-average' : 'badge-poor'));

        $('#overall-score-text').text(overallScore + '/100');

        const circle = $('#score-circle-progress');
        const radius = circle.get(0).r.baseVal.value;
        const circumference = 2 * Math.PI * radius;
        const offset = circumference - (overallScore / 100) * circumference;
        circle.css('stroke-dashoffset', offset);
        const circleColor = overallScore >= 80 ? 'var(--green-500)' : (overallScore >= 50 ? 'var(--orange-500)' : 'var(--red-600)');
        circle.css('stroke', circleColor);

        $('#domain-url').text(audit.url);
        $('#favicon-img').attr('src', `https://www.google.com/s2/favicons?domain=${audit.url}`);

        const failedTests = Object.keys(audit.major_issues || {}).length + Object.keys(audit.moderate_issues || {}).length;
        const warningTests = Object.keys(audit.minor_issues || {}).length;
        $('#passed-tests').text(audit.passed_tests || 0);
        $('#failed-tests').text(failedTests);
        $('#warning-tests').text(warningTests);
        $('#total-tests-info').text(`${audit.total_tests || 0} total tests`);

        const performanceScore = Math.max(0, Math.round(100 - ((audit.response_time || 2000) / 2000 * 50) - ((audit.ttfb || 1) * 1000 / 1000 * 50)));
        $('#performance-score').text(performanceScore);
        $('#load-time').text(Math.round(audit.response_time || 0) + 'ms');
        $('#ttfb').text(Math.round((audit.ttfb || 0) * 1000) + 'ms');
        $('#page-size').text(((audit.page_size || 0) / 1024).toFixed(1) + ' KB');
        $('#performance-progress').css('width', performanceScore + '%');

        const accessibilityScore = Math.max(0, Math.round(100 - ((data.dom_size || 500) / 1500 * 50) - ((300 / (data.words_count || 300)) * 50)));
        $('#accessibility-score').text(accessibilityScore);
        $('#dom-size').text((data.dom_size || 0) + ' nodes');
        $('#word-count').text((data.words_count || 0).toLocaleString());
        $('#text-html-ratio').text(data.text_to_html_ratio || '0');
        $('#accessibility-progress').css('width', accessibilityScore + '%');

        const bestPracticesScore = Math.round(((audit.is_https ? 1 : 0) + (data.meta_description ? 1 : 0) + (data.title ? 1 : 0)) / 3 * 100);
        $('#best-practices-score').text(bestPracticesScore);
        $('#https-status').html(audit.is_https ? '<span class="value secure">✓ Secure</span>' : '<span class="value insecure">✗ Not Secure</span>');
        $('#meta-desc-status').html(data.meta_description ? '<span class="value secure">✓ Present</span>' : '<span class="value insecure">✗ Missing</span>');
        $('#title-status').html(data.title ? '<span class="value secure">✓ Present</span>' : '<span class="value insecure">✗ Missing</span>');
        $('#best-practices-progress').css('width', bestPracticesScore + '%');

        $('#security-badge').text(audit.is_https ? 'HTTPS' : 'HTTP');
        $('#ssl-status').html(audit.is_ssl_valid ? '<span class="value secure">✓ Valid</span>' : '<span class="value insecure">✗ Invalid</span>');
        $('#http-requests').text(audit.http_requests || 0);
        $('#download-speed').text(Math.round((audit.average_download_speed || 0) / 1024) + ' KB/s');
        $('#security-progress').css('width', audit.is_ssl_valid && audit.is_https ? '100%' : '10%');

        if (typeof Dashboard.manageRowVisibility === 'function') {
            Dashboard.manageRowVisibility('.seo-dashboard', [
                { data: overallScore, type: 'score' },
                { data: audit.url, type: 'metric' },
                { data: performanceScore, type: 'score' },
                { data: accessibilityScore, type: 'score' },
                { data: bestPracticesScore, type: 'score' },
                { data: audit.is_https, type: 'boolean' }
            ]);
        }
    };
})(window, jQuery);
