jQuery(document).ready(function($) {
    
    // Current step tracking
    let currentStep = 1;
    const totalSteps = 3; // Updated total steps (removed welcome step)
    let otpSent = false;
    let isWelcomePhase = true; // Track if we're in the welcome phase
    let countdownInterval = null;
    let remainingTime = 0;

    // Initialize wizard
    initWizard();
    
    // Check for registration return or existing registration session
    checkRegistrationStatus();
    
        // Initialize mobile menu
        initMobileMenu();
        
        // Initialize dropdown navigation
        initDropdownNavigation();

    function showButtonLoader($btn) {
        $btn.addClass('loading').prop('disabled', true);
        $btn.find('.btn-text').css('opacity', '0');
        $btn.find('.btn-loader').show();
    }

    function hideButtonLoader($btn, defaultText = 'Continue') {
        $btn.removeClass('loading').prop('disabled', false);
        $btn.find('.btn-text').css('opacity', '1').text(defaultText);
        $btn.find('.btn-loader').hide();
    }

    function initWizard() {
        // Start onboarding button click (welcome phase)
        $(document).on('click', '.start-onboarding', async function(e) {
            e.preventDefault();
            const $btn = $(this);
            
            if (isWelcomePhase) {
                const email = $('#email-input').val().trim();
                if (!email || !isValidEmail(email)) {
                    showAlertMessage('Please enter a valid email address.', 'error');
                    return;
                }

                if (!otpSent) {
                    showButtonLoader($btn);
                    const otpResult = await sendOtp(email);
                    if (otpResult && otpResult.success) {
                        if (otpResult.type === 'registration') {
                            // Account creation section is already shown in sendOtp
                            hideButtonLoader($btn, 'Get Started');
                        } else {
                            otpSent = true;
                            $('#otp-email-display').text(email);
                            $('#email-section').stop(true, true).fadeOut(300, function() {
                                $('#otp-section').fadeIn(300, function() {
                                    $('#otp-inputs input').first().focus();
                                });
                            });
                            hideButtonLoader($btn, 'Verify & Continue');
                        }
                    } else {
                        hideButtonLoader($btn, 'Get Started');
                    }
                } else {
                    const otp = Array.from($('#otp-inputs input')).map(input => input.value).join('');
                    if (otp.length !== 6) {
                        showAlertMessage('Please enter the 6-digit verification code.', 'error');
                        return;
                    }
                    showButtonLoader($btn);
                    const verified = await verifyOtp(email, otp);
                    if (verified) {
                        // Hide welcome section and show onboarding steps
                        $('#welcome-section').fadeOut(300, function() {
                            $('#onboarding-steps').fadeIn(300);
                            isWelcomePhase = false;
                            currentStep = 1; // Reset to step 1 of the 3-step process
                            updateStepIndicators(1);
                        });
                        hideButtonLoader($btn, 'Get Started');
                    } else {
                        hideButtonLoader($btn, 'Verify & Continue');
                    }
                }
            }
        });

        // Next step button click
        $(document).on('click', '.next-step', async function(e) {
            e.preventDefault();
            const $btn = $(this);
            const nextStep = parseInt($btn.data('next'));

            const validationResult = await validateCurrentStep(nextStep);
            if (validationResult) {
                showButtonLoader($btn);
                try {
                    const success = await saveStepData();
                    if (success) {
                        goToStep(nextStep);
                    }
                } catch (error) {
                    console.error('Error in next step logic:', error);
                } finally {
                    const buttonText = (nextStep === totalSteps) ? 'Complete Setup' : 'Continue';
                    hideButtonLoader($btn, buttonText);
                }
            }
        });

        // Previous step button click
        $(document).on('click', '.prev-step', function(e) {
            e.preventDefault();
            const prevStep = $(this).data('prev');
            goToStep(prevStep);
        });

        // Complete onboarding button click
        $(document).on('click', '.complete-onboarding', async function(e) {
            e.preventDefault();
            const $btn = $(this);
            if (await validateCurrentStep()) {
                showButtonLoader($btn);
                try {
                    await saveStepData();
                    await completeOnboarding(); // This function handles its own redirect
                } catch (error) {
                    console.error('Error completing onboarding:', error);
                    hideButtonLoader($btn, 'Complete Setup');
                }
            }
        });

        // Restart onboarding button click
        $(document).on('click', '#restart-onboarding', function(e) {
            e.preventDefault();
            restartOnboarding();
        });

        // OTP input handling
        const $otpInputs = $('#otp-inputs input');
        $otpInputs.on('input', function(e) {
            const $this = $(this);
            if ($this.val().length === 1) {
                const next = $otpInputs.eq($otpInputs.index(this) + 1);
                if (next.length) {
                    next.focus();
                }
            }
        });

        $otpInputs.on('keydown', function(e) {
            if (e.key === 'Backspace' && $(this).val().length === 0) {
                const prev = $otpInputs.eq($otpInputs.index(this) - 1);
                if (prev.length) {
                    prev.focus();
                }
            }
        });

        // Handle OTP paste
        $otpInputs.on('paste', function(e) {
            e.preventDefault();
            const pastedData = (e.originalEvent.clipboardData || window.clipboardData).getData('text').trim();
            if (pastedData) {
                const digits = pastedData.split('').filter(d => /^\d$/.test(d));
                digits.forEach((digit, index) => {
                    if (index < $otpInputs.length) {
                        $($otpInputs[index]).val(digit);
                    }
                });
                // Focus the last filled input or the next empty one
                const lastFilledIndex = Math.min(digits.length, $otpInputs.length) - 1;
                if (lastFilledIndex < $otpInputs.length - 1) {
                    $($otpInputs[lastFilledIndex + 1]).focus();
                } else {
                    $($otpInputs[lastFilledIndex]).focus();
                }
            }
        });

        // Edit email link
        $(document).on('click', '#edit-email-link', function(e) {
            e.preventDefault();
            otpSent = false;
            $('#otp-section').stop(true, true).fadeOut(300, function() {
                $('#email-section').fadeIn(300);
            });
            const $continueBtn = $('.next-step[data-next="2"]');
            $continueBtn.find('.btn-text').text('Continue');
        });

        // Change email link in onboarding steps
        $(document).on('click', '.change-onboarding-email', function(e) {
            e.preventDefault();
            showCancelOnboardingModal().then(function(confirmed) {
                if (!confirmed) {
                    return;
                }
                resetOnboardingToEmail($(this));
            }.bind(this));
        });

        // Tab functionality
        $(document).on('click', '.tab-button:not(.disabled)', function(e) {
            e.preventDefault();
            const targetTab = $(this).data('tab');
            switchTab(targetTab);
        });

        // Disabled tab click handler
        $(document).on('click', '.tab-button.disabled', function(e) {
            e.preventDefault();
            showDisabledTabMessage($(this).data('tab'));
        });



        // Checkbox change
        $(document).on('change', 'input[type="checkbox"]', function() {
            const $checkbox = $(this).closest('.checkbox-option');
            if ($(this).is(':checked')) {
                $checkbox.addClass('selected');
            } else {
                $checkbox.removeClass('selected');
            }
        });

        // Handle default environment checkboxes (mutual exclusivity)
        $(document).on('change', '#testing-default', function() {
            if ($(this).is(':checked')) {
                $('#production-default').prop('checked', false);
            }
        });

        $(document).on('change', '#production-default', function() {
            if ($(this).is(':checked')) {
                $('#testing-default').prop('checked', false);
            }
        });

        // Add visual feedback when checkboxes are automatically selected
        $(document).on('change', '#testing-default, #production-default', function() {
            // Remove auto-selected class from both checkboxes
            $('#testing-default, #production-default').closest('.simple-checkbox').removeClass('auto-selected');
        });
    }

    function switchTab(tabName) {
        // Remove active class from all tabs and panes
        $('.tab-button').removeClass('active');
        $('.tab-pane').removeClass('active');

        // Add active class to clicked tab and corresponding pane
        $(`.tab-button[data-tab="${tabName}"]`).addClass('active');
        $(`#${tabName}-tab`).addClass('active');
    }

    function showDisabledTabMessage(tabName) {
        const tabNames = {
            'seo': 'SEO',
            'analytics': 'Analytics',
            'notifications': 'Notifications'
        };

        const tabNameDisplay = tabNames[tabName] || tabName;

        // Create a temporary message
        const $message = $(`
            <div class="nuhello-disabled-tab-message" style="
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: #fff;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                z-index: 10000;
                max-width: 400px;
                text-align: center;
            ">
                <i class="dashicons dashicons-info" style="
                    font-size: 2rem;
                    color: #666;
                    margin-bottom: 10px;
                    display: block;
                "></i>
                <h3 style="margin: 0 0 10px 0; color: #333;">${tabNameDisplay} Features</h3>
                <p style="margin: 0 0 15px 0; color: #666;">
                    ${tabNameDisplay} features are coming soon and will be available in a future update.
                </p>
                <button class="nuhello-btn nuhello-btn-primary" style="
                    background: #3F215B;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    cursor: pointer;
                " onclick="this.parentElement.remove()">
                    Got it
                </button>
            </div>
        `);

        $('body').append($message);

        // Auto-remove after 5 seconds
        setTimeout(function() {
            $message.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
    }

    function goToStep(step) {
        // Hide current step content
        $('.step-content.active').removeClass('active');

        // Show new step content
        $(`.step-content[data-step="${step}"]`).addClass('active');

        // Update step indicators
        updateStepIndicators(step);

        // Update current step
        currentStep = parseInt(step);
    }

    function updateStepIndicators(activeStep) {
        $('.step').removeClass('active completed');

        $('.step').each(function(index) {
            const stepNumber = parseInt($(this).data('step'));
            if (stepNumber < activeStep) {
                $(this).addClass('completed');
            } else if (stepNumber == activeStep) {
                $(this).addClass('active');
            }
        });
    }

    function isValidUrl(urlString) {
        if (!urlString) {
            return true; // Allow empty URLs
        }

        // Regular expression to validate a URL, requiring a protocol (http/https) and including localhost.
        const pattern = /^(https?:\/\/)(?:([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}|localhost)(?:\/.*)*$/;

        return pattern.test(urlString);
    }

    function isValidEmail(email) {
        const pattern = /^(([^<>()[\]\.,;:\s@"]+(\.[^<>()[\]\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return pattern.test(String(email).toLowerCase());
    }

    async function validateCurrentStep(nextStep) {
        if (isWelcomePhase) {
            return false; // Welcome phase is handled by start-onboarding button
        }

        switch (currentStep) {
            case 1:
                const chatbotKey = $('#chatbot-selector').val().trim();
                if (!chatbotKey) {
                    showAlertMessage('Please select your chatbot.', 'error');
                    return false;
                }
                break;
            case 2:
                // No validation needed for this step as it's informational
                // or a simple checkbox.
                break;
            case 3:
                // All checkboxes are optional, so no validation needed
                break;
        }
        return true;
    }

    async function sendOtp(email) {
        return new Promise((resolve) => {
            $.ajax({
                url: nuhello_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'nuhello_send_onboarding_otp',
                    email: email,
                    nonce: nuhello_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        if (response.data && response.data.type === 'registration') {
                            // Show account creation section
                            showAccountCreationSection(response.data.key || '', email);
                            showAlertMessage(response.data.message || 'Please check your email for the registration link.', 'success');
                            resolve({ success: true, type: 'registration' });
                        } else {
                            showAlertMessage('OTP sent successfully. Please check your email.', 'success');
                            resolve({ success: true, type: 'otp' });
                        }
                    } else {
                        showAlertMessage(response.data.message || 'Failed to send OTP.', 'error');
                        resolve({ success: false });
                    }
                },
                error: function() {
                    showAlertMessage('An error occurred while sending the OTP.', 'error');
                    resolve({ success: false });
                }
            });
        });
    }

    async function verifyOtp(email, otp) {
        return new Promise((resolve) => {
            $.ajax({
                url: nuhello_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'nuhello_verify_onboarding_otp',
                    email: email,
                    otp: otp,
                    nonce: nuhello_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlertMessage('Email verified successfully!', 'success');
                        const chatbotSelector = $('#chatbot-selector');
                        chatbotSelector.empty(); // Clear existing options

                        if (response.data && response.data.chatbots && Array.isArray(response.data.chatbots) && response.data.chatbots.length > 0) {
                            chatbotSelector.append($('<option>', {
                                value: '',
                                text: 'Select a Chatbot'
                            }));
                            response.data.chatbots.forEach(function(item) {
                                chatbotSelector.append($('<option>', {
                                    value: item.id,
                                    text: item.name
                                }));
                            });
                        } else {
                            chatbotSelector.append($('<option>', {
                                value: '',
                                text: 'No Chatbots found'
                            }));
                        }
                        resolve(true);
                    } else {
                        showAlertMessage(response.data.message || 'Failed to verify OTP.', 'error');
                        resolve(false);
                    }
                },
                error: function() {
                    showAlertMessage('An error occurred while verifying the OTP.', 'error');
                    resolve(false);
                }
            });
        });
    }

    function urlsMatch(urlStr1, urlStr2) {
        if (!urlStr1 || !urlStr2) return false;
        try {
            const url1 = new URL(urlStr1);
            const url2 = new URL(urlStr2);
            return url1.protocol === url2.protocol && url1.hostname === url2.hostname;
        } catch (e) {
            console.error("Invalid URL for comparison:", e);
            return false;
        }
    }

    async function saveStepData() {
        const data = {};
        let action = 'nuhello_save_step';
        let backendStep = currentStep; // Map frontend step to backend step

        switch (currentStep) {
            case 1:
                data.chatbot_id = $('#chatbot-selector').val().trim();
                backendStep = 2; // Backend expects step 2 for chatbot selection
                break;
            case 2:
                data.is_test_env = $('#is-test-env').is(':checked');
                if ($('#edit-production-url-toggle').is(':checked')) {
                    data.production_url = $('#production-url').val();
                }
                backendStep = 3; // Backend expects step 3 for environment
                break;
            case 3:
                data.display_chatbot = $('input[name="display_chatbot"]').is(':checked');
                data.show_all_pages = $('input[name="show_all_pages"]').is(':checked');
                data.enable_analytics = $('input[name="enable_analytics"]').is(':checked');
                data.enable_notifications = $('input[name="enable_notifications"]').is(':checked');
                backendStep = 4; // Backend expects step 4 for settings
                break;
        }

        if (Object.keys(data).length > 0) {
            return new Promise((resolve, reject) => {
                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: action,
                        step: backendStep,
                        data: data,
                        nonce: nuhello_ajax.nonce
                    },
                    success: function(response) {
                        console.log('AJAX Response:', response); // Debug log
                        if (response.success) {
                            if (currentStep === 1) {
                                showAlertMessage('Chatbot saved successfully!', 'success');

                                // Handle environment display based on URL match
                                const responseData = response.data || {};
                                const fullWebsiteUrl = responseData.full_website_url || '';
                                const wordpressSiteUrl = responseData.wordpress_site_url || '';
                                const environmentOptions = $('#environment-options');
                                environmentOptions.empty(); // Clear previous content
                                
                                if (responseData.otp_verified_time) {
                                    localStorage.setItem('nuhello_otp_verified_time', responseData.otp_verified_time);
                                }

                                // Check if we have valid URLs to compare
                                if (fullWebsiteUrl && wordpressSiteUrl) {
                                    try {
                                        const wordpressSiteOrigin = new URL(wordpressSiteUrl).origin;
                                        
                                        if (urlsMatch(fullWebsiteUrl, wordpressSiteUrl)) {
                                            environmentOptions.html(`
                                                <div class="info-box success">
                                                    <p>Your chatbot will appear on: <strong>${fullWebsiteUrl}</strong></p>
                                                </div>
                                                <input type="hidden" id="production-url" value="${fullWebsiteUrl}" />
                                                <input type="hidden" id="is-test-env" value="false" />
                                            `);
                                        } else {
                                            environmentOptions.html(`
                                                <div class="info-box warning">
                                                    <p>Your WordPress website address (<strong>${wordpressSiteOrigin}</strong>) is different from your chatbot's configured address (<strong>${fullWebsiteUrl || 'Not set'}</strong>).</p>
                                                </div>
                                                <div class="form-group">
                                                    <label class="simple-checkbox">
                                                        <input type="checkbox" id="is-test-env" name="is_test_env" />
                                                        I want to test the chatbot on my WordPress site first.
                                                    </label>
                                                    <p class="description">Select this option to test your chatbot on <strong>${wordpressSiteOrigin}</strong> before making it live on the production site. Some features may be limited in the test environment.</p>
                                                </div>
                                                <div class="form-group">
                                                    <label class="simple-checkbox">
                                                    <div id="production-url-warning" class="info-box warning" style="margin-top: 10px;">
                                                        <p><strong>Note:</strong> You can only update the production URL within 10 minutes of verifying your email.</p>
                                                    </div>
                                                        <input type="checkbox" id="edit-production-url-toggle" />
                                                        Update the production website address for my chatbot.
                                                    </label>
                                                </div>
                                                <div class="form-group" id="production-url-container" style="display: none;">
                                                    <label for="production-url">Production URL</label>
                                                    <input type="text" id="production-url" value="${fullWebsiteUrl}" disabled />
                                                </div>
                                            `);
                                        }
                                    } catch (error) {
                                        console.error('Error parsing URLs:', error);
                                        // Fallback: show simple environment setup
                                        environmentOptions.html(`
                                            <div class="info-box success">
                                                <p>Your chatbot has been configured successfully!</p>
                                            </div>
                                        `);
                                    }
                                } else {
                                    // Fallback when URLs are not available
                                    environmentOptions.html(`
                                        <div class="info-box success">
                                            <p>Your chatbot has been configured successfully!</p>
                                        </div>
                                    `);
                                }

                                // Set default values for checkboxes if available
                                if (responseData.display_chatbot !== undefined) {
                                    $('input[name="display_chatbot"]').prop('checked', responseData.display_chatbot);
                                }
                                if (responseData.show_on_all_pages !== undefined) {
                                    $('input[name="show_all_pages"]').prop('checked', responseData.show_on_all_pages);
                                }
                                if (responseData.enable_analytics !== undefined) {
                                    $('input[name="enable_analytics"]').prop('checked', responseData.enable_analytics);
                                }
                                if (responseData.enable_notifications !== undefined) {
                                    $('input[name="enable_notifications"]').prop('checked', responseData.enable_notifications);
                                }
                            }
                            resolve(true);
                        } else {
                            const errorMessage = (response.data && response.data.message) ? response.data.message : 'An unknown error occurred.';
                            showAlertMessage(errorMessage, 'error');
                            resolve(false);
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('AJAX error saving step data', textStatus, errorThrown);
                        showAlertMessage('AJAX error: ' + textStatus, 'error');
                        resolve(false);
                    }
                });
            });
        } else {
            return Promise.resolve(true);
        }
    }

    async function completeOnboarding() {
        // Save final step data
        const data = {
            display_chatbot: $('input[name="display_chatbot"]').is(':checked'),
            show_all_pages: $('input[name="show_all_pages"]').is(':checked'),
            enable_analytics: $('input[name="enable_analytics"]').is(':checked'),
            enable_notifications: $('input[name="enable_notifications"]').is(':checked')
        };

        return new Promise((resolve, reject) => {
            $.ajax({
                url: nuhello_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'nuhello_complete_onboarding',
                    step: 4, // Backend expects step 4 for final step
                    data: data,
                    nonce: nuhello_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        showAlertMessage('Setup completed successfully!', 'success');

                        // Redirect to dashboard after a short delay
                        setTimeout(function() {
                            window.location.href = response.data.redirect_url;
                        }, 1500);
                        resolve();
                    } else {
                        console.error('Failed to complete onboarding');
                        reject();
                    }
                },
                error: function() {
                    console.error('AJAX error completing onboarding');
                    reject();
                }
            });
        });
    }

    function restartOnboarding() {
        showRestartOnboardingModal().then(function(confirmed) {
            if (!confirmed) {
                return;
            }
            executeRestartOnboarding();
        });
    }

    function executeRestartOnboarding() {
        const $mainLoader = $('#configuration-loader-overlay');
        const $settingsPanel = $('#configuration-settings-panel');
        if ($mainLoader.length) {
            $mainLoader.show();
        }
        if ($settingsPanel.length) {
            $settingsPanel.hide();
        }
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_complete_onboarding',
                restart: true,
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    window.location.reload();
                } else {
                    if ($mainLoader.length) {
                        $mainLoader.hide();
                    }
                    if ($settingsPanel.length) {
                        $settingsPanel.show();
                    }
                    showAlertMessage('Failed to restart onboarding.', 'error');
                }
            },
            error: function() {
                if ($mainLoader.length) {
                    $mainLoader.hide();
                }
                if ($settingsPanel.length) {
                    $settingsPanel.show();
                }
                showAlertMessage('An error occurred while restarting onboarding.', 'error');
            }
        });
    }

    function showRestartOnboardingModal() {
        return new Promise(function(resolve) {
            const $modal = $('#restart-onboarding-modal');
            const $confirm = $('#confirm-restart-onboarding');
            const $cancel = $('#cancel-restart-onboarding');
            const $close = $modal.find('.nuhello-modal-close');

            if (!$modal.length) {
                resolve(false);
                return;
            }

            function cleanup(result) {
                $modal.hide();
                $confirm.off('click', onConfirm);
                $cancel.off('click', onCancel);
                $close.off('click', onCancel);
                $modal.off('click', onBackdrop);
                resolve(result);
            }

            function onConfirm(e) {
                e.preventDefault();
                cleanup(true);
            }

            function onCancel(e) {
                e.preventDefault();
                cleanup(false);
            }

            function onBackdrop(e) {
                if (e.target === $modal[0]) {
                    cleanup(false);
                }
            }

            $confirm.on('click', onConfirm);
            $cancel.on('click', onCancel);
            $close.on('click', onCancel);
            $modal.on('click', onBackdrop);
            $modal.show();
        });
    }

    function showAlertMessage(message, type = 'success') {
        // Define icons and colors
        const successIcon = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11.5" fill="white" stroke="#3F215B"/>
                <path d="M9 12.5L11.5 15L17 9.5" stroke="#3F215B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
        const errorIcon = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11.5" fill="white" stroke="#D32F2F"/>
                <path d="M16 8L8 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M8 8L16 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;

        const icon = type === 'success' ? successIcon : errorIcon;
        const textColor = '#333';

        // Create message element
        const $message = $(`
            <div class="nuhello-alert-message" style="
                position: fixed;
                bottom: 30px;
                right: 20px;
                background: #fff;
                color: ${textColor};
                border-radius: 8px;
                z-index: 9999;
                display: flex;
                align-items: center;
                transform: translateY(120%);
                opacity: 0;
                transition: transform 0.4s ease, opacity 0.4s ease;
                padding: 13px;
                border: 1px solid #ededed;
                box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
                font-size: 13px;;
                gap: 8px;
            ">
                ${icon}
                <span style="font-weight: 500;">${message}</span>
            </div>
        `);

        $('body').append($message);

        // Animate in
        setTimeout(function() {
            $message.css({
                'transform': 'translateY(0)',
                'opacity': '1'
            });
        }, 10); // Small delay to ensure transition is applied

        // Remove message after 3 seconds
        setTimeout(function() {
            $message.css({
                'transform': 'translateY(120%)',
                'opacity': '0'
            });
            setTimeout(function() {
                $message.remove();
            }, 400); // Wait for animation to finish
        }, 8000);
    }

    function showAutoDefaultMessage(message) {
        // Remove any existing auto-default message
        hideAutoDefaultMessage();

        // Create auto-default message element
    }

    function hideAutoDefaultMessage() {
        $('.nuhello-auto-default-message').remove();
    }

    $(document).on('change', '#edit-production-url-toggle', function() {
        const isChecked = $(this).is(':checked');
        const productionUrlContainer = $('#production-url-container');
        const productionUrlInput = $('#production-url');

        if (isChecked) {
            const otpVerifiedTime = parseInt(localStorage.getItem('nuhello_otp_verified_time') || '0', 10);
            const now = Math.floor(Date.now() / 1000);
            console.log("OTP Verified Time:", otpVerifiedTime);
            console.log("Current Time:", now);
            if (now - otpVerifiedTime > 600) { // 10 minutes
                showAlertMessage('The 10-minute window to edit the production URL has expired.', 'error');
                $(this).prop('checked', false);
                return;
            }
            productionUrlContainer.show();
            productionUrlInput.prop('disabled', false);
        } else {
            productionUrlContainer.hide();
            productionUrlInput.prop('disabled', true);
        }
    });
    
    // Mobile menu functionality
    function initMobileMenu() {
        const $mobileToggle = $('#mobile-menu-toggle');
        const $sidebar = $('.nuhello-sidebar');
        const $main = $('.nuhello-main');
        
        $mobileToggle.on('click', function() {
            $sidebar.toggleClass('open');
        });
        
        // Close sidebar when clicking outside on mobile
        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$sidebar.is(e.target) && $sidebar.has(e.target).length === 0 && 
                    !$mobileToggle.is(e.target) && $mobileToggle.has(e.target).length === 0) {
                    $sidebar.removeClass('open');
                }
            }
        });
        
        // Close sidebar when window is resized to desktop
        $(window).on('resize', function() {
            if ($(window).width() > 768) {
                $sidebar.removeClass('open');
            }
        });
        
        // Handle WordPress admin sidebar collapse/expand
        function updateSidebarPosition() {
            if ($(window).width() > 768) {
                if ($('body').hasClass('folded')) {
                    $sidebar.css('left', '36px');
                    $main.css('margin-left', '280px');
                } else {
                    $sidebar.css('left', '160px');
                    $main.css('margin-left', '280px');
                }
            }
        }
        
        // Listen for WordPress admin sidebar toggle
        $(document).on('click', '#wp-admin-bar-menu-toggle', function() {
            updateSidebarPosition(); // Immediate update
        });
        
        // Listen for other possible WordPress admin sidebar toggle events
        $(document).on('click', '#collapse-menu', function() {
            updateSidebarPosition(); // Immediate update
        });
        
        // Listen for window resize events
        $(window).on('resize', function() {
            updateSidebarPosition();
        });
        
        // Listen for body class changes (in case WordPress uses other methods)
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    updateSidebarPosition(); // Immediate update
                }
            });
        });
        
        observer.observe(document.body, {
            attributes: true,
            attributeFilter: ['class']
        });
        
        // Initial positioning
        updateSidebarPosition();
    }

    function initDropdownNavigation() {
        // Dropdown navigation toggle
        $('.nav-dropdown-toggle').on('click', function(e) {
            e.preventDefault();
            const $dropdown = $(this).closest('.nav-dropdown');
            const $menu = $dropdown.find('.nav-dropdown-menu');
            
            // Close other dropdowns
            $('.nav-dropdown').not($dropdown).removeClass('active');
            
            // Toggle current dropdown
            $dropdown.toggleClass('active');
        });

        // Close dropdown when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.nav-dropdown').length) {
                $('.nav-dropdown').removeClass('active');
            }
        });
        
        // Cancel account creation button
        $(document).on('click', '#cancel-account-creation', function(e) {
            e.preventDefault();
            cancelAccountCreation();
        });
    }

    function checkRegistrationStatus() {
        // Check if we have registration data from PHP
        if (typeof window.nuhelloRegistrationData !== 'undefined') {
            const regData = window.nuhelloRegistrationData;
            
            // Priority 1: Check if user returned from registration with URL parameters
            // This should happen first, as user is coming back from registration link
            if (regData.registrationEmail && regData.registrationKey) {
                // Hide any visible sections
                $('#email-section').hide();
                $('#otp-section').hide();
                $('#account-creation-section').hide();
                validateSession(regData.registrationEmail, regData.registrationKey);
                return;
            }
            
            // Priority 2: Check if auth token already exists (user has already verified OTP or validated session)
            // If auth token exists and no URL parameters, skip directly to onboarding steps
            if (regData.hasAuthToken) {
                // User has already authenticated, skip directly to onboarding steps
                skipToOnboardingSteps();
                return;
            }
            
            // Priority 3: Check if there's an existing registration session (account creation in progress)
            if (regData.storedRegistrationEmail && regData.storedRegistrationKey && regData.remainingTime > 0) {
                showAccountCreationSection(regData.storedRegistrationKey, regData.storedRegistrationEmail, regData.remainingTime);
                return;
            }
        }
    }
    
    /**
     * Skip directly to onboarding steps if auth token exists
     */
    function skipToOnboardingSteps() {
        // Hide welcome section and show onboarding steps
        $('#welcome-section').hide();
        $('#onboarding-steps').fadeIn(300);
        isWelcomePhase = false;
        currentStep = 1;
        updateStepIndicators(1);
        
        // Load chatbots
        loadChatbotsForOnboarding();
    }
    
    /**
     * Load chatbots for onboarding step 1
     */
    function loadChatbotsForOnboarding() {
        const chatbotSelector = $('#chatbot-selector');
        chatbotSelector.empty();
        chatbotSelector.append($('<option>', {
            value: '',
            text: 'Loading chatbots...'
        }));
        
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_get_chatbots',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                chatbotSelector.empty();
                if (response.success && response.data && response.data.chatbots && Array.isArray(response.data.chatbots) && response.data.chatbots.length > 0) {
                    chatbotSelector.append($('<option>', {
                        value: '',
                        text: 'Select a Chatbot'
                    }));
                    response.data.chatbots.forEach(function(item) {
                        chatbotSelector.append($('<option>', {
                            value: item.id,
                            text: item.name
                        }));
                    });
                } else {
                    chatbotSelector.append($('<option>', {
                        value: '',
                        text: 'No Chatbots found'
                    }));
                }
            },
            error: function() {
                chatbotSelector.empty();
                chatbotSelector.append($('<option>', {
                    value: '',
                    text: 'Failed to load chatbots'
                }));
            }
        });
    }

    function showAccountCreationSection(key, email = '', initialTime = 900) {
        // Hide email and OTP sections
        $('#email-section').hide();
        $('#otp-section').hide();
        
        // Hide the Get Started button
        $('#get-started-button-container').hide();
        
        // Show account creation section
        const displayEmail = email || $('#email-input').val().trim();
        $('#account-creation-email-display').text(displayEmail);
        $('#account-creation-section').fadeIn(300);
        
        // Start countdown timer
        remainingTime = initialTime;
        startCountdownTimer();
    }

    function startCountdownTimer() {
        // Clear any existing interval
        if (countdownInterval) {
            clearInterval(countdownInterval);
        }
        
        // Update display immediately
        updateCountdownDisplay();
        
        // Update every second
        countdownInterval = setInterval(function() {
            remainingTime--;
            updateCountdownDisplay();
            
            if (remainingTime <= 0) {
                clearInterval(countdownInterval);
                countdownInterval = null;
                // Time expired, show email section again
                $('#account-creation-section').fadeOut(300, function() {
                    $('#email-section').fadeIn(300);
                    $('#get-started-button-container').show();
                    $('.start-onboarding .btn-text').text('Get Started');
                    $('.start-onboarding').prop('disabled', false);
                    otpSent = false;
                });
                // Clear registration data
                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'nuhello_clear_registration',
                        nonce: nuhello_ajax.nonce
                    }
                });
            }
        }, 1000);
    }

    function updateCountdownDisplay() {
        const minutes = Math.floor(remainingTime / 60);
        const seconds = remainingTime % 60;
        const display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        $('#countdown-display').text(display);
    }

    function cancelAccountCreation() {
        // Clear countdown
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }
        
        // Hide account creation section
        $('#account-creation-section').fadeOut(300, function() {
            $('#email-section').fadeIn(300);
            $('.step-actions:has(.start-onboarding)').show();
            $('.start-onboarding .btn-text').text('Get Started');
            $('.start-onboarding').prop('disabled', false);
            otpSent = false;
        });
        
        // Clear registration data via AJAX
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_clear_registration',
                nonce: nuhello_ajax.nonce
            }
        });
    }

    function resetOnboardingToEmail($trigger) {
        if ($trigger && $trigger.prop('disabled')) {
            return;
        }

        if ($trigger) {
            $trigger.prop('disabled', true);
        }

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_reset_onboarding_progress',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    localStorage.removeItem('nuhello_otp_verified_time');
                    resetOnboardingUI();
                } else {
                    showAlertMessage((response.data && response.data.message) || 'Failed to reset onboarding.', 'error');
                }
            },
            error: function() {
                showAlertMessage('An error occurred while resetting onboarding.', 'error');
            },
            complete: function() {
                if ($trigger) {
                    $trigger.prop('disabled', false);
                }
            }
        });
    }

    function showCancelOnboardingModal() {
        return new Promise(function(resolve) {
            const $modal = $('#cancel-onboarding-modal');
            const $confirm = $('#cancel-onboarding-yes');
            const $cancel = $('#cancel-onboarding-no');
            const $close = $modal.find('.nuhello-modal-close');

            if (!$modal.length) {
                resolve(false);
                return;
            }

            function cleanup(result) {
                $modal.hide();
                $confirm.off('click', onConfirm);
                $cancel.off('click', onCancel);
                $close.off('click', onCancel);
                $modal.off('click', onBackdrop);
                resolve(result);
            }

            function onConfirm(e) {
                e.preventDefault();
                cleanup(true);
            }

            function onCancel(e) {
                e.preventDefault();
                cleanup(false);
            }

            function onBackdrop(e) {
                if (e.target === $modal[0]) {
                    cleanup(false);
                }
            }

            $confirm.on('click', onConfirm);
            $cancel.on('click', onCancel);
            $close.on('click', onCancel);
            $modal.on('click', onBackdrop);
            $modal.show();
        });
    }

    function resetOnboardingUI() {
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }

        remainingTime = 0;
        otpSent = false;
        isWelcomePhase = true;
        currentStep = 1;

        $('#onboarding-steps').hide();
        $('#account-creation-section').hide();
        $('#otp-section').hide();
        $('#email-section').show();
        $('#welcome-section').fadeIn(300);
        $('#get-started-button-container').show();
        $('.start-onboarding .btn-text').text('Get Started');
        $('.start-onboarding').prop('disabled', false);

        $('#chatbot-selector').val('');
        $('#environment-options').empty();
        updateStepIndicators(1);
        removeIdentifierFromUrl();
    }

    function removeIdentifierFromUrl() {
        if (window.history && window.history.replaceState) {
            const url = new URL(window.location);
            url.searchParams.delete('identifier');
            url.searchParams.delete('email');
            url.searchParams.delete('NUHELLO_WPKEY');
            window.history.replaceState({}, '', url);
        }
    }

    async function validateSession(email, key) {
        showAlertMessage('Validating your account...', 'success');

        
        
        return new Promise((resolve) => {
            $.ajax({
                url: nuhello_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'nuhello_validate_session',
                    email: email,
                    key: key,
                    nonce: nuhello_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlertMessage('Account created and verified successfully!', 'success');
                        
                        // Clear countdown if running
                        if (countdownInterval) {
                            clearInterval(countdownInterval);
                            countdownInterval = null;
                        }
                        
                        // Hide welcome section and show onboarding steps
                        $('#welcome-section').fadeOut(300, function() {
                            $('#onboarding-steps').fadeIn(300);
                            isWelcomePhase = false;
                            currentStep = 1;
                            updateStepIndicators(1);
                            
                            // Load chatbots
                            const chatbotSelector = $('#chatbot-selector');
                            chatbotSelector.empty();
                            
                            if (response.data && response.data.chatbots && Array.isArray(response.data.chatbots) && response.data.chatbots.length > 0) {
                                chatbotSelector.append($('<option>', {
                                    value: '',
                                    text: 'Select a Chatbot'
                                }));
                                response.data.chatbots.forEach(function(item) {
                                    chatbotSelector.append($('<option>', {
                                        value: item.id,
                                        text: item.name
                                    }));
                                });
                            } else {
                                chatbotSelector.append($('<option>', {
                                    value: '',
                                    text: 'No Chatbots found'
                                }));
                            }
                        });
                        
                        // Remove URL parameters
                        removeIdentifierFromUrl();
                        
                        resolve(true);
                    } else {
                        showAlertMessage(response.data.message || 'Failed to validate session.', 'error');
                        // Show email section on error
                        $('#account-creation-section').fadeOut(300, function() {
                            $('#email-section').fadeIn(300);
                        });
                        // Remove URL parameters even on error
                        removeIdentifierFromUrl();
                        resolve(false);
                    }
                },
                error: function() {
                    showAlertMessage('An error occurred while validating your session.', 'error');
                    $('#account-creation-section').fadeOut(300, function() {
                        $('#email-section').fadeIn(300);
                    });
                    // Remove URL parameters even on error
                    removeIdentifierFromUrl();
                    resolve(false);
                }
            });
        });
    }
});