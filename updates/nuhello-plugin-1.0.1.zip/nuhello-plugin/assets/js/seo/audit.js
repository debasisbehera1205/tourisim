(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.audit = Seo.audit || {};
    Seo.state = Seo.state || {
        originalRecommendations: [],
        allAudits: [],
        shouldScrollToTabs: false
    };

    Seo.audit.fetchSeoAudit = function() {
        const urlParams = new URLSearchParams(window.location.search);
        const isFromDashboard = urlParams.get('view') === 'full-report';

        if (isFromDashboard) {
            $('#seo-dashboard-loading').show();
            $('#seo-dashboard-content').hide();
        }

        const $loadingState = $('#seo-dashboard-loading-state');
        const $emptyState = $('#seo-empty-state');
        if ($loadingState.length) {
            $loadingState.show();
        }
        if ($emptyState.length) {
            $emptyState.attr('hidden', 'hidden');
        }

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_get_seo_audit_by_chatbot',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                if (response.success && response.data.payload && response.data.payload.length > 0) {
                    Seo.state.allAudits = response.data.payload;

                    const mostRecentSuccessfulAudit = Seo.state.allAudits.find(audit => audit.status === 'SUCCESS');
                    if (mostRecentSuccessfulAudit) {
                        const audit = mostRecentSuccessfulAudit.auditData;
                        const recommendations = mostRecentSuccessfulAudit.aiRecommendations?.recommendations || [];
                        Seo.state.originalRecommendations = recommendations;

                        Seo.audit.updateUI(audit);
                        Seo.audit.updateAuditsList(Seo.state.allAudits);

                        if (recommendations && recommendations.length > 0) {
                            Seo.recommendations.updateRecommendations(recommendations);
                        }

                        if (isFromDashboard) {
                            Seo.state.shouldScrollToTabs = true;
                            Seo.recommendations.renderAuditDetails(mostRecentSuccessfulAudit, true);

                            setTimeout(function() {
                                $('.seo-tabs-nav .seo-tab-link[data-tab="recommendations"]').click();
                                const newUrl = window.location.pathname + window.location.search.replace(/[?&]view=full-report/, '').replace(/^&/, '?');
                                window.history.replaceState({}, '', newUrl);
                            }, 100);
                        } else {
                            $('#seo-dashboard-loading').hide();
                            $('#seo-dashboard-content').show();
                        }
                    } else {
                        if ($loadingState.length) {
                            $loadingState.hide();
                        }
                        if ($emptyState.length) {
                            $emptyState.removeAttr('hidden');
                        } else {
                            $('#seo-dashboard-loading').html(
                                '<div class="nuhello-empty-state">' +
                                    '<h4>Brand health report not available yet</h4>' +
                                    '<p>Run a brand health audit to see insights about your site\'s performance, accessibility, and trust signals.</p>' +
                                '</div>'
                            );
                        }
                        $('#seo-dashboard-loading').show();
                        $('#seo-dashboard-content').hide();
                    }
                } else {
                    if ($loadingState.length) {
                        $loadingState.hide();
                    }
                    if ($emptyState.length) {
                        $emptyState.removeAttr('hidden');
                    } else {
                        $('#seo-dashboard-loading').html(
                            '<div class="nuhello-empty-state">' +
                                '<h4>Brand health report not available yet</h4>' +
                                '<p>Run a brand health audit to see insights about your site\'s performance, accessibility, and trust signals.</p>' +
                            '</div>'
                        );
                    }
                    $('#seo-dashboard-loading').show();
                    $('#seo-dashboard-content').hide();
                }
            },
            error: function() {
                $('#seo-dashboard-loading').html('<p>An error occurred while fetching SEO audit data.</p>').show();
                $('#seo-dashboard-content').hide();
            }
        });
    };

    Seo.audit.updateUI = function(audit) {
        const data = audit.data || {};
        const $seoContainer = $('#seo-dashboard-content');

        const overallScore = audit.score || 0;
        const scoreLabel = overallScore >= 80 ? 'Good' : (overallScore >= 50 ? 'Average' : 'Poor');
        const scoreBadge = $seoContainer.find('#overall-score-badge');
        scoreBadge.text(scoreLabel);
        scoreBadge.removeClass('badge-good badge-average badge-poor')
            .addClass(overallScore >= 80 ? 'badge-good' : (overallScore >= 50 ? 'badge-average' : 'badge-poor'));

        $seoContainer.find('#overall-score-text').text(overallScore + '/100');

        const circle = $seoContainer.find('#score-circle-progress');
        if (circle.length && circle.get(0)) {
            const radius = circle.get(0).r.baseVal.value;
            const circumference = 2 * Math.PI * radius;
            const offset = circumference - (overallScore / 100) * circumference;
            circle.css('stroke-dashoffset', offset);
            const circleColor = overallScore >= 80 ? 'var(--green-500)' : (overallScore >= 50 ? 'var(--orange-500)' : 'var(--red-600)');
            circle.css('stroke', circleColor);
        }

        $seoContainer.find('#domain-url').text(audit.url);
        $seoContainer.find('#favicon-img').attr('src', `https://www.google.com/s2/favicons?domain=${audit.url}`);

        const failedTests = Object.keys(audit.major_issues || {}).length + Object.keys(audit.moderate_issues || {}).length;
        const warningTests = Object.keys(audit.minor_issues || {}).length;
        $seoContainer.find('#passed-tests').text(audit.passed_tests || 0);
        $seoContainer.find('#failed-tests').text(failedTests);
        $seoContainer.find('#warning-tests').text(warningTests);
        $seoContainer.find('#total-tests-info').text(`${audit.total_tests || 0} total tests`);

        const performanceScore = Math.max(0, Math.round(100 - ((audit.response_time || 2000) / 2000 * 50) - ((audit.ttfb || 1) * 1000 / 1000 * 50)));
        $seoContainer.find('#performance-score').text(performanceScore);
        $seoContainer.find('#load-time').text(Math.round(audit.response_time || 0) + 'ms');
        $seoContainer.find('#ttfb').text(Math.round((audit.ttfb || 0) * 1000) + 'ms');
        $seoContainer.find('#page-size').text(((audit.page_size || 0) / 1024).toFixed(1) + ' KB');
        $seoContainer.find('#performance-progress').css('width', performanceScore + '%');

        const accessibilityScore = Math.max(0, Math.round(100 - ((data.dom_size || 500) / 1500 * 50) - ((300 / (data.words_count || 300)) * 50)));
        $seoContainer.find('#accessibility-score').text(accessibilityScore);
        $seoContainer.find('#dom-size').text((data.dom_size || 0) + ' nodes');
        $seoContainer.find('#word-count').text((data.words_count || 0).toLocaleString());
        $seoContainer.find('#text-html-ratio').text(data.text_to_html_ratio || '0');
        $seoContainer.find('#accessibility-progress').css('width', accessibilityScore + '%');

        const bestPracticesScore = Math.round(((audit.is_https ? 1 : 0) + (data.meta_description ? 1 : 0) + (data.title ? 1 : 0)) / 3 * 100);
        $seoContainer.find('#best-practices-score').text(bestPracticesScore);
        $seoContainer.find('#https-status').html(audit.is_https ? '<span class="value secure">✓ Secure</span>' : '<span class="value insecure">✗ Not Secure</span>');
        $seoContainer.find('#meta-desc-status').html(data.meta_description ? '<span class="value secure">✓ Present</span>' : '<span class="value insecure">✗ Missing</span>');
        $seoContainer.find('#title-status').html(data.title ? '<span class="value secure">✓ Present</span>' : '<span class="value insecure">✗ Missing</span>');
        $seoContainer.find('#best-practices-progress').css('width', bestPracticesScore + '%');

        $seoContainer.find('#security-badge').text(audit.is_https ? 'HTTPS' : 'HTTP');
        $seoContainer.find('#ssl-status').html(audit.is_ssl_valid ? '<span class="value secure">✓ Valid</span>' : '<span class="value insecure">✗ Invalid</span>');
        $seoContainer.find('#http-requests').text(audit.http_requests || 0);
        $seoContainer.find('#download-speed').text(Math.round((audit.average_download_speed || 0) / 1024) + ' KB/s');
        $seoContainer.find('#security-progress').css('width', audit.is_ssl_valid && audit.is_https ? '100%' : '10%');

        Seo.utils.manageRowVisibility($seoContainer.find('.seo-left-column'), [
            { data: overallScore, type: 'score' },
            { data: audit.url, type: 'metric' },
            { data: audit.passed_tests, type: 'score' }
        ]);

        Seo.utils.manageRowVisibility($seoContainer.find('.seo-metrics-column'), [
            { data: performanceScore, type: 'score' },
            { data: accessibilityScore, type: 'score' },
            { data: bestPracticesScore, type: 'score' },
            { data: audit.is_https, type: 'boolean' }
        ]);
    };

    Seo.audit.updateAuditsList = function(audits) {
        const container = $('#audits-list-container');
        container.empty();

        if (!audits || audits.length === 0) {
            container.append('<p>No audit history found.</p>');
            return;
        }

        const list = $('<div class="audits-list"></div>');
        audits.forEach(auditItem => {
            const audit = auditItem.auditData;
            const score = audit.score || 0;
            const majorIssues = Object.keys(audit.major_issues || {}).length;
            const moderateIssues = Object.keys(audit.moderate_issues || {}).length;
            const minorIssues = Object.keys(audit.minor_issues || {}).length;

            const item = $('<div>').addClass('audit-list-item');
            const grid = $('<div>').addClass('audit-list-item-grid');

            const mainInfo = $('<div>').addClass('audit-list-item-main');
            const favicon = $('<img>').attr('src', `https://www.google.com/s2/favicons?domain=${audit.url}`).addClass('audit-favicon');
            const details = $('<div>').addClass('audit-list-item-details');
            const url = $('<a>').attr('href', audit.url).addClass('audit-url').text(audit.url);
            const title = $('<span>').addClass('audit-title').text(audit.data?.title || 'No title found');
            details.append(url, title);
            mainInfo.append(favicon, details);

            const subGrid = $('<div>').addClass('audit-list-item-subgrid');
            const statusScore = $('<div>').addClass('audit-status-score');
            const statusBadge = $('<span>').addClass('badge badge-status-success').text('Success');
            const scoreText = $('<span>').addClass('audit-score').text(score + '%');
            const dots = $('<div>').addClass('audit-dots');
            for (let i = 0; i < 5; i++) {
                const dot = $('<span>');
                if (i < Math.round(score / 20)) {
                    dot.addClass(score >= 90 ? 'dot-green' : 'dot-yellow');
                } else {
                    dot.addClass('dot-muted');
                }
                dots.append(dot);
            }
            statusScore.append(statusBadge, scoreText, dots);

            const issues = $('<div>').addClass('audit-issues');
            if (majorIssues > 0) {
                issues.append($('<span>').addClass('badge badge-issue-major').text(majorIssues));
            }
            if (moderateIssues > 0) {
                issues.append($('<span>').addClass('badge badge-issue-moderate').text(moderateIssues));
            }
            if (minorIssues > 0) {
                issues.append($('<span>').addClass('badge badge-issue-minor').text(minorIssues));
            }

            const actions = $('<div>').addClass('audit-actions');
            const date = $('<span>').addClass('audit-date').text(new Date(auditItem.auditDate).toLocaleDateString());
            const buttons = $('<div>').addClass('audit-action-buttons');
            const viewBtn = $('<button>').attr('title', 'View Details').html('<span class="dashicons dashicons-visibility"></span>');
            viewBtn.data('auditId', auditItem.id || auditItem.auditDate);
            buttons.append(viewBtn);
            actions.append(date, buttons);

            subGrid.append(statusScore, issues, actions);
            grid.append(mainInfo, subGrid);
            item.append(grid);
            list.append(item);
        });

        container.append(list);
    };
})(window, jQuery);
