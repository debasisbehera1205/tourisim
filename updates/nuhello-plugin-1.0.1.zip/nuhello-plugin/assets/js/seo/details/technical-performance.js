(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.details = Seo.details || {};

    Seo.details.renderTechnicalPerformance = function(auditData, container) {
        const data = auditData.data || {};

        const technicalItems = [
            {
                title: 'robots.txt page',
                value: data.has_robots_page ? data.robots_url : 'Not found',
                status: data.has_robots_page,
                description: 'We tested your site for the robots page existence, its validity & exclusion rules.',
                isLink: true,
                solution: "Create a robots.txt file in your website's root directory to control search engine crawling."
            },
            {
                title: '404 page',
                value: data.has_404_page ? `${data.not_found_url} - ${data.not_found_status_code}` : 'Not found',
                status: data.has_404_page,
                description: 'We tested your site against a randomized URL so we can validate if your site returns a 404 status code.',
                isLink: true,
                solution: 'Create a custom 404 error page to improve user experience when pages are not found.'
            },
            {
                title: 'Server tag',
                value: data.response_headers?.server || 'Not found',
                status: null,
                description: 'Make sure to remove the server HTTP header tag to avoid exposing details about your server.',
                warning: {
                    message: 'Server tag is public.',
                    details: 'Make sure to remove the server HTTP header tag to avoid exposing details about your server.'
                },
                solution: 'Configure your web server to remove or hide the Server header to improve security.'
            },
            {
                title: 'Server compression',
                value: data.response_headers?.content_encoding || 'No compression',
                status: !!data.response_headers?.content_encoding,
                description: 'Server compression, like gzip or Brotli, reduces the size of web resources, leading to faster load times.',
                extraInfo: data.page_size && data.download_size ? `${Seo.utils.formatFileSize(data.page_size)} non-compressed vs ${Seo.utils.formatFileSize(data.download_size)} compressed (${Math.round((1 - (data.download_size || 0) / (data.page_size || 1)) * 100)}% difference)` : null,
                solution: 'Enable gzip or Brotli compression on your web server to reduce file sizes and improve loading speed.'
            },
            {
                title: 'Response time',
                value: Seo.utils.formatResponseTime(auditData.response_time || 0),
                status: (auditData.response_time || 0) < 1000,
                description: 'Response time is crucial for SEO; faster pages improve rankings, user experience, and reduce bounce rates.',
                solution: 'Optimize your server performance, use CDN, and minimize server-side processing to reduce response time.'
            },
            {
                title: 'Page size',
                value: Seo.utils.formatFileSize(auditData.page_size || 0),
                status: (auditData.page_size || 0) < 150 * 1024,
                description: 'A smaller page size ensures faster loading times and better user experience.',
                warning: (auditData.page_size || 0) >= 150 * 1024 ? {
                    message: 'Page size is too big.',
                    details: 'It is recommended to keep your page size below 150 KB (kilobytes).'
                } : null,
                solution: 'Optimize images, minify CSS/JS, and remove unnecessary content to reduce page size.'
            },
            {
                title: 'DOM size',
                value: `${data.dom_size || 0} nodes`,
                status: (data.dom_size || 0) < 1500,
                description: 'A smaller DOM size ensures faster rendering, smoother interactivity, and better performance, especially on resource-limited devices.',
                solution: 'Simplify your HTML structure, remove unnecessary elements, and use efficient CSS selectors to reduce DOM size.'
            }
        ];

        const passedItems = technicalItems.filter(item => item.status).length;
        const totalItems = technicalItems.filter(item => item.status !== null).length;

        container.empty();

        Seo.utils.fetchTemplate('technical-performance', function(response) {
            const $template = $(response.data);
            $template.find('.detail-section-subtitle span').text(`${passedItems} out of ${totalItems}`);
            container.append($template);

            const listContainer = container.find('.detail-section-list');
            const getStatusDetails = (status) => {
                if (status === null) return { icon: 'dashicons-warning', label: 'Warning', className: 'status-warning' };
                return status ? { icon: 'dashicons-yes-alt', label: 'Pass', className: 'status-pass' } : { icon: 'dashicons-dismiss', label: 'Fail', className: 'status-fail' };
            };

            const getPriorityDetails = (status) => {
                if (status === null) return { text: 'Medium Priority', className: 'priority-medium' };
                return status ? { text: 'Low Priority', className: 'priority-low' } : { text: 'High Priority', className: 'priority-high' };
            };

            Seo.utils.fetchTemplate('technical-performance-item', function(itemResponse) {
                const itemTemplate = itemResponse.data;
                technicalItems.forEach((item, index) => {
                    const statusDetails = getStatusDetails(item.status);
                    const priorityDetails = getPriorityDetails(item.status);
                    const $itemEl = $(itemTemplate).clone();

                    $itemEl.find('.detail-item-title-group .dashicons').addClass(statusDetails.icon).addClass(statusDetails.className);
                    $itemEl.find('.status-badge').addClass(statusDetails.className).text(statusDetails.label);
                    if (item.status !== null) {
                        $itemEl.find('.priority-badge').addClass(priorityDetails.className).text(priorityDetails.text).show();
                    }
                    $itemEl.find('.detail-item-title').text(item.title);
                    $itemEl.find('.detail-item-description').text(item.description);

                    let valueHtml;
                    if (item.isLink && item.status) {
                        valueHtml = `<a href="${item.value}" target="_blank" rel="noopener noreferrer" class="detail-link-value">${item.value}</a>`;
                    } else {
                        valueHtml = `<code class="detail-code-value">${item.value}</code>`;
                    }
                    $itemEl.find('.detail-value-content').html(valueHtml);

                    if (item.extraInfo) {
                        $itemEl.find('.detail-extra-info').text(`(${item.extraInfo})`).show();
                    }

                    if (item.warning) {
                        const $warning = $itemEl.find('.detail-warning');
                        $warning.find('.detail-warning-title').text(item.warning.message);
                        $warning.find('.detail-warning-text').text(item.warning.details);
                        $warning.show();
                    }

                    if (!item.status) {
                        const $toggle = $itemEl.find('.detail-solution-toggle');
                        $toggle.show().attr('data-index', index);
                        const $solution = $itemEl.find('.detail-solution');
                        $solution.attr('id', `tech-solution-${index}`);
                        $solution.find('.detail-info-box-text').text(item.solution);
                    }

                    listContainer.append($itemEl);
                });
            });
        });

        container.on('click', '.detail-solution-toggle', function() {
            const index = $(this).data('index');
            $(`#tech-solution-${index}`).slideToggle();
        });
    };
})(window, jQuery);
