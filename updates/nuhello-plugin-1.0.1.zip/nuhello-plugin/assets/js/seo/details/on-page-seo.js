(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.details = Seo.details || {};

    Seo.details.renderOnPageSeo = function(auditData, container) {
        const data = auditData.data || {};
        const onPageSeoItems = [
            {
                title: 'Title',
                value: auditData?.title || 'Not found',
                status: auditData?.title?.length > 0 && auditData?.title?.length <= 60,
                description: 'The title tag is crucial for SEO and should be between 50-60 characters.',
                warning: auditData?.title?.length > 60 ? {
                    message: 'Title is too long.',
                    details: 'It is recommended to keep your title between 50-60 characters.'
                } : null,
                extraInfo: `${auditData?.title?.length || 0} characters`,
                solution: 'Optimize your title to be between 50-60 characters for better search engine visibility.'
            },
            {
                title: 'Meta description',
                value: auditData?.meta_description || 'Not found',
                status: !!auditData?.meta_description,
                description: 'A compelling meta description can improve click-through rates from search results.',
                extraInfo: `${auditData?.meta_description?.length || 0} characters`,
                solution: 'Add a compelling meta description between 150-160 characters that accurately describes your page content.'
            },
            {
                title: 'H1 tag',
                value: data?.headings?.h1?.[0] || 'Not found',
                status: data?.headings?.h1?.length === 1,
                description: 'Each page should have exactly one H1 tag that clearly describes the page content.',
                warning: data?.headings?.h1?.length > 1 ? {
                    message: 'Too many H1 tags.',
                    details: 'It is significant to have only one H1 heading tag on your page.'
                } : null,
                extraInfo: data?.headings?.h1?.[0] ? `${data?.headings?.h1[0].length} characters` : null,
                solution: 'Ensure you have exactly one H1 tag per page that clearly describes the main content.'
            },
            {
                title: 'Meta robots',
                value: data?.meta_robots?.join(', ') || 'Not found',
                status: !data?.meta_robots?.some(r => r.includes('noindex') || r.includes('none')),
                description: 'We tested your webpage for the noindex and none properties on the meta robots tag. They should not be included in your webpage to avoid being excluded from search engines.',
                solution: "Remove any 'noindex' or 'none' directives from your meta robots tag to ensure search engines can index your page."
            },
            {
                title: 'Header robots',
                value: data?.response_headers?.['x-robots-tag'] || 'No robots header tag has been used.',
                status: !data?.response_headers?.['x-robots-tag'],
                description: 'We tested your webpage for the noindex and none properties on the X-Robots-Tag header. This header tag should not be included in your webpage to avoid being excluded from search engines.',
                solution: "Ensure your server doesn't send X-Robots-Tag headers with 'noindex' or 'none' directives."
            },
            {
                title: 'Meta keywords',
                value: data?.meta_keywords?.join(', ') || 'Not found',
                status: !data?.meta_keywords || data.meta_keywords.length === 0,
                description: 'Meta keywords are no longer relevant for Google SEO; however, other search engines, such as Baidu and Yandex, still consider them.',
                solution: 'While not required for Google, you can add relevant meta keywords for other search engines if needed.'
            }
        ];

        const passedItems = onPageSeoItems.filter(item => item.status).length;
        const totalItems = onPageSeoItems.length;

        container.empty();

        Seo.utils.fetchTemplate('on-page-seo', function(response) {
            const $template = $(response.data);
            $template.find('.detail-section-subtitle span').text(`${passedItems} out of ${totalItems}`);
            container.append($template);

            const listContainer = container.find('.detail-section-list');
            const getStatusDetails = (status) => {
                if (status === null) return { icon: 'dashicons-warning', label: 'Warning', className: 'status-warning' };
                return status ? { icon: 'dashicons-yes-alt', label: 'Pass', className: 'status-pass' } : { icon: 'dashicons-dismiss', label: 'Fail', className: 'status-fail' };
            };

            const getPriorityDetails = (status) => {
                if (status === null) return { text: 'Medium Priority', className: 'priority-medium' };
                return status ? { text: 'Low Priority', className: 'priority-low' } : { text: 'High Priority', className: 'priority-high' };
            };

            Seo.utils.fetchTemplate('on-page-seo-item', function(itemResponse) {
                const itemTemplate = itemResponse.data;
                onPageSeoItems.forEach((item, index) => {
                    const statusDetails = getStatusDetails(item.status);
                    const priorityDetails = getPriorityDetails(item.status);
                    const $itemEl = $(itemTemplate).clone();

                    $itemEl.find('.detail-item-title-group .dashicons').addClass(statusDetails.icon).addClass(statusDetails.className);
                    $itemEl.find('.status-badge').addClass(statusDetails.className).text(statusDetails.label);
                    $itemEl.find('.priority-badge').addClass(priorityDetails.className).text(priorityDetails.text);
                    $itemEl.find('.detail-item-title').text(item.title);
                    $itemEl.find('.detail-item-description').text(item.description);
                    $itemEl.find('.detail-code-value').text(item.value);

                    if (item.extraInfo) {
                        $itemEl.find('.detail-extra-info').text(`(${item.extraInfo})`).show();
                    }

                    if (item.warning) {
                        const $warning = $itemEl.find('.detail-warning');
                        $warning.find('.detail-warning-title').text(item.warning.message);
                        $warning.find('.detail-warning-text').text(item.warning.details);
                        $warning.show();
                    }

                    if (!item.status) {
                        const $toggle = $itemEl.find('.detail-solution-toggle');
                        $toggle.show().attr('data-index', index);
                        const $solution = $itemEl.find('.detail-solution');
                        $solution.attr('id', `onpage-solution-${index}`);
                        $solution.find('.detail-info-box-text').text(item.solution);
                    }

                    listContainer.append($itemEl);
                });
            });
        });

        container.on('click', '.detail-solution-toggle', function() {
            const index = $(this).data('index');
            $(`#onpage-solution-${index}`).slideToggle();
        });
    };
})(window, jQuery);
