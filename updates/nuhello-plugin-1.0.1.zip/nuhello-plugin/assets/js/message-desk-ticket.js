(function ($) {
    let currentTicket = null;
    let currentTicketId = null;

    function setLoading(isLoading) {
        const $loading = $("#message-desk-ticket-loading");
        if (!$loading.length) return;
        if (isLoading) {
            $loading.removeAttr("hidden");
        } else {
            $loading.attr("hidden", "hidden");
        }
    }

    function escapeHtml(text) {
        return String(text || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function toHtml(text) {
        return `<div>${escapeHtml(text || "").replace(/\n/g, "<br/>")}</div>`;
    }

    function sanitizeEmailHtml(input, fallbackText) {
        const raw = String(input || "").trim();
        if (!raw) return "";
        if (typeof DOMParser === "undefined") {
            return `<div>${escapeHtml(fallbackText || raw).replace(/\n/g, "<br/>")}</div>`;
        }

        const allowedTags = new Set(["B", "STRONG", "I", "EM", "U", "BR", "P", "DIV", "UL", "OL", "LI", "BLOCKQUOTE", "SPAN"]);
        const doc = new DOMParser().parseFromString(raw, "text/html");
        const body = doc.body;

        const walk = (node) => {
            if (node.nodeType === Node.COMMENT_NODE) {
                node.parentNode?.removeChild(node);
                return;
            }
            if (node.nodeType === Node.ELEMENT_NODE) {
                const el = node;
                const tag = el.tagName.toUpperCase();
                if (["SCRIPT", "STYLE", "IFRAME", "OBJECT", "EMBED"].includes(tag)) {
                    el.remove();
                    return;
                }
                if (!allowedTags.has(tag)) {
                    const text = doc.createTextNode(el.textContent || "");
                    el.replaceWith(text);
                    return;
                }
                for (const attr of Array.from(el.attributes)) {
                    el.removeAttribute(attr.name);
                }
            }
            for (const child of Array.from(node.childNodes)) {
                walk(child);
            }
        };

        walk(body);
        return `<div>${body.innerHTML}</div>`;
    }

    function timeAgo(date) {
        const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes} minutes ago`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours} hours ago`;
        const days = Math.floor(hours / 24);
        return `${days} days ago`;
    }

    function formatTimeAgo(value) {
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return "";
        return timeAgo(date);
    }

    function getInitials(name, email) {
        const n = (name || "").trim();
        if (n) {
            const parts = n.split(" ");
            return ((parts[0]?.[0] || "") + (parts[1]?.[0] || "")).toUpperCase() || "U";
        }
        const e = (email || "").trim();
        return (e[0] || "U").toUpperCase();
    }

    function updateReplyFields(ticket) {
        const toEmail = ticket?.email_meta?.customer_email || ticket?.contact?.email || ticket?.contact_form?.email || "";
        const subject = ticket?.AI_analysis?.subject || "No Subject";
        const title = /^re:/i.test(subject) ? subject : `Re: ${subject}`;
        $("#message-desk-reply-to").text(toEmail);
        $("#message-desk-reply-subject").text(title);
    }

    function updateReplySendState() {
        const text = $("#message-desk-reply-text").text();
        const hasText = String(text || "").trim().length > 0;
        $("#message-desk-reply-send").prop("disabled", !hasText);
    }

    function updateToolbarStates() {
        const toolbar = $(".message-desk-reply-toolbar");
        if (!toolbar.length) return;
        const setState = (command, isActive) => {
            toolbar.find(`[data-command="${command}"]`).toggleClass("is-active", !!isActive);
        };
        try {
            setState("bold", document.queryCommandState("bold"));
            setState("italic", document.queryCommandState("italic"));
            setState("underline", document.queryCommandState("underline"));
            setState("insertUnorderedList", document.queryCommandState("insertUnorderedList"));
            setState("insertOrderedList", document.queryCommandState("insertOrderedList"));
            const format = document.queryCommandValue("formatBlock");
            const isQuote = String(format || "").toLowerCase().includes("blockquote");
            setState("formatBlock", isQuote);
        } catch (e) {
            // no-op
        }
    }

    function showToast(message, type) {
        const isError = type === "error";
        const icon = isError
            ? `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="11.5" fill="white" stroke="#D32F2F"/>
                    <path d="M16 8L8 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M8 8L16 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
               </svg>`
            : `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="11.5" fill="white" stroke="#3F215B"/>
                    <path d="M9 12.5L11.5 15L17 9.5" stroke="#3F215B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
               </svg>`;
        const $toast = $(`
            <div class="nuhello-alert-message" style="
                position: fixed;
                bottom: 30px;
                right: 20px;
                background: #fff;
                color: #333;
                border-radius: 8px;
                z-index: 9999;
                display: flex;
                align-items: center;
                transform: translateY(120%);
                opacity: 0;
                transition: transform 0.4s ease, opacity 0.4s ease;
                padding: 12px 14px;
                border: 1px solid #ededed;
                box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
                font-size: 13px;
                gap: 8px;
            ">
                ${icon}
                <span style="font-weight: 500;">${message}</span>
            </div>
        `);
        $("body").append($toast);
        setTimeout(() => $toast.css({ transform: "translateY(0)", opacity: "1" }), 10);
        setTimeout(() => {
            $toast.css({ transform: "translateY(120%)", opacity: "0" });
            setTimeout(() => $toast.remove(), 400);
        }, 3000);
    }

    function toggleBlockquote() {
        const editor = document.getElementById("message-desk-reply-text");
        const selection = document.getSelection();
        if (!editor || !selection || !selection.anchorNode) return;
        const node = selection.anchorNode.nodeType === 1 ? selection.anchorNode : selection.anchorNode.parentElement;
        const blockquote = node ? node.closest("blockquote") : null;
        if (blockquote && editor.contains(blockquote)) {
            const unwrap = (bq) => {
                const parent = bq.parentNode;
                if (!parent) return;
                const frag = document.createDocumentFragment();
                while (bq.firstChild) {
                    frag.appendChild(bq.firstChild);
                }
                parent.replaceChild(frag, bq);
            };
            const allQuotes = editor.querySelectorAll("blockquote");
            if (allQuotes.length) {
                allQuotes.forEach(unwrap);
            } else {
                unwrap(blockquote);
            }
            updateToolbarStates();
            return;
        }
        document.execCommand("formatBlock", false, "blockquote");
        updateToolbarStates();
    }

    function clearReplyForm() {
        const $editor = $("#message-desk-reply-text");
        $editor.html("");
        $editor.text("");
        $("#message-desk-reply-error").attr("hidden", "hidden").text("");
        $("#message-desk-reply-send").prop("disabled", true).text("Send");
        updateReplySendState();
    }

    function renderTicket(ticket) {
        currentTicket = ticket || null;
        currentTicketId = ticket?.id || ticket?._id || null;

        const name = ticket?.email_meta?.customer_name || ticket?.contact?.name || ticket?.contact_form?.fullname || "Unknown";
        const email = ticket?.email_meta?.customer_email || ticket?.contact?.email || ticket?.contact_form?.email || "";
        const subject = ticket?.AI_analysis?.subject || "No Subject";
        const status = ticket?.status || "open";
        const type = ticket?.ticket_type || ticket?.ticket_source || "ticket";
        const viewed = typeof ticket?.labels?.viewed === "boolean" ? (ticket.labels.viewed ? "Viewed" : "Unviewed") : null;
        const category = ticket?.AI_analysis?.category || "";

        const badges = [
            `<span class="message-desk-ticket-badge">${type}</span>`,
            `<span class="message-desk-ticket-badge">${status}</span>`
        ];
        if (viewed) badges.push(`<span class="message-desk-ticket-badge">${viewed}</span>`);
        if (category) badges.push(`<span class="message-desk-ticket-badge">${category}</span>`);

        const emailChain = Array.isArray(ticket?.email_chain) ? ticket.email_chain : [];
        const contentItems = emailChain.length
            ? emailChain
            : [{
                direction: ticket?.ticket_source || "inbound",
                sender_name: name,
                sender_email: email,
                content: ticket?.AI_analysis?.summary || "",
                timestamp: ticket?.last_updated || ticket?.created_at
            }];

        const main = contentItems[0];
        const mainContent = sanitizeEmailHtml(main?.content || "", ticket?.AI_analysis?.summary || "");
        const threadItems = contentItems.slice(1).map((item) => {
            const fromName = item.sender_name || name;
            const fromEmail = item.sender_email || email;
            const content = sanitizeEmailHtml(item.content || "", ticket?.AI_analysis?.summary || "");
            return `
                <div class="message-desk-ticket-item">
                    <div class="message-desk-ticket-item__header">
                        <div class="message-desk-ticket-item__from">${escapeHtml(fromName)}${fromEmail ? ` <span class="message-desk-ticket-item__email">&lt;${escapeHtml(fromEmail)}&gt;</span>` : ""}</div>
                        <div class="message-desk-ticket-item__time">${formatTimeAgo(item.timestamp || ticket?.last_updated || ticket?.created_at)}</div>
                    </div>
                    <div class="message-desk-ticket-item__content">${content}</div>
                </div>
            `;
        });

        const html = `
            <div class="message-desk-ticket-header">
                <h3 class="message-desk-ticket-subject">${escapeHtml(subject)}</h3>
                <div class="message-desk-ticket-meta">${badges.join("")}</div>
            </div>
            <div class="message-desk-ticket-body">
                <div class="message-desk-ticket-sender">
                    <div class="message-desk-ticket-avatar">${getInitials(name, email)}</div>
                    <div>
                        <div class="message-desk-ticket-sender-name">${escapeHtml(name)}</div>
                        <div class="message-desk-ticket-sender-email">${email ? `&lt;${escapeHtml(email)}&gt;` : ""}</div>
                    </div>
                </div>
                <div class="message-desk-ticket-content">${mainContent}</div>
            </div>
            ${threadItems.length ? `<div class="message-desk-ticket-thread">${threadItems.join("")}</div>` : ""}
        `;

        $("#message-desk-ticket-content").html(html);
        updateReplyFields(ticket);
        setLoading(false);
    }

    function fetchTicket(ticketId) {
        setLoading(true);
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: "GET",
            data: {
                action: "nuhello_get_message_desk_ticket",
                nonce: nuhello_ajax.nonce,
                ticket_id: ticketId
            },
            success: function (response) {
                const payload = response && response.success ? response.data : response;
                renderTicket(payload?.ticket || payload);
            },
            error: function () {
                $("#message-desk-ticket-content").html("<div class=\"message-desk-empty\">Failed to load ticket details.</div>");
                setLoading(false);
            }
        });
    }

    function sendReplyEmail() {
        const editor = $("#message-desk-reply-text");
        const messageText = editor.text();
        const messageHtml = editor.html();
        if (!messageText || !currentTicketId) return;

        const toEmail = currentTicket?.email_meta?.customer_email || currentTicket?.contact?.email || currentTicket?.contact_form?.email || "";
        const subject = currentTicket?.AI_analysis?.subject || "No Subject";
        const title = /^re:/i.test(subject) ? subject : `Re: ${subject}`;
        const replyTo = currentTicket?.email_meta?.alias || "";

        $("#message-desk-reply-send").prop("disabled", true).text("Sending...");

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: "POST",
            data: {
                action: "nuhello_send_message_desk_email",
                nonce: nuhello_ajax.nonce,
                ticket_id: currentTicketId,
                email: toEmail,
                title,
                content: sanitizeEmailHtml(messageHtml || "", messageText) || toHtml(messageText),
                channel: JSON.stringify(["EMAIL"]),
                type: "SUPPORT",
                replyTo
            },
            success: function (response) {
                const payload = response?.data;
                const apiSuccess = response?.success !== false;
                if (!apiSuccess) {
                    const err = payload?.message || "Failed to send reply.";
                    $("#message-desk-reply-error").text(err).removeAttr("hidden");
                    showToast(err, "error");
                    return;
                }
                clearReplyForm();
                $("#message-desk-reply-card").attr("hidden", "hidden");
                if (currentTicketId) {
                    fetchTicket(currentTicketId);
                }
                showToast("Email sent successfully!", "success");
            },
            error: function (xhr) {
                const err = xhr?.responseJSON?.data?.message || "Failed to send reply.";
                $("#message-desk-reply-error").text(err).removeAttr("hidden");
                showToast(err, "error");
            },
            complete: function () {
                updateReplySendState();
                $("#message-desk-reply-send").text("Send");
            }
        });
    }

    function copyInboxEmail() {
        const $button = $(".message-desk-copy");
        const email = $button.data("copy");
        if (!email || !navigator.clipboard) return;
        navigator.clipboard.writeText(email).then(() => {
            $button.addClass("is-copied");
            setTimeout(() => $button.removeClass("is-copied"), 1500);
        });
    }

    $(document).ready(function () {
        const ticketId = $("#message-desk-ticket-detail").data("ticket-id");
        if (ticketId) {
            fetchTicket(ticketId);
        }

        $(".message-desk-copy").on("click", copyInboxEmail);

        $(document).on("click", "#message-desk-reply-open", function () {
            $("#message-desk-reply-card").removeAttr("hidden");
            updateReplySendState();
            $("#message-desk-reply-text").trigger("focus");
        });

        $(document).on("click", "#message-desk-reply-close", function () {
            $("#message-desk-reply-card").attr("hidden", "hidden");
            clearReplyForm();
        });

        $(document).on("click", "#message-desk-reply-discard", function () {
            $("#message-desk-reply-card").attr("hidden", "hidden");
            clearReplyForm();
        });

        $(document).on("input", "#message-desk-reply-text", updateReplySendState);

        $(document).on("click", ".message-desk-reply-tool", function () {
            const command = $(this).data("command");
            const value = $(this).data("value");
            const editor = document.getElementById("message-desk-reply-text");
            if (!editor) return;
            editor.focus();
            if (command === "formatBlock" && value === "blockquote") {
                toggleBlockquote();
                return;
            }
            if (command === "formatBlock" && value) {
                document.execCommand(command, false, value);
                updateToolbarStates();
                return;
            }
            document.execCommand(command, false, null);
            updateReplySendState();
            updateToolbarStates();
        });

        document.addEventListener("selectionchange", function () {
            const editor = document.getElementById("message-desk-reply-text");
            if (!editor) return;
            const selection = document.getSelection();
            if (!selection || !selection.anchorNode) return;
            if (!editor.contains(selection.anchorNode)) return;
            updateToolbarStates();
        });

        $(document).on("click", "#message-desk-reply-send", function (event) {
            event.preventDefault();
            sendReplyEmail();
        });
    });
})(jQuery);
