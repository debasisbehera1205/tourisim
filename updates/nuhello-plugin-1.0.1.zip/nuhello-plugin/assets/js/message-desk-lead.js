(function ($) {
    function setLoading(isLoading) {
        const $loading = $("#message-desk-lead-loading");
        if (!$loading.length) return;
        if (isLoading) {
            $loading.removeAttr("hidden");
        } else {
            $loading.attr("hidden", "hidden");
        }
    }

    function escapeHtml(text) {
        return String(text || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function renderLead(lead) {
        const name = lead?.contact_form?.fullname || "Unknown";
        const email = lead?.contact_form?.email || "";
        const phone = lead?.contact_form?.contact || "";
        const message = lead?.lead_context || lead?.context || lead?.contact_form?.message || "";
        const receivedFrom = lead?.received_from || "";
        const status = lead?.status || "new";

        const html = `
            <div class="message-desk-lead-header">
                <h3 class="message-desk-lead-title">${escapeHtml(name)}</h3>
            </div>
            <div class="message-desk-lead-body">
                <div class="message-desk-lead-meta">
                    <div><strong>Email:</strong> ${email ? escapeHtml(email) : "—"}</div>
                    <div><strong>Phone:</strong> ${phone ? escapeHtml(phone) : "—"}</div>
                    <div><strong>Status:</strong> ${escapeHtml(status)}</div>
                    <div><strong>Location:</strong> ${receivedFrom ? escapeHtml(receivedFrom) : "—"}</div>
                </div>
                <div class="message-desk-lead-message">${message ? escapeHtml(message).replace(/\n/g, "<br/>") : "No message provided."}</div>
            </div>
        `;

        $("#message-desk-lead-content").html(html);
        setLoading(false);
    }

    function fetchLead(leadId) {
        setLoading(true);
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: "GET",
            data: {
                action: "nuhello_get_message_desk_lead",
                nonce: nuhello_ajax.nonce,
                lead_id: leadId
            },
            success: function (response) {
                const payload = response && response.success ? response.data : response;
                renderLead(payload?.lead || payload);
            },
            error: function () {
                $("#message-desk-lead-content").html("<div class=\"message-desk-empty\">Failed to load lead.</div>");
                setLoading(false);
            }
        });
    }

    function copyInboxEmail() {
        const $button = $(".message-desk-copy");
        const email = $button.data("copy");
        if (!email || !navigator.clipboard) return;
        navigator.clipboard.writeText(email).then(() => {
            $button.addClass("is-copied");
            setTimeout(() => $button.removeClass("is-copied"), 1500);
        });
    }

    $(document).ready(function () {
        const leadId = $("#message-desk-lead-detail").data("lead-id");
        if (leadId) {
            fetchLead(leadId);
        }
        $(".message-desk-copy").on("click", copyInboxEmail);
    });
})(jQuery);
