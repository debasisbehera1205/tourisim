<?php
/**
 * Plugin Name: Nuhello Plugin
 * Description: Connect and manage your Nuhello chatbot from WordPress with a guided onboarding flow, environment setup, and analytics settings.
 * Plugin URI: https://nuhello.dev
 * Author URI: https://nuhello.dev
 * Version: 1.0.1
 * Author: Nuhello
 * Text Domain: nuhello-plugin
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('NUHELLO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('NUHELLO_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('NUHELLO_PLUGIN_VERSION', '1.0.1');
// Optional: set this to your self-hosted update JSON URL.
define('NUHELLO_UPDATE_JSON_URL', 'https://cf.debasis.free.nf/updates/nuhello-plugin.json');
// URLs should not have trailing slashes
// define('NUHELLO_AUTH_API_URL', 'http://127.0.0.1:4000');
define('NUHELLO_AUTH_API_URL', 'https://core-api.nuhello.dev');
// define('NUHELLO_FLASK_API_URL', 'http://127.0.0.1:5300');
define('NUHELLO_FLASK_API_URL', 'https://flask-api.nuhello.dev');
// define('NUHELLO_FRONT_URL', 'http://127.0.0.1:7700');
define('NUHELLO_FRONT_URL', 'https://dashboard.nuhello.dev');

// Include required files
require_once NUHELLO_PLUGIN_PATH . 'includes/class-nuhello-plugin.php';
require_once NUHELLO_PLUGIN_PATH . 'includes/class-utils.php';
require_once NUHELLO_PLUGIN_PATH . 'includes/class-admin-menu.php';
require_once NUHELLO_PLUGIN_PATH . 'includes/class-onboarding.php';
require_once NUHELLO_PLUGIN_PATH . 'includes/class-dashboard.php';
require_once NUHELLO_PLUGIN_PATH . 'includes/class-ajax-handler.php';
require_once NUHELLO_PLUGIN_PATH . 'includes/class-assets.php';
require_once NUHELLO_PLUGIN_PATH . 'includes/class-email-validation-handler.php';
require_once NUHELLO_PLUGIN_PATH . 'includes/class-json-updater.php';

// Initialize the plugin
function nuhello_plugin_init() {
    new Nuhello_Plugin();
}
add_action('plugins_loaded', 'nuhello_plugin_init');

// Add Settings link on the Plugins page
function nuhello_plugin_action_links($links) {
    $settings_url = admin_url('admin.php?page=nuhello-dashboard');
    $settings_link = '<a href="' . esc_url($settings_url) . '">' . esc_html__('Settings', 'nuhello-plugin') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'nuhello_plugin_action_links');

// Activation hook
register_activation_hook(__FILE__, 'nuhello_plugin_activate');
function nuhello_plugin_activate() {
    // Add default options if they don't exist
    add_option('nuhello_onboarding_completed', false);
    add_option('nuhello_environment', 'testing');
    add_option('nuhello_testing_url', '');
    add_option('nuhello_production_url', '');
    add_option('nuhello_testing_default', false);
    add_option('nuhello_production_default', false);
    add_option('nuhello_display_chatbot', true);
    add_option('nuhello_show_all_pages', true);
    add_option('nuhello_enable_analytics', true);
    add_option('nuhello_enable_notifications', true);
    add_option('nuhello_chatbot_email', '');
    
    // Email validation defaults
    add_option('nuhello_email_validation_allowed_statuses', array('Valid'));
    add_option('nuhello_email_validation_allowed_safe_to_send', array('yes'));
    add_option('nuhello_email_validation_blocked_types', array('Free Account'));
    add_option('nuhello_email_validation_error_message', '');
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'nuhello_plugin_deactivate');
function nuhello_plugin_deactivate() {
    // Cleanup if needed
}
