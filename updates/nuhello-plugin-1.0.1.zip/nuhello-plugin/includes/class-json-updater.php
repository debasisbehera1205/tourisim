<?php
/**
 * JSON Updater for Nuhello Plugin
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Json_Updater {
    private $plugin_file;
    private $plugin_basename;
    private $slug;
    private $current_version;
    private $cache_key = 'nuhello_json_release';
    private $cache_ttl = 6 * HOUR_IN_SECONDS;

    public function __construct($plugin_file, $current_version) {
        $this->plugin_file = $plugin_file;
        $this->plugin_basename = plugin_basename($plugin_file);
        $this->slug = dirname($this->plugin_basename);
        $this->current_version = $current_version;

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_updates']);
        add_filter('plugins_api', [$this, 'plugins_api'], 20, 3);
        add_action('upgrader_process_complete', [$this, 'clear_cache'], 10, 2);
    }

    public function check_for_updates($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $release = $this->get_latest_release();
        if (!$release || empty($release['version'])) {
            return $transient;
        }

        if (version_compare($this->current_version, $release['version'], '<')) {
            $update = (object) [
                'slug' => $this->slug,
                'plugin' => $this->plugin_basename,
                'new_version' => $release['version'],
                'url' => $release['homepage'],
                'package' => $release['zip_url'],
                'tested' => get_bloginfo('version'),
            ];

            $transient->response[$this->plugin_basename] = $update;
        }

        return $transient;
    }

    public function plugins_api($result, $action, $args) {
        if ($action !== 'plugin_information') {
            return $result;
        }

        if (empty($args->slug) || $args->slug !== $this->slug) {
            return $result;
        }

        $release = $this->get_latest_release();
        if (!$release) {
            return $result;
        }

        $info = (object) [
            'name' => 'Nuhello Plugin',
            'slug' => $this->slug,
            'version' => $release['version'] ?? $this->current_version,
            'author' => '<a href="https://nuhello.dev">Nuhello</a>',
            'homepage' => $release['homepage'],
            'download_link' => $release['zip_url'],
            'sections' => [
                'description' => 'A WordPress plugin with dashboard and onboarding wizard.',
                'changelog' => !empty($release['changelog']) ? wp_kses_post($release['changelog']) : 'See release notes for details.',
            ],
        ];

        return $info;
    }

    public function clear_cache($upgrader, $options) {
        if (!empty($options['action']) && $options['action'] === 'update' && !empty($options['type']) && $options['type'] === 'plugin') {
            delete_transient($this->cache_key);
        }
    }

    private function get_latest_release() {
        $cached = get_transient($this->cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $url = $this->get_update_url();
        if (!$url) {
            return null;
        }

        $request = wp_remote_get(
            $url,
            [
                'timeout' => 15,
                'headers' => [
                    'Accept' => 'application/json',
                    'User-Agent' => 'WordPress/' . get_bloginfo('version'),
                ],
            ]
        );

        if (is_wp_error($request)) {
            return null;
        }

        $status = wp_remote_retrieve_response_code($request);
        if ($status !== 200) {
            return null;
        }

        $body = json_decode(wp_remote_retrieve_body($request), true);
        if (empty($body) || empty($body['version']) || empty($body['zip_url'])) {
            return null;
        }

        $release = [
            'version' => (string) $body['version'],
            'zip_url' => (string) $body['zip_url'],
            'homepage' => !empty($body['homepage']) ? (string) $body['homepage'] : '',
            'changelog' => !empty($body['changelog']) ? (string) $body['changelog'] : '',
        ];

        set_transient($this->cache_key, $release, $this->cache_ttl);
        return $release;
    }

    private function get_update_url() {
        if (defined('NUHELLO_UPDATE_JSON_URL') && NUHELLO_UPDATE_JSON_URL) {
            return NUHELLO_UPDATE_JSON_URL;
        }

        $filtered = apply_filters('nuhello_update_json_url', '');
        if (!empty($filtered)) {
            return $filtered;
        }

        return '';
    }
}
