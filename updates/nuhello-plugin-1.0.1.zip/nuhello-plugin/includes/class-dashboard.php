<?php
/**
 * Dashboard Handler
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Dashboard {
    
    public function __construct() {
        // Constructor for future initialization if needed
    }
    
    /**
     * Render dashboard
     */
    public function render() {
        include NUHELLO_PLUGIN_PATH . 'admin/views/dashboard.php';
    }
    
    /**
     * Get current tab
     */
    public function get_current_tab() {
        return isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
    }
    
    /**
     * Get current sub-tab
     */
    public function get_current_subtab() {
        return isset($_GET['subtab']) ? sanitize_text_field($_GET['subtab']) : null;
    }
    
    /**
     * Get available tabs
     */
    public function get_tabs() {
        return array(
            'dashboard' => array(
                'title' => 'Dashboard',
                'icon' => 'dashicons-dashboard',
                'enabled' => true
            ),
            'customize' => array(
                'title' => 'Chatbot',
                'icon' => 'dashicons-admin-appearance',
                'enabled' => true
            ),
            'configuration' => array(
                'title' => 'Configuration',
                'icon' => 'dashicons-admin-settings',
                'enabled' => true
            ),
            'seo' => array(
                'title' => 'Brand Health',
                'icon' => 'dashicons-search',
                'enabled' => true,
                'coming_soon' => false
            ),
            'message-desk' => array(
                'title' => 'Message Desk',
                'icon' => 'dashicons-email-alt',
                'enabled' => true
            ),
            // 'notifications' => array(
            //     'title' => 'Notifications',
            //     'icon' => 'dashicons-bell',
            //     'enabled' => true,
            //     'has_subtabs' => true,
            //     'subtabs' => array(
            //         'subscriber-button' => array(
            //             'title' => 'Subscriber Button',
            //             'icon' => 'dashicons-email-alt',
            //             'enabled' => true
            //         ),
            //         'campaigns' => array(
            //             'title' => 'Campaigns',
            //             'icon' => 'dashicons-megaphone',
            //             'enabled' => true
            //         )
            //     )
            // ),
            // 'Customer Verification' => array(
            //     'title' => 'Customer Verification',
            //     'icon' => 'dashicons-email',
            //     'enabled' => true,
            //     'has_subtabs' => true,
            //     'subtabs' => array(
            //         'email-verification' => array(
            //             'title' => 'Email Verifier',
            //             'icon' => 'dashicons-email-alt2',
            //             'enabled' => true
            //         )
            //     )
            // )
        );
    }
} 