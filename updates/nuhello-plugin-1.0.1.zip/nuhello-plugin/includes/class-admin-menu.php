<?php
/**
 * Admin Menu Handler
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Admin_Menu {
    
    private $plugin;
    
    public function __construct($plugin) {
        $this->plugin = $plugin;
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'Nuhello',
            'Nuhello',
            'manage_options',
            'nuhello-dashboard',
            array($this, 'render_dashboard_page'),
            'dashicons-format-chat',
            30
        );
    }
    
    /**
     * Render dashboard page
     */
    public function render_dashboard_page() {
        $onboarding_completed = get_option('nuhello_onboarding_completed', false);
        
        if (!$onboarding_completed) {
            $this->plugin->onboarding->render();
        } else {
            $this->plugin->dashboard->render();
        }
    }

    /**
     * Render SEO audit page
     */
    public function render_seo_audit_page() {
        include_once NUHELLO_PLUGIN_DIR . 'admin/views/tabs/seo.php';
    }
}