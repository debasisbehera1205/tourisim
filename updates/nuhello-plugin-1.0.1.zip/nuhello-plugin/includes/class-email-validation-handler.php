<?php
/**
 * Email Validation Handler
 * 
 * Validates email addresses during WordPress user registration
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Email_Validation_Handler extends Nuhello_Utils {
    private const EMAIL_VALIDATION_STATUS_META_KEY = 'nuhello_email_validation_status';
    
    /**
     * Constructor
     */
    public function __construct() {
        // Hook into registration errors (for WordPress core registration)
        add_filter('registration_errors', array($this, 'validate_email_registration_errors'), 10, 3);
        
        // Hook into user_register for third-party plugins (fires after user is created)
        add_action('user_register', array($this, 'validate_email_on_user_register'), 10, 1);
        
        // Hook into wp_insert_user_data to validate before user is created (for third-party plugins)
        add_filter('wp_pre_insert_user_data', array($this, 'validate_email_before_insert'), 10, 3);
        
        // Hook into user_profile_update_errors for admin user creation/editing
        add_action('user_profile_update_errors', array($this, 'validate_email_admin_creation'), 10, 3);
        
        // Hook into users list to add email validation icon
        add_action('admin_footer-users.php', array($this, 'add_users_list_email_validation_script'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_users_list_scripts'));

        // Hook into users list to add email validation status column
        add_filter('manage_users_columns', array($this, 'add_email_validation_status_column'));
        add_filter('manage_users_custom_column', array($this, 'render_email_validation_status_column'), 10, 3);
        add_filter('manage_users_sortable_columns', array($this, 'add_email_validation_sortable_columns'));
        add_action('pre_get_users', array($this, 'handle_email_validation_sorting'));
    }
    
    /**
     * Check if email validation is enabled
     * 
     * @return bool
     */
    private function is_email_validation_enabled() {
        $value = get_option('nuhello_enable_email_validation', false);
        // Handle both boolean and string values (WordPress might store as '1' or '0')
        return ($value === true || $value === '1' || $value === 1 || $value === 'true');
    }
    
    /**
     * Get allowed status values
     * 
     * @return array
     */
    private function get_allowed_statuses() {
        return get_option('nuhello_email_validation_allowed_statuses', array('Valid'));
    }
    
    /**
     * Get allowed safe to send values
     * 
     * @return array
     */
    private function get_allowed_safe_to_send() {
        return get_option('nuhello_email_validation_allowed_safe_to_send', array('yes'));
    }
    
    /**
     * Get blocked type values
     * 
     * @return array
     */
    private function get_blocked_types() {
        return get_option('nuhello_email_validation_blocked_types', array('Free Account'));
    }
    
    /**
     * Get custom error message
     * 
     * @return string
     */
    private function get_custom_error_message() {
        return get_option('nuhello_email_validation_error_message', '');
    }
    
    /**
     * Format error message with placeholders
     * 
     * @param string $template Error message template
     * @param string $status Status value
     * @param string $safetosend Safe to send value (normalized: yes, risky, unknown)
     * @param string $type Type value
     * @return string Formatted error message
     */
    private function format_error_template($template, $status = '', $safetosend = '', $type = '') {
        $message = $template;
        $message = str_replace('{status}', $status, $message);
        
        // Format safetosend for display: yes -> Yes, risky -> Risky, unknown -> Unknown
        $safetosend_display = ucfirst($safetosend);
        if ($safetosend === 'yes') {
            $safetosend_display = 'Yes';
        } elseif ($safetosend === 'risky') {
            $safetosend_display = 'Risky';
        } elseif ($safetosend === 'unknown' || empty($safetosend)) {
            $safetosend_display = 'Unknown';
        }
        $message = str_replace('{safetosend}', $safetosend_display, $message);
        
        // Format type for display
        $type_display = $type === '' ? 'Empty/Not Specified' : $type;
        $message = str_replace('{type}', $type_display, $message);
        
        return $message;
    }
    
    /**
     * Extract validation data from API result
     * 
     * @param array|null $result API response
     * @return array|null Array with 'status', 'safetosend', 'type', or null if invalid
     */
    private function extract_validation_data_from_result($result) {
        if ($result === null || !isset($result['data']) || !is_array($result['data']) || empty($result['data'])) {
            return null;
        }
        
        $first_result = $result['data'][0];
        if (!isset($first_result['response'])) {
            return null;
        }
        
        $response = $first_result['response'];
        $safetosend = isset($response['safetosend']) ? $response['safetosend'] : 'unknown';
        
        // Normalize safetosend: "Yes" -> "yes", "No" -> "risky"
        $safetosend = strtolower($safetosend);
        if ($safetosend === 'no') {
            $safetosend = 'risky';
        }
        
        return array(
            'status' => isset($response['status']) ? $response['status'] : 'Unknown',
            'safetosend' => $safetosend,
            'type' => isset($response['type']) ? $response['type'] : ''
        );
    }
    
    /**
     * Validate email against criteria
     * 
     * @param array $validation_data Validation data from API (status, safetosend, type)
     * @return array Array with 'valid' (bool) and 'reason' (string) keys
     */
    private function validate_email_criteria($validation_data) {
        $allowed_statuses = $this->get_allowed_statuses();
        $allowed_safe_to_send = $this->get_allowed_safe_to_send();
        $blocked_types = $this->get_blocked_types();
        $custom_error_message = $this->get_custom_error_message();
        
        $status = $validation_data['status'];
        $safetosend = $validation_data['safetosend']; // Already normalized in extract_validation_data_from_result
        $type = $validation_data['type'];
        
        // Check status
        if (!in_array($status, $allowed_statuses)) {
            $error_reason = '';
            if (!empty($custom_error_message)) {
                // Use custom error message with placeholder replacement
                $error_reason = $this->format_error_template($custom_error_message, $status, $safetosend, $type);
            } else {
                // Use default error message
                $error_reason = sprintf(
                    __('Email status "%s" is not allowed. Allowed statuses: %s.', 'nuhello'),
                    $status,
                    implode(', ', $allowed_statuses)
                );
            }
            return array(
                'valid' => false,
                'reason' => $error_reason,
                'field' => 'status',
                'value' => $status
            );
        }
        
        // Check safe to send
        if (!in_array($safetosend, $allowed_safe_to_send)) {
            $error_reason = '';
            if (!empty($custom_error_message)) {
                // Use custom error message with placeholder replacement
                $error_reason = $this->format_error_template($custom_error_message, $status, $safetosend, $type);
            } else {
                // Use default error message
                $error_reason = sprintf(
                    __('Email is marked as "%s" which is not allowed. Only "%s" emails are permitted.', 'nuhello'),
                    $safetosend === 'risky' ? 'risky' : $safetosend,
                    implode('" or "', $allowed_safe_to_send)
                );
            }
            return array(
                'valid' => false,
                'reason' => $error_reason,
                'field' => 'safetosend',
                'value' => $safetosend
            );
        }
        
        // Check type (blocked types should not be allowed)
        if (in_array($type, $blocked_types)) {
            $type_label = $type === '' ? 'Empty/Not Specified' : $type;
            $error_reason = '';
            if (!empty($custom_error_message)) {
                // Use custom error message with placeholder replacement
                $error_reason = $this->format_error_template($custom_error_message, $status, $safetosend, $type);
            } else {
                // Use default error message
                $error_reason = sprintf(
                    __('Registrations from %s email accounts are not permitted.', 'nuhello'),
                    strtolower($type_label)
                );
            }
            return array(
                'valid' => false,
                'reason' => $error_reason,
                'field' => 'type',
                'value' => $type
            );
        }
        
        return array('valid' => true);
    }
    
    /**
     * Check if current request is AJAX
     * 
     * @return bool
     */
    private function is_ajax_request() {
        return wp_doing_ajax() 
            || (defined('DOING_AJAX') && DOING_AJAX) 
            || (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
    }
    
    /**
     * Detect expected response format based on request context
     * 
     * @return string Response format type: 'wordpress_standard', 'custom_plugin', or 'universal'
     */
    private function detect_response_format() {
        // Check for WordPress standard AJAX action pattern
        $action = isset($_REQUEST['action']) ? sanitize_text_field($_REQUEST['action']) : '';
        
        // WordPress standard AJAX actions typically use wp_ajax_ or wp_ajax_nopriv_ hooks
        // These expect wp_send_json_error() format with nested 'data' object
        if (!empty($action)) {
            // Check if this is a known WordPress core action
            $core_actions = array(
                'add-user', 'create-user', 'user-new', 'wp_ajax_add_user',
                'register', 'user_register', 'wp_ajax_register'
            );
            
            if (in_array($action, $core_actions)) {
                return 'wordpress_standard';
            }
            
            // Check for specific plugin patterns
            // WPR (the plugin you mentioned) - check for wpr_ prefix or wpr_vars
            if (strpos($action, 'wpr_') === 0 || isset($_POST['wpr_vars'])) {
                return 'custom_plugin';
            }
            
            // Gravity Forms
            if (strpos($action, 'gf_') === 0 || strpos($action, 'gravityforms') !== false) {
                return 'wordpress_standard';
            }
            
            // WooCommerce
            if (strpos($action, 'woocommerce') !== false || strpos($action, 'wc_') === 0) {
                return 'wordpress_standard';
            }
            
            // Ultimate Member
            if (strpos($action, 'um_') === 0 || strpos($action, 'ultimatemember') !== false) {
                return 'custom_plugin';
            }
            
            // MemberPress
            if (strpos($action, 'mepr_') === 0 || strpos($action, 'memberpress') !== false) {
                return 'wordpress_standard';
            }
        }
        
        // Check for WordPress standard AJAX hook pattern
        if (wp_doing_ajax() && !empty($action)) {
            // If action follows WordPress standard pattern, use standard format
            if (has_action("wp_ajax_{$action}") || has_action("wp_ajax_nopriv_{$action}")) {
                return 'wordpress_standard';
            }
        }
        
        // Default to universal format (works with both)
        return 'universal';
    }
    
    /**
     * Send AJAX error response with format detection
     * 
     * @param string $error_message Error message
     */
    private function send_ajax_error_response($error_message) {
        status_header(200);
        header('Content-Type: application/json; charset=UTF-8');
        nocache_headers();
        
        $format = $this->detect_response_format();
        
        // Build response based on detected format
        switch ($format) {
            case 'wordpress_standard':
                // WordPress standard format - nested in 'data' object
                $response = array(
                    'success' => false,
                    'data' => array(
                        'message' => $error_message,
                        'status' => 'error',
                        'code' => 'email_validation_failed'
                    )
                );
                break;
                
            case 'custom_plugin':
                // Custom plugin format - top-level message and status
                $response = array(
                    'success' => false,
                    'message' => $error_message,
                    'status' => 'error',
                    'code' => 'email_validation_failed'
                );
                break;
                
            case 'universal':
            default:
                // Universal format - includes both formats for maximum compatibility
                $response = array(
                    'success' => false,
                    'message' => $error_message,
                    'status' => 'error',
                    'code' => 'email_validation_failed',
                    'data' => array(
                        'message' => $error_message,
                        'status' => 'error',
                        'code' => 'email_validation_failed'
                    )
                );
                break;
        }
        
        echo wp_json_encode($response);
        die();
    }
    
    /**
     * Format error message based on validation failure
     * 
     * @param array $validation_result Validation result from validate_email_criteria
     * @return string Formatted error message
     */
    private function format_error_message($validation_result) {
        return $validation_result['reason'];
    }
    
    /**
     * Validate email and return validation result
     * 
     * @param string $email Email address
     * @return array|null Array with 'validation_result' and 'validation_data' keys, or null if API call failed
     */
    private function validate_email_and_get_result($email) {
        if (empty($email) || !is_email($email)) {
            return null;
        }
        
        $result = $this->verify_email_api_silent($email);
        if ($result === null) {
            return null;
        }
        
        $validation_data = $this->extract_validation_data_from_result($result);
        if ($validation_data === null) {
            return null;
        }
        
        $validation_result = $this->validate_email_criteria($validation_data);
        
        return array(
            'validation_result' => $validation_result,
            'validation_data' => $validation_data,
            'result' => $result
        );
    }

    /**
     * Store email validation status for a user
     *
     * @param int $user_id
     * @param array $validation_data
     * @return void
     */
    private function update_user_email_validation_status($user_id, $validation_data) {
        if (empty($user_id) || empty($validation_data) || !is_array($validation_data)) {
            return;
        }

        $status = isset($validation_data['status']) ? sanitize_text_field($validation_data['status']) : 'Unknown';
        update_user_meta($user_id, self::EMAIL_VALIDATION_STATUS_META_KEY, $status);
    }

    /**
     * Get stored email validation status for a user
     *
     * @param int $user_id
     * @return string
     */
    private function get_user_email_validation_status($user_id) {
        $status = get_user_meta($user_id, self::EMAIL_VALIDATION_STATUS_META_KEY, true);
        return !empty($status) ? $status : 'Unknown';
    }
    
    /**
     * Validate email before user is inserted (for third-party plugins)
     * 
     * @param array $data User data
     * @param bool $update Whether this is an update
     * @param int|null $id User ID (null for new users)
     * @return array User data
     */
    public function validate_email_before_insert($data, $update, $id) {
        // Only validate for new users (when $update is false and $id is 0 or null)
        if ($update) {
            return $data;
        }
        
        // For new users, $id should be 0 or null, but check both
        if (!empty($id) && $id > 0) {
            return $data;
        }
        
        if (!$this->is_email_validation_enabled()) {
            return $data;
        }
        
        if (empty($data['user_email']) || !is_email($data['user_email'])) {
            return $data;
        }
        
        $validation = $this->validate_email_and_get_result($data['user_email']);
        if ($validation === null) {
            // API call failed, allow registration to proceed
            return $data;
        }
        
        $validation_result = $validation['validation_result'];
        
        if (!$validation_result['valid']) {
            $error_message = $this->format_error_message($validation_result);
            
            // Store error in transient for potential use in user_register hook
            set_transient('nuhello_email_validation_error_' . md5($data['user_email']), array(
                'message' => $error_message,
                'field' => $validation_result['field'] ?? null,
                'value' => $validation_result['value'] ?? null
            ), 60);
            
            if ($this->is_ajax_request()) {
                $this->send_ajax_error_response($error_message);
            } else {
                // For non-AJAX requests, return empty array to cause wp_insert_user to fail
                return array();
            }
        } else {
            // Store validation result for the user_register hook
            set_transient(
                'nuhello_email_validation_pass_' . md5($data['user_email']),
                $validation['validation_data'],
                5 * MINUTE_IN_SECONDS
            );
        }
        
        return $data;
    }
    
    /**
     * Validate email on user_register hook (for third-party plugins)
     * 
     * @param int $user_id
     */
    public function validate_email_on_user_register($user_id) {
        if (!$this->is_email_validation_enabled()) {
            return;
        }
        
        $user = get_userdata($user_id);
        if (!$user || empty($user->user_email)) {
            return;
        }
        
        // Check if there's a stored error from wp_pre_insert_user_data filter
        $error_key = 'nuhello_email_validation_error_' . md5($user->user_email);
        $stored_error = get_transient($error_key);
        
        if ($stored_error) {
            delete_transient($error_key);
            wp_delete_user($user_id);
            
            if ($this->is_ajax_request()) {
                $this->send_ajax_error_response($stored_error['message']);
            } elseif (!is_admin()) {
                wp_die(
                    '<strong>' . __('Registration Error:', 'nuhello') . '</strong> ' . $stored_error['message'],
                    __('Registration Failed', 'nuhello'),
                    array('response' => 400, 'back_link' => true)
                );
            }
            return;
        }

        // If validation already passed in pre-insert, store status and exit
        $pass_key = 'nuhello_email_validation_pass_' . md5($user->user_email);
        $stored_pass = get_transient($pass_key);
        if ($stored_pass) {
            $this->update_user_email_validation_status($user_id, $stored_pass);
            delete_transient($pass_key);
            return;
        }
        
        // Fallback validation - most plugins should be caught by wp_pre_insert_user_data filter
        $validation = $this->validate_email_and_get_result($user->user_email);
        if ($validation === null) {
            return;
        }
        
        $validation_result = $validation['validation_result'];
        
        if (!$validation_result['valid']) {
            wp_delete_user($user_id);
            $error_message = $this->format_error_message($validation_result);
            
            if ($this->is_ajax_request()) {
                $this->send_ajax_error_response($error_message);
            } elseif (!is_admin()) {
                wp_die(
                    '<strong>' . __('Registration Error:', 'nuhello') . '</strong> ' . $error_message,
                    __('Registration Failed', 'nuhello'),
                    array('response' => 400, 'back_link' => true)
                );
            }
        } else {
            $this->update_user_email_validation_status($user_id, $validation['validation_data']);
        }
    }

    /**
     * Add email validation status column to users list
     *
     * @param array $columns
     * @return array
     */
    public function add_email_validation_status_column($columns) {
        if (!$this->is_email_validation_enabled()) {
            return $columns;
        }

        $updated = array();
        foreach ($columns as $key => $label) {
            $updated[$key] = $label;
            if ($key === 'email') {
                $updated['nuhello_email_validation_status'] = __('Status', 'nuhello');
            }
        }

        if (!isset($updated['nuhello_email_validation_status'])) {
            $updated['nuhello_email_validation_status'] = __('Status', 'nuhello');
        }

        return $updated;
    }

    /**
     * Render email validation status column
     *
     * @param string $value
     * @param string $column_name
     * @param int $user_id
     * @return string
     */
    public function render_email_validation_status_column($value, $column_name, $user_id) {
        if ($column_name !== 'nuhello_email_validation_status') {
            return $value;
        }

        if (!$this->is_email_validation_enabled()) {
            return $value;
        }

        $status = $this->get_user_email_validation_status($user_id);
        return esc_html($status);
    }

    /**
     * Make email validation status column sortable
     *
     * @param array $columns
     * @return array
     */
    public function add_email_validation_sortable_columns($columns) {
        if (!$this->is_email_validation_enabled()) {
            return $columns;
        }

        $columns['nuhello_email_validation_status'] = 'nuhello_email_validation_status';
        return $columns;
    }

    /**
     * Handle sorting by email validation status
     *
     * @param WP_User_Query $query
     * @return void
     */
    public function handle_email_validation_sorting($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        if ($query->get('orderby') !== 'nuhello_email_validation_status') {
            return;
        }

        if (!$this->is_email_validation_enabled()) {
            return;
        }

        $query->set('meta_key', self::EMAIL_VALIDATION_STATUS_META_KEY);
        $query->set('orderby', 'meta_value');
    }
    
    /**
     * Validate email in admin user creation/editing
     * 
     * @param WP_Error $errors
     * @param bool $update Whether this is an update
     * @param stdClass $user User object
     */
    public function validate_email_admin_creation($errors, $update, $user) {
        // Only validate for new users (not updates)
        if ($update) {
            return;
        }
        
        if (!$this->is_email_validation_enabled()) {
            return;
        }
        
        if (empty($user->user_email) || !is_email($user->user_email)) {
            return;
        }
        
        // Perform validation and add errors if validation fails
        $this->perform_email_validation($user->user_email, $errors);
    }
    
    /**
     * Validate email in registration errors filter
     * 
     * @param WP_Error $errors
     * @param string $sanitized_user_login
     * @param string $user_email
     * @return WP_Error
     */
    public function validate_email_registration_errors($errors, $sanitized_user_login, $user_email) {
        if (!$this->is_email_validation_enabled()) {
            return $errors;
        }
        
        if (empty($user_email) || !is_email($user_email)) {
            return $errors;
        }
        
        $this->perform_email_validation($user_email, $errors);
        
        return $errors;
    }
    
    /**
     * Perform email validation
     * 
     * @param string $email
     * @param WP_Error $errors
     */
    private function perform_email_validation($email, $errors) {
        $validation = $this->validate_email_and_get_result($email);
        
        if ($validation === null) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Nuhello Email Validation: API call failed for email: ' . $email);
            }
            return;
        }
        
        $validation_result = $validation['validation_result'];
        
        if (!$validation_result['valid']) {
            $error_message = $this->format_error_message($validation_result);
            $errors->add(
                'email_validation_failed',
                '<strong>' . __('Error:', 'nuhello') . '</strong> ' . $error_message,
                array('form-field' => 'email')
            );
        }
    }
    
    /**
     * Verify email API without sending JSON errors
     * 
     * @param string $email
     * @return array|null
     */
    private function verify_email_api_silent($email) {
        if (empty($email)) {
            return null;
        }

        $api_url = rtrim(NUHELLO_FLASK_API_URL, '/') . '/verify_email';

        $token = $this->get_auth_token();

        // Get bot_id from saved website details
        $website_details = $this->get_saved_website_details();
        $bot_id = isset($website_details['chatbot_id']) ? $website_details['chatbot_id'] : '';

        $body_data = array('email' => $email);
        if (!empty($bot_id)) {
            $body_data['bot_id'] = $bot_id;
        }

        $api_args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body' => json_encode($body_data),
            'data_format' => 'body',
            'timeout' => 30,
        );

        // If we have an auth token, attempt to send it
        if (!empty($token)) {
            $api_args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        // Make the request without using _make_api_request (which sends JSON errors)
        $response = wp_remote_request($api_url, $api_args);
        
        if (is_wp_error($response)) {
            return null;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        if ($response_code !== 200 && $response_code !== 201) {
            return null;
        }

        $data = json_decode($response_body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        return $data;
    }
    
    /**
     * Enqueue scripts for users list page
     */
    public function enqueue_users_list_scripts($hook) {
        // Only load on users list page
        if ($hook !== 'users.php') {
            return;
        }
        
        // Only load if email validation is enabled
        if (!$this->is_email_validation_enabled()) {
            return;
        }
        
        wp_enqueue_style(
            'nuhello-users-list-email-validation-css',
            NUHELLO_PLUGIN_URL . 'assets/css/users-list-email-validation.css',
            array(),
            NUHELLO_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'nuhello-users-list-email-validation-js',
            NUHELLO_PLUGIN_URL . 'assets/js/users-list-email-validation.js',
            array('jquery'),
            NUHELLO_PLUGIN_VERSION,
            true
        );
        
        wp_localize_script('nuhello-users-list-email-validation-js', 'nuhello_email_validation', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nuhello_nonce')
        ));
    }
    
    /**
     * Add inline script to inject email validation icons in users list
     */
    public function add_users_list_email_validation_script() {
        if (!$this->is_email_validation_enabled()) {
            return;
        }
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Add validation icon to each email in the users table
            $('.wp-list-table.users .column-email a[href^="mailto:"]').each(function() {
                var $emailLink = $(this);
                var email = $emailLink.attr('href').replace('mailto:', '');
                
                // Create icon element with SVG
                var $icon = $('<span class="nuhello-email-validation-icon" title="Verify Email" style="margin-left: 8px; cursor: pointer; display: inline-flex; align-items: center; vertical-align: middle;"></span>');
                var $svg = $('<svg width="16" height="16" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: #2271b1;"><path d="M44 24V9H24H4V24V39H24" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="36" cy="34" r="5" fill="white" stroke="currentColor" stroke-width="4"/><path d="M40 37L44 40" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 9L24 24L44 9" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>');
                $icon.append($svg);
                $icon.data('email', email);
                
                // Insert icon after email link
                $emailLink.after($icon);
            });
        });
        </script>
        <?php
    }
}

