<?php
/**
 * Main Nuhello Plugin Class
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Nuhello_Plugin {
    
    /**
     * Plugin components
     */
    public $admin_menu;
    public $onboarding;
    public $dashboard;
    public $ajax_handler;
    public $assets;
    public $utils;
    public $email_validation_handler;
    public $updater;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->init_components();
    }
    
    /**
     * Initialize plugin components
     */
    private function init_components() {
        // Initialize components
        $this->admin_menu = new Nuhello_Admin_Menu($this);
        $this->onboarding = new Nuhello_Onboarding();
        $this->dashboard = new Nuhello_Dashboard();
        $this->ajax_handler = new Nuhello_Ajax_Handler();
        $this->assets = new Nuhello_Assets();
        $this->utils = new Nuhello_Utils();
        $this->email_validation_handler = new Nuhello_Email_Validation_Handler();
        $this->updater = new Nuhello_Json_Updater(NUHELLO_PLUGIN_PATH . 'nuhello-plugin.php', NUHELLO_PLUGIN_VERSION);

        add_action('wp_footer', [$this, 'add_nuhello_code']);
    }

    function add_nuhello_code() {
        $website = $this->utils->get_saved_website_details();
        $pixelkey = $website['pixel_key'] ?? '';
        if (!empty($pixelkey)) {
            echo '<script defer src="' . NUHELLO_FRONT_URL . '/scripts/v1/pixel/' . esc_attr($pixelkey) . '"></script>';
        }
    }

} 