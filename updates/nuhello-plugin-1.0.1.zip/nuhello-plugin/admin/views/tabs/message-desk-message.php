<?php
/**
 * Message Desk Conversation Detail
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

$message_desk_email = get_option('nuhello_chatbot_email', '');
$has_message_desk_email = !empty($message_desk_email);
$conversation_id = isset($_GET['conversation_id']) ? sanitize_text_field($_GET['conversation_id']) : '';
?>

<div id="message-desk-message-root" class="dashboard-layout message-desk">
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-email-alt"></i> Message Desk</h2>
            <p class="header-description">Manage all your customer communications in one place</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <div class="message-desk-inbox">
                    <span class="message-desk-inbox-icon dashicons dashicons-email-alt"></span>
                    <span class="message-desk-inbox-text">
                        <strong><?php echo $has_message_desk_email ? esc_html($message_desk_email) : 'Not set'; ?></strong>
                    </span>
                    <button type="button" class="message-desk-copy" data-copy="<?php echo esc_attr($message_desk_email); ?>" title="Copy email address" <?php echo $has_message_desk_email ? '' : 'disabled'; ?>>
                        <span class="dashicons dashicons-admin-page"></span>
                    </button>
                </div>
                <button type="button" class="nuhello-upgrade-btn" id="nuhello-upgrade-open" data-upgrade-modal-open="true">
                    Upgrade Plan
                </button>
            </div>
        </div>
    </div>

    <div class="content-row">
        <div class="message-desk-card message-desk-detail-card">
            <div class="message-desk-detail-toolbar">
                <a class="message-desk-back-link" href="<?php echo esc_url(admin_url('admin.php?page=nuhello-dashboard&tab=message-desk&panel=messages')); ?>">
                    <span class="dashicons dashicons-arrow-left-alt2"></span>
                    Back to messages
                </a>
            </div>

            <div id="message-desk-message-detail" data-conversation-id="<?php echo esc_attr($conversation_id); ?>">
                <?php
                    $inline = true;
                    $loader_id = 'message-desk-message-loading';
                    include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
                ?>
                <div id="message-desk-message-content"></div>
            </div>
        </div>
    </div>
</div>
