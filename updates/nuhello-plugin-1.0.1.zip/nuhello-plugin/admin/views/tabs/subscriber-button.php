<?php
/**
 * Subscriber Button Tab View
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

$utils = new Nuhello_Utils();
$website = $utils->get_saved_website_details();
$chatbot_id = $website['chatbot_id'] ?? '';
$auth_token = get_option('nuhello_auth_token', '');
$org_id = $website['organization_id'] ?? '';

// Get current notification settings
$current_settings = get_option('nuhello_notification_settings', array());
?>

<div class="dashboard-layout notifications-layout">
    <!-- Single Header for Both Panels -->
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-email-alt"></i> Subscriber Button Settings</h2>
            <p class="header-description">Customize your subscriber notification widget appearance and behavior</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <button type="button" id="reset-notification-settings" class="nuhello-btn nuhello-btn-sm nuhello-btn-outline">
                    <i class="dashicons dashicons-update"></i> Reset
                </button>
                <button type="button" id="save-notification-settings" class="nuhello-btn nuhello-btn-sm nuhello-btn-primary">
                    <i class="dashicons dashicons-saved"></i> Save Changes
                </button>
                <button type="button" id="refresh-notification-preview" class="nuhello-btn nuhello-btn-sm nuhello-btn-outline">
                    <i class="dashicons dashicons-update"></i> Refresh Preview
                </button>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="content-wrapper" style="position: relative; min-height: 200px;">
        <div id="widget-loading">
            <div class="widget-loader"></div>
        </div>
        <div class="content-row" style="display: none;">
            <!-- Left Side - Notification Settings Form -->
            <div class="dashboard-left">
                <div class="settings-panel">
                    
                    <form id="notification-settings-form">
                        <?php wp_nonce_field('nuhello_notification_nonce', 'nuhello_notification_nonce'); ?>
                        <input type="hidden" id="auth-token" value="<?php echo esc_attr($auth_token); ?>">
                        <input type="hidden" id="org-id" value="<?php echo esc_attr($org_id); ?>">
                        <input type="hidden" id="bot-id" value="<?php echo esc_attr($chatbot_id); ?>">
                        
                        <div class="settings-section">
                            <div class="section-header">
                                <h3><i class="dashicons dashicons-admin-generic"></i> Basic Settings</h3>
                                <p class="section-description">Configure the fundamental notification settings</p>
                            </div>
                            
                            <div class="form-grid">
                                <div class="setting-item">
                                    <label for="notification-title">Notification Title</label>
                                    <div class="field-wrapper">
                                        <input type="text" id="notification-title" name="title" value="<?php echo esc_attr($current_settings['title'] ?? 'Get notified on discount campaigns 🔥'); ?>" placeholder="Enter notification title">
                                        <small class="field-description">Main title displayed in the notification widget</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="notification-description">Description</label>
                                    <div class="field-wrapper">
                                        <textarea id="notification-description" name="description" rows="3" placeholder="Enter notification description"><?php echo esc_textarea($current_settings['description'] ?? 'Once a month, no spam, unsubscribe at any time.'); ?></textarea>
                                        <small class="field-description">Description text shown below the title</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="learn-more-url">Learn More URL</label>
                                    <div class="field-wrapper">
                                        <input type="url" id="learn-more-url" name="learnMoreUrl" value="<?php echo esc_attr($current_settings['learnMoreUrl'] ?? ''); ?>" placeholder="https://example.com/learn-more">
                                        <small class="field-description">Optional URL for "Learn More" link</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-section">
                            <div class="section-header">
                                <h3><i class="dashicons dashicons-admin-appearance"></i> Appearance</h3>
                                <p class="section-description">Customize the visual appearance of your notification widget</p>
                            </div>
                            
                            <div class="form-grid">
                                <div class="setting-item">
                                    <label for="notification-background-color">Background Color</label>
                                    <div class="field-wrapper">
                                        <div class="color-input-wrapper">
                                            <input type="color" id="notification-background-color" name="backgroundColor" value="<?php echo esc_attr($current_settings['backgroundColor'] ?? '#ffffff'); ?>">
                                            <span class="color-value"><?php echo esc_attr($current_settings['backgroundColor'] ?? '#ffffff'); ?></span>
                                        </div>
                                        <small class="field-description">Background color of the notification widget</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="notification-accent-color">Accent Color</label>
                                    <div class="field-wrapper">
                                        <div class="color-input-wrapper">
                                            <input type="color" id="notification-accent-color" name="accentColor" value="<?php echo esc_attr($current_settings['accentColor'] ?? '#3F215B'); ?>">
                                            <span class="color-value"><?php echo esc_attr($current_settings['accentColor'] ?? '#3F215B'); ?></span>
                                        </div>
                                        <small class="field-description">Primary color for buttons and highlights</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="notification-title-color">Title Color</label>
                                    <div class="field-wrapper">
                                        <div class="color-input-wrapper">
                                            <input type="color" id="notification-title-color" name="titleColor" value="<?php echo esc_attr($current_settings['titleColor'] ?? '#000000'); ?>">
                                            <span class="color-value"><?php echo esc_attr($current_settings['titleColor'] ?? '#000000'); ?></span>
                                        </div>
                                        <small class="field-description">Color of the notification title text</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="notification-text-color">Text Color</label>
                                    <div class="field-wrapper">
                                        <div class="color-input-wrapper">
                                            <input type="color" id="notification-text-color" name="textColor" value="<?php echo esc_attr($current_settings['textColor'] ?? '#4B5563'); ?>">
                                            <span class="color-value"><?php echo esc_attr($current_settings['textColor'] ?? '#4B5563'); ?></span>
                                        </div>
                                        <small class="field-description">Color of the description text</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="settings-section">
                            <div class="section-header">
                                <h3><i class="dashicons dashicons-layout"></i> Layout & Position</h3>
                                <p class="section-description">Configure the layout and positioning of the notification widget</p>
                            </div>
                            
                            <div class="form-grid">
                                <div class="setting-item">
                                    <label for="notification-position">Position</label>
                                    <div class="field-wrapper">
                                        <select id="notification-position" name="position">
                                            <option value="top_left" <?php selected($current_settings['position'] ?? 'top_left', 'top_left'); ?>>Top Left</option>
                                            <option value="top_center" <?php selected($current_settings['position'] ?? 'top_left', 'top_center'); ?>>Top Center</option>
                                            <option value="top_right" <?php selected($current_settings['position'] ?? 'top_left', 'top_right'); ?>>Top Right</option>
                                            <option value="middle_left" <?php selected($current_settings['position'] ?? 'top_left', 'middle_left'); ?>>Middle Left</option>
                                            <option value="middle_center" <?php selected($current_settings['position'] ?? 'top_left', 'middle_center'); ?>>Middle Center</option>
                                            <option value="middle_right" <?php selected($current_settings['position'] ?? 'top_left', 'middle_right'); ?>>Middle Right</option>
                                            <option value="bottom_left" <?php selected($current_settings['position'] ?? 'top_left', 'bottom_left'); ?>>Bottom Left</option>
                                            <option value="bottom_center" <?php selected($current_settings['position'] ?? 'top_left', 'bottom_center'); ?>>Bottom Center</option>
                                            <option value="bottom_right" <?php selected($current_settings['position'] ?? 'top_left', 'bottom_right'); ?>>Bottom Right</option>
                                            <option value="banner-top" <?php selected($current_settings['position'] ?? 'top_left', 'banner-top'); ?>>Banner Top</option>
                                            <option value="banner-bottom" <?php selected($current_settings['position'] ?? 'top_left', 'banner-bottom'); ?>>Banner Bottom</option>
                                        </select>
                                        <small class="field-description">Position of the notification widget on the page</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="notification-layout">Layout Style</label>
                                    <div class="field-wrapper">
                                        <select id="notification-layout" name="layout">
                                            <option value="classic" <?php selected($current_settings['layout'] ?? 'classic', 'classic'); ?>>Classic</option>
                                            <option value="block" <?php selected($current_settings['layout'] ?? 'classic', 'block'); ?>>Block</option>
                                            <option value="edgeless" <?php selected($current_settings['layout'] ?? 'classic', 'edgeless'); ?>>Edgeless</option>
                                            <option value="wire" <?php selected($current_settings['layout'] ?? 'classic', 'wire'); ?>>Wire</option>
                                        </select>
                                        <small class="field-description">Visual style of the notification widget</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="settings-section">
                            <div class="section-header">
                                <h3><i class="dashicons dashicons-format-image"></i> Icon & Buttons</h3>
                                <p class="section-description">Configure notification icon and button text</p>
                            </div>
                            
                            <div class="form-grid">
                                <div class="setting-item checkbox-item">
                                    <label for="show-notification-icon">Show Icon</label>
                                    <div class="field-wrapper">
                                        <label class="checkbox-label">
                                            <input type="checkbox" id="show-notification-icon" name="showIcon" <?php checked($current_settings['showIcon'] ?? true, true); ?>>
                                            <span class="checkmark"></span>
                                            Display an icon in the notification
                                        </label>
                                        <small class="field-description">Show an icon next to the notification content</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="notification-icon">Notification Icon URL</label>
                                    <div class="field-wrapper">
                                        <div class="image-input-wrapper">
                                            <input type="url" id="notification-icon" name="notificationIcon" value="<?php echo esc_attr($current_settings['notificationIcon'] ?? ''); ?>" placeholder="Enter icon URL">
                                            <div class="image-preview" id="notification-icon-preview">
                                                <img src="<?php echo esc_attr($current_settings['notificationIcon'] ?? ''); ?>" alt="Notification Icon Preview" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                                <div class="image-placeholder" style="display: none;">
                                                    <i class="dashicons dashicons-format-image"></i>
                                                    <span>No icon</span>
                                                </div>
                                            </div>
                                        </div>
                                        <small class="field-description">Icon image URL for the notification</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="accept-button-text">Accept Button Text</label>
                                    <div class="field-wrapper">
                                        <input type="text" id="accept-button-text" name="acceptButtonText" value="<?php echo esc_attr($current_settings['acceptButtonText'] ?? 'Subscribe'); ?>" placeholder="Enter button text">
                                        <small class="field-description">Text for the subscribe/accept button</small>
                                    </div>
                                </div>
                                
                                <div class="setting-item">
                                    <label for="reject-button-text">Reject Button Text</label>
                                    <div class="field-wrapper">
                                        <input type="text" id="reject-button-text" name="rejectButtonText" value="<?php echo esc_attr($current_settings['rejectButtonText'] ?? 'No, thanks'); ?>" placeholder="Enter button text">
                                        <small class="field-description">Text for the decline/reject button</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>

            <!-- Right Side - Live Preview -->
            <div class="dashboard-right">
                <div class="widget-panel">
                    <div class="widget-container">
                        <div id="notification-preview-container" class="preview-container">
                            <div id="subscriber-widget-preview" class="subscriber-widget-preview">
                                <!-- Subscriber widget will be rendered here -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="nuhello-notification-notifications" class="nuhello-notifications"></div>
