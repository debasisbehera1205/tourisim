<?php
/**
 * Email Verification Tab View
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

$utils = new Nuhello_Utils();
$website = $utils->get_saved_website_details();
$chatbot_id = $website['chatbot_id'] ?? '';
$auth_token = get_option('nuhello_auth_token', '');
$org_id = $website['organization_id'] ?? '';

?>
<div class="wrap">
    <h1 class="wp-heading-inline"><?php esc_html_e('Email Verifier', 'nuhello-plugin'); ?></h1>
    <p class="description"><?php esc_html_e('Verify email deliverability and find professional email addresses for your growth campaigns.', 'nuhello-plugin'); ?></p>

    <div class="nuhello-email-verifier" style="margin-top:18px;">
        <!-- Toggle buttons -->
        <div class="ef-toggle-row" style="display:flex;gap:12px;margin-bottom:16px;">
            <button class="ef-btn" data-ef-toggle-single><?php esc_html_e('Single Email', 'nuhello-plugin'); ?></button>
            <button class="ef-btn" data-ef-toggle-bulk><?php esc_html_e('Bulk Verification', 'nuhello-plugin'); ?></button>
        </div>

        <!-- Single panel -->
        <div data-ef-panel-single>
            <div style="background:#fff;border:1px solid #e6e9ef;padding:18px;border-radius:12px;margin-bottom:12px;">
                <div style="display:flex;flex-direction:column;align-items:center;gap:12px;">
                    <div style="width:64px;height:64px;display:flex;align-items:center;justify-content:center;border-radius:12px;background:#e6f0ff;color:#0b63d6;font-size:28px;">✓</div>
                    <div style="text-align:center;">
                        <h3 style="margin:0;font-size:16px;"><?php esc_html_e('Verify Single Email', 'nuhello-plugin'); ?></h3>
                        <p style="margin:6px 0 0;color:#6b7280;font-size:13px;"><?php esc_html_e('Enter an email address to check its deliverability', 'nuhello-plugin'); ?></p>
                    </div>

                    <div style="width:100%;margin-top:8px;">
                        <input data-ef-single-input type="email" class="ef-input" placeholder="example@domain.com" />
                        <div style="display:flex;justify-content:flex-end;margin-top:10px;">
                            <button class="ef-btn" data-ef-verify-single><?php esc_html_e('Verify Email', 'nuhello-plugin'); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bulk panel -->
        <div data-ef-panel-bulk>
            <div style="background:#fff;border:1px solid #e6e9ef;padding:18px;border-radius:12px;margin-bottom:12px;">
                <div style="display:flex;flex-direction:column;align-items:center;gap:12px;">
                    <div style="width:64px;height:64px;display:flex;align-items:center;justify-content:center;border-radius:12px;background:#ecfdf5;color:#065f46;font-size:28px;">≡</div>
                    <div style="text-align:center;">
                        <h3 style="margin:0;font-size:16px;"><?php esc_html_e('Bulk Email Verification', 'nuhello-plugin'); ?></h3>
                        <p style="margin:6px 0 0;color:#6b7280;font-size:13px;"><?php esc_html_e('Enter multiple email addresses (comma or newline separated, max 100)', 'nuhello-plugin'); ?></p>
                    </div>

                    <div style="width:100%;margin-top:8px;">
                        <textarea data-ef-bulk-input rows="6" class="ef-input" placeholder="email1@example.com, email2@example.com"></textarea>
                        <div style="display:flex;justify-content:flex-end;margin-top:10px;">
                            <button class="ef-btn" data-ef-verify-bulk><?php esc_html_e('Verify All', 'nuhello-plugin'); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Results -->
        <div data-ef-results></div>
    </div>
</div>