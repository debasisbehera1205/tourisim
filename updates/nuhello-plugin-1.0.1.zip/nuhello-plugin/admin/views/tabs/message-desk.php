<?php
/**
 * Message Desk Tab
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

$message_desk_email = get_option('nuhello_chatbot_email', '');
$has_message_desk_email = !empty($message_desk_email);
$detail_view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : '';

if ($detail_view === 'ticket') {
    include NUHELLO_PLUGIN_PATH . 'admin/views/tabs/message-desk-ticket.php';
    return;
}
if ($detail_view === 'message') {
    include NUHELLO_PLUGIN_PATH . 'admin/views/tabs/message-desk-message.php';
    return;
}
if ($detail_view === 'lead') {
    include NUHELLO_PLUGIN_PATH . 'admin/views/tabs/message-desk-lead.php';
    return;
}
?>

<div id="message-desk-root" class="dashboard-layout message-desk">
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-email-alt"></i> Message Desk</h2>
            <p class="header-description">Manage all your customer communications in one place</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <div class="message-desk-inbox">
                    <span class="message-desk-inbox-icon dashicons dashicons-email-alt"></span>
                    <span class="message-desk-inbox-text">
                        <strong><?php echo $has_message_desk_email ? esc_html($message_desk_email) : 'Not set'; ?></strong>
                    </span>
                    <button type="button" class="message-desk-copy" data-copy="<?php echo esc_attr($message_desk_email); ?>" title="Copy email address" <?php echo $has_message_desk_email ? '' : 'disabled'; ?>>
                        <span class="dashicons dashicons-admin-page"></span>
                    </button>
                </div>
                <button type="button" class="nuhello-upgrade-btn" id="nuhello-upgrade-open" data-upgrade-modal-open="true">
                    Upgrade Plan
                </button>
            </div>
        </div>
    </div>

    <div class="content-row">
        <div class="message-desk-card">

        <div class="message-desk-tabs" role="tablist" aria-label="Message Desk Options">
            <button type="button" class="message-desk-tab is-active" data-tab="tickets">Tickets</button>
            <button type="button" class="message-desk-tab" data-tab="messages">Messages</button>
            <button type="button" class="message-desk-tab" data-tab="leads">Leads</button>
        </div>

        <div class="message-desk-toolbar">
            <div class="message-desk-toolbar-left">
                <div class="message-desk-search">
                    <span class="dashicons dashicons-search"></span>
                    <input type="text" id="message-desk-search" placeholder="Search..." />
                    <button type="button" class="message-desk-search-clear" id="message-desk-search-clear" title="Clear search" aria-label="Clear search" hidden>
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
            </div>

            <div class="message-desk-toolbar-right">
                <div class="message-desk-actions">
                    <button type="button" title="Refresh" data-action="refresh">
                        <span class="dashicons dashicons-update"></span>
                    </button>
                </div>
                <span id="message-desk-filter-count" class="message-desk-filter-count" hidden></span>
                <span id="message-desk-range">0-0 of 0</span>
                <button type="button" class="message-desk-page-btn" id="message-desk-prev" title="Newer">
                    <span class="dashicons dashicons-arrow-left-alt2"></span>
                </button>
                <button type="button" class="message-desk-page-btn" id="message-desk-next" title="Older">
                    <span class="dashicons dashicons-arrow-right-alt2"></span>
                </button>
            </div>
        </div>

        <div class="message-desk-content">
            <div class="message-desk-panel is-active" data-panel="tickets">
                <div class="message-desk-list-wrapper">
                    <?php
                        $inline = true;
                        $loader_id = 'message-desk-loading';
                        include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
                    ?>
                    <div class="message-desk-search-message" id="message-desk-search-message" hidden></div>
                    <div class="nuhello-empty-state" id="message-desk-search-empty" hidden>
                        <img src="<?php echo NUHELLO_PLUGIN_URL . 'assets/images/nuhello-confused.svg'; ?>" alt="No results" class="nuhello-empty-state__image" />
                        <h4 id="message-desk-search-empty-title">No tickets found</h4>
                        <p id="message-desk-search-empty-desc">Try a different search term.</p>
                    </div>
                    <div class="nuhello-empty-state" id="message-desk-empty" hidden>
                        <img src="<?php echo NUHELLO_PLUGIN_URL . 'assets/images/image.png'; ?>" alt="Empty state" class="nuhello-empty-state__image" />
                        <h4 id="message-desk-empty-title">No tickets or emails yet</h4>
                        <p id="message-desk-empty-desc">Tickets and inbound emails will appear here for triage and follow-up.</p>
                        <p id="message-desk-empty-hint" class="nuhello-empty-state__hint"></p>
                    </div>
                    <div class="message-desk-list" id="message-desk-list"></div>
                </div>
            </div>

            <div class="message-desk-panel" data-panel="messages">
                <div class="message-desk-list-wrapper">
                    <?php
                        $inline = true;
                        $loader_id = 'message-desk-messages-loading';
                        include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
                    ?>
                    <div class="message-desk-search-message" id="message-desk-messages-search-message" hidden></div>
                    <div class="nuhello-empty-state" id="message-desk-messages-search-empty" hidden>
                        <img src="<?php echo NUHELLO_PLUGIN_URL . 'assets/images/nuhello-confused.svg'; ?>" alt="No results" class="nuhello-empty-state__image" />
                        <h4 id="message-desk-messages-search-empty-title">No messages found</h4>
                        <p id="message-desk-messages-search-empty-desc">Try a different search term.</p>
                    </div>
                    <div class="nuhello-empty-state" id="message-desk-messages-empty" hidden>
                        <img src="<?php echo NUHELLO_PLUGIN_URL . 'assets/images/image.png'; ?>" alt="Empty state" class="nuhello-empty-state__image" />
                        <h4 id="message-desk-messages-empty-title">No messages yet</h4>
                        <p id="message-desk-messages-empty-desc">Chat conversations will appear here.</p>
                        <p id="message-desk-messages-empty-hint" class="nuhello-empty-state__hint"></p>
                    </div>
                    <div class="message-desk-list" id="message-desk-messages-list"></div>
                </div>
            </div>

            <div class="message-desk-panel" data-panel="leads">
                <div class="message-desk-list-wrapper">
                    <?php
                        $inline = true;
                        $loader_id = 'message-desk-leads-loading';
                        include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
                    ?>
                    <div class="message-desk-search-message" id="message-desk-leads-search-message" hidden></div>
                    <div class="nuhello-empty-state" id="message-desk-leads-search-empty" hidden>
                        <img src="<?php echo NUHELLO_PLUGIN_URL . 'assets/images/nuhello-confused.svg'; ?>" alt="No results" class="nuhello-empty-state__image" />
                        <h4 id="message-desk-leads-search-empty-title">No leads found</h4>
                        <p id="message-desk-leads-search-empty-desc">Try a different search term.</p>
                    </div>
                    <div class="nuhello-empty-state" id="message-desk-leads-empty" hidden>
                        <img src="<?php echo NUHELLO_PLUGIN_URL . 'assets/images/image.png'; ?>" alt="Empty state" class="nuhello-empty-state__image" />
                        <h4 id="message-desk-leads-empty-title">No leads yet</h4>
                        <p id="message-desk-leads-empty-desc">Leads will appear here.</p>
                        <p id="message-desk-leads-empty-hint" class="nuhello-empty-state__hint"></p>
                    </div>
                    <div class="message-desk-list" id="message-desk-leads-list"></div>
                </div>
            </div>
        </div>
        </div>
    </div>

</div>
