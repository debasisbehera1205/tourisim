<?php
/**
 * Template for a single item in the Social Media Links section.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="detail-section-item">
    <div class="detail-item-header">
        <div class="detail-item-main-content">
            <div class="detail-item-title-group">
                <span class="dashicons status-pass"></span>
                <span class="status-badge status-pass">Pass</span>
                <span class="priority-badge priority-low">Low Priority</span>
                <h4 class="detail-item-title"></h4>
            </div>
            <p class="detail-item-description"></p>
        </div>
    </div>
    <div class="detail-current-value">
        <span class="detail-current-label">Current:</span>
        <a href="#" target="_blank" rel="noopener noreferrer" class="detail-link-value"></a>
    </div>
</div>
