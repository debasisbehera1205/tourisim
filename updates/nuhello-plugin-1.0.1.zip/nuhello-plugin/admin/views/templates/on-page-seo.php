<?php
/**
 * Template for the On-page SEO section in the detailed audit view.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="detail-section-header">
    <h3 class="detail-section-title">On-page SEO</h3>
    <p class="detail-section-subtitle">
        Your website's on-page SEO is <span></span> items properly configured.
    </p>
</div>
<div class="detail-section-list"></div>
