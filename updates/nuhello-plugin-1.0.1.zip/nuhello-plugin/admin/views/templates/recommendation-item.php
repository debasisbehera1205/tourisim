<?php
/**
 * Template for a single recommendation item on the main dashboard.
 *
 * @package    nuhello-plugin
 * @subpackage nuhello-plugin/admin/views/templates
 */
?>
<div class="recommendation-item">
    <div class="recommendation-icon">
        <span class="dashicons dashicons-lightbulb"></span>
    </div>
    <div class="recommendation-content">
        <div class="recommendation-title-header">
            <h4 class="recommendation-title"></h4>
            <span class="badge recommendation-priority-badge"></span>
        </div>
        <p class="recommendation-description"></p>
        <div class="recommendation-solution">
            <div class="solution-header" style="display: flex; align-items: center; gap: 10px;">
                <div class="solution-title">Solution:</div>
                <a class="recommendation-solution-link" href="#" target="_blank" rel="noopener noreferrer" style="display: none; margin-bottom: 0.5rem;">Open Settings</a>
            </div>
            <div class="solution-text"></div>
        </div>
    </div>
</div>
