<?php
/**
 * Dashboard View
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

$dashboard = new Nuhello_Dashboard();
$current_tab = $dashboard->get_current_tab();
$current_subtab = $dashboard->get_current_subtab();
$tabs = $dashboard->get_tabs();
if (!isset($tabs[$current_tab])) {
    $current_tab = array_key_first($tabs);
}

$utils = new Nuhello_Utils();
$website = $utils->get_saved_website_details();

// Get settings data
$testing_url = get_option('nuhello_testing_url', '');
$production_url = get_option('nuhello_production_url', '');
$testing_default = get_option('nuhello_testing_default', false);
$production_default = get_option('nuhello_production_default', false);

$display_chatbot = $website['is_bot_enabled'] ?? true;
$show_all_pages = $website['bot_show_on_all_pages'] ?? true;
$enable_analytics = $website['is_analytics_enabled'] ?? true;
$enable_notifications = $website['is_push_notification_enabled'] ?? true;
$saved_chatbot_id = $website['chatbot_id'] ?? '';

//This is reuired in dashboard
$chatbot_org_id = $website['organization_id'] ?? '';
$auth_token = get_option('nuhello_auth_token', '');

$tickets_continue_url = rtrim(NUHELLO_FRONT_URL, '/') . '/' . $chatbot_org_id . '/chatbots/' . $saved_chatbot_id . '/core/tickets';
$tickets_link = ($auth_token && $chatbot_org_id && $saved_chatbot_id)
    ? rtrim(NUHELLO_FRONT_URL, '/') . '/remote-login?token=' . rawurlencode($auth_token) . '&continue=' . rawurlencode($tickets_continue_url)
    : '#';
?>

<div class="wrap nuhello-dashboard">
    <button class="mobile-menu-toggle" id="mobile-menu-toggle">
        <i class="dashicons dashicons-menu"></i>
    </button>
    <div class="nuhello-layout">
        <!-- Sidebar Navigation -->
        <div class="nuhello-sidebar">
            <div class="sidebar-header">
                <div class="logo-container">
                    <img src="<?php echo NUHELLO_PLUGIN_URL; ?>assets/images/favicon-logo.png" alt="Nuhello" class="sidebar-logo" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="logo-placeholder" style="display: none;">
                        <i class="dashicons dashicons-format-chat"></i>
                        <span>Nuhello</span>
                    </div>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <?php foreach ($tabs as $tab_id => $tab): ?>
                    <?php if (isset($tab['has_subtabs']) && $tab['has_subtabs']): ?>
                        <!-- Dropdown Navigation Item -->
                        <div class="nav-dropdown <?php echo $current_tab === $tab_id ? 'active' : ''; ?>">
                            <div class="nav-item nav-dropdown-toggle <?php echo ($current_tab === $tab_id) ? 'active' : ''; ?> <?php echo !$tab['enabled'] ? 'disabled' : ''; ?>"
                                 <?php echo !$tab['enabled'] ? 'onclick="return false;"' : ''; ?>>
                                <i class="dashicons <?php echo esc_attr($tab['icon']); ?>"></i>
                                <span class="nav-text"><?php echo esc_html($tab['title']); ?></span>
                                <i class="dashicons dashicons-arrow-down-alt2 dropdown-arrow"></i>
                            </div>
                            <div class="nav-dropdown-menu">
                                <?php foreach ($tab['subtabs'] as $subtab_id => $subtab): ?>
                                    <?php
                                        $cs = $current_subtab;
                                        if ($current_subtab == 'customize-campaign' && $subtab_id == 'campaigns') {
                                            $cs = 'campaigns';
                                        }
                                    ?>
                                    <a href="?page=nuhello-dashboard&tab=<?php echo esc_attr($tab_id); ?>&subtab=<?php echo esc_attr($subtab_id); ?>" 
                                       class="nav-subitem <?php echo ($current_tab === $tab_id && $cs === $subtab_id) ? 'active' : ''; ?> <?php echo !$subtab['enabled'] ? 'disabled' : ''; ?>"
                                       <?php echo !$subtab['enabled'] ? 'onclick="return false;"' : ''; ?>>
                                        <i class="dashicons <?php echo esc_attr($subtab['icon']); ?>"></i>
                                        <span class="nav-text"><?php echo esc_html($subtab['title']); ?></span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <!-- Regular Navigation Item -->
                        <a href="?page=nuhello-dashboard&tab=<?php echo esc_attr($tab_id); ?>" 
                           class="nav-item <?php echo $current_tab === $tab_id ? 'active' : ''; ?> <?php echo !$tab['enabled'] ? 'disabled' : ''; ?>"
                           <?php echo !$tab['enabled'] ? 'onclick="return false;"' : ''; ?>>
                            <i class="dashicons <?php echo esc_attr($tab['icon']); ?>"></i>
                            <span class="nav-text"><?php echo esc_html($tab['title']); ?></span>
                            <?php if (isset($tab['coming_soon']) && $tab['coming_soon']): ?>
                                <span class="coming-soon-badge">Soon</span>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>
            
        </div>
        
        <!-- Main Content Area -->
        <div class="nuhello-main">
            
            <!-- Tab Content -->
            <div class="main-content">
                <?php
                $tab_id = $current_tab;
                $tab = $tabs[$tab_id];
                ?>
                    <?php if (isset($tab['has_subtabs']) && $tab['has_subtabs']): ?>
                        <!-- Tab with subtabs -->
                    <div class="tab-pane active" id="<?php echo esc_attr($tab_id); ?>-tab">
                            <?php if ($tab['enabled']): ?>
                                <?php if ($current_subtab && isset($tab['subtabs'][$current_subtab])): ?>
                                    <?php 
                                    $subtab_file = NUHELLO_PLUGIN_PATH . 'admin/views/tabs/' . $current_subtab . '.php';
                                    if (file_exists($subtab_file)) {
                                        include $subtab_file;
                                    } else {
                                        echo '<div class="error-message">Sub-tab file not found: ' . esc_html($current_subtab) . '.php</div>';
                                    }
                                    ?>
                                <?php else: ?>
                                    <!-- Default to first subtab if no subtab selected -->
                                    <?php 
                                    $first_subtab = array_key_first($tab['subtabs']);
                                    if ($current_subtab == 'customize-campaign') {
                                        $first_subtab = 'customize-campaign';
                                    }
                                    $subtab_file = NUHELLO_PLUGIN_PATH . 'admin/views/tabs/' . $first_subtab . '.php';
                                    if (file_exists($subtab_file)) {
                                        include $subtab_file;
                                    } else {
                                        echo '<div class="error-message">Default sub-tab file not found: ' . esc_html($first_subtab) . '.php</div>';
                                    }
                                    ?>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="disabled-tab-content">
                                    <div class="disabled-content">
                                        <i class="dashicons <?php echo esc_attr($tab['icon']); ?>"></i>
                                        <h2><?php echo esc_html($tab['title']); ?> Features</h2>
                                        <p><?php echo esc_html($tab['title']); ?> features are coming soon.</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <!-- Regular tab -->
                    <div class="tab-pane active" id="<?php echo esc_attr($tab_id); ?>-tab">
                            <?php if ($tab['enabled']): ?>
                                <?php include NUHELLO_PLUGIN_PATH . 'admin/views/tabs/' . $tab_id . '.php'; ?>
                            <?php else: ?>
                                <div class="disabled-tab-content">
                                    <div class="disabled-content">
                                        <i class="dashicons <?php echo esc_attr($tab['icon']); ?>"></i>
                                        <h2><?php echo esc_html($tab['title']); ?> Features</h2>
                                        <p><?php echo esc_html($tab['title']); ?> features are coming soon. This tab will allow you to configure <?php echo strtolower($tab['title']); ?> settings for your chatbot.</p>
                                        <div class="coming-soon-features">
                                            <h3>Planned Features:</h3>
                                            <ul>
                                                <?php if ($tab_id === 'seo'): ?>
                                                    <li>Meta tag optimization</li>
                                                    <li>Schema markup integration</li>
                                                    <li>Search engine visibility settings</li>
                                                    <li>Performance optimization</li>
                                                <?php elseif ($tab_id === 'analytics'): ?>
                                                    <li>Conversation analytics</li>
                                                    <li>User engagement metrics</li>
                                                    <li>Performance reports</li>
                                                    <li>Custom dashboards</li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</div> 

<?php include NUHELLO_PLUGIN_PATH . 'admin/views/templates/upgrade-plan-modal.php'; ?>