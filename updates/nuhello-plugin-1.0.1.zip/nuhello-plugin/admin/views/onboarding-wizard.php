<?php
/**
 * Onboarding Wizard View
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap nuhello-onboarding">
    <div class="nuhello-header">
        <h1>Welcome to nuhello</h1>
        <p>Let's get you set up in just a few steps</p>
    </div>
    
    <div class="nuhello-wizard">
        <!-- Welcome Card (No Steps) -->
        <div class="welcome-card-section" id="welcome-section">
            <div class="welcome-content-card">
                <p>We're excited to help you set up your nuhello account. This quick setup will take just a few minutes and will get your nuhello running in no time.</p>
                <p>After registration, you will be redirected back to this page to complete the setup.</p>
                
                <div id="email-section">
                    <div class="form-group">
                        <label for="email-input">Enter your nuhello registered email</label>
                        <input type="email" id="email-input" name="email" placeholder="you@example.com" value="<?php echo esc_attr($user_email); ?>"/>
                    </div>
                </div>

                <div id="otp-section" style="display: none;">
                    <div class="form-group">
                        <div class="otp-header">
                            <label for="otp-inputs">Verification Code</label>
                            <a href="#" id="edit-email-link">Edit Email</a>
                        </div>
                        <p>We've sent a 6-digit code to <strong id="otp-email-display"></strong>. Please enter it below.</p>
                        <div class="otp-inputs" id="otp-inputs">
                            <input type="text" maxlength="1" pattern="[0-9]" inputmode="numeric" />
                            <input type="text" maxlength="1" pattern="[0-9]" inputmode="numeric" />
                            <input type="text" maxlength="1" pattern="[0-9]" inputmode="numeric" />
                            <input type="text" maxlength="1" pattern="[0-9]" inputmode="numeric" />
                            <input type="text" maxlength="1" pattern="[0-9]" inputmode="numeric" />
                            <input type="text" maxlength="1" pattern="[0-9]" inputmode="numeric" />
                        </div>
                    </div>
                </div>

                <div id="account-creation-section" style="display: none;">
                    <div class="form-group">
                        <div class="account-creation-header">
                            <h3>Check Your Email</h3>
                        </div>
                        <p>We've sent you an email with a registration link to create your account. Please check your inbox at <strong id="account-creation-email-display"></strong>.</p>
                        <div class="countdown-timer">
                            <p>Registration link expires in: <strong id="countdown-display">15:00</strong></p>
                        </div>
                        <div class="step-actions" style="margin-top: 20px;">
                            <button class="nuhello-btn nuhello-btn-secondary" id="cancel-account-creation">
                                <span class="btn-text">Use Another Email</span>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="step-actions" id="get-started-button-container">
                    <button class="nuhello-btn nuhello-btn-primary start-onboarding">
                        <span class="btn-text">Get Started</span>
                        <span class="btn-loader" style="display: none;"></span>
                    </button>
                </div>
            </div>
        </div>

        <!-- 3-Step Onboarding Process -->
        <div class="onboarding-steps" id="onboarding-steps" style="display: none;">
            <div class="wizard-steps">
                <div class="step active" data-step="1">
                    <div class="step-number">1</div>
                    <div class="step-title">Chatbot</div>
                </div>
                <div class="step" data-step="2">
                    <div class="step-number">2</div>
                    <div class="step-title">Environment</div>
                </div>
                <div class="step" data-step="3">
                    <div class="step-number">3</div>
                    <div class="step-title">Settings</div>
                </div>
            </div>
        
            <div class="wizard-content">
                <!-- Step 1: Chatbot -->
                <div class="step-content active" data-step="1">
                    <div class="content-card">
                        <h2>Select Your Chatbot</h2>
                        <p>Please select the chatbot from below. This will help us connect your chatbot to your account.</p>
                        <div class="form-group">
                            <label for="chatbot-selector">Chatbot</label>
                            <select id="chatbot-selector" name="chatbot_id">
                                <option value="">Select your chatbot</option>
                            </select>
                        </div>
                        <div class="step-actions">
                            <div class="step-actions-left">
                                <button class="nuhello-btn nuhello-btn-primary next-step" data-next="2">
                                    <span class="btn-text">Continue</span>
                                    <span class="btn-loader" style="display: none;"></span>
                                </button>
                            </div>
                            <button type="button" class="nuhello-btn nuhello-btn-link change-onboarding-email">Cancel Onboarding</button>
                        </div>
                    </div>
                </div>
                
                <!-- Step 2: Environment -->
                <div class="step-content" data-step="2">
                    <div class="content-card">
                        <h2>Where should your chatbot appear?</h2>
                        <p>Let's set up the website address where your chatbot will be active.</p>
                        <div id="environment-options">
                            <!-- This content will be dynamically populated by JavaScript -->
                        </div>
                        <div class="step-actions">
                            <div class="step-actions-left">
                                <button class="nuhello-btn nuhello-btn-primary next-step" data-next="3">
                                    <span class="btn-text">Continue</span>
                                    <span class="btn-loader" style="display: none;"></span>
                                </button>
                            </div>
                            <div class="step-actions-right">
                                <button type="button" class="nuhello-btn nuhello-btn-link change-onboarding-email">Cancel Onboarding</button>
                                <button class="nuhello-btn nuhello-btn-secondary prev-step" data-prev="1">Previous</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Step 3: Settings -->
                <div class="step-content" data-step="3">
                    <div class="content-card">
                        <h2>Configure Your Settings</h2>
                        <p>Choose which features you'd like to enable for your chatbot.</p>
                        <div class="form-group">
                            <div class="checkbox-group">
                                <label class="simple-checkbox">
                                    <input type="checkbox" name="display_chatbot" checked />
                                    <div class="checkbox-content">
                                        <h3>Display Chatbot</h3>
                                        <p>Show the chatbot widget on your website</p>
                                    </div>
                                </label>
                                <label class="simple-checkbox">
                                    <input type="checkbox" name="show_all_pages" checked />
                                    <div class="checkbox-content">
                                        <h3>Show on All Pages</h3>
                                        <p>Display the chatbot on every page of your website</p>
                                    </div>
                                </label>
                                <label class="simple-checkbox">
                                    <input type="checkbox" name="enable_analytics" checked />
                                    <div class="checkbox-content">
                                        <h3>Enable Analytics</h3>
                                        <p>Track chatbot usage and performance</p>
                                    </div>
                                </label>
                                <label class="simple-checkbox" style="display:none !important;">
                                    <input type="checkbox" name="enable_notifications" checked />
                                    <div class="checkbox-content">
                                        <h3>Enable Notifications</h3>
                                        <p>Receive notifications for new messages and events</p>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <div class="step-actions">
                            <div class="step-actions-left">
                                <button class="nuhello-btn nuhello-btn-primary complete-onboarding">
                                    <span class="btn-text">Complete Setup</span>
                                    <span class="btn-loader" style="display: none;"></span>
                                </button>
                            </div>
                            <div class="step-actions-right">
                                <button type="button" class="nuhello-btn nuhello-btn-link change-onboarding-email">Cancel Onboarding</button>
                                <button class="nuhello-btn nuhello-btn-secondary prev-step" data-prev="2">Previous</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Cancel Onboarding Confirmation Modal -->
<div id="cancel-onboarding-modal" class="nuhello-modal" style="display: none;">
    <div class="nuhello-modal-content">
        <span class="nuhello-modal-close" role="button" tabindex="0" aria-label="Close">&times;</span>
        <h3>Cancel Onboarding?</h3>
        <p>This will clear your onboarding progress and return you to the email step.</p>
        <div class="nuhello-danger-actions">
            <button type="button" class="nuhello-btn nuhello-btn-outline nuhello-btn-sm" id="cancel-onboarding-no">No</button>
            <button type="button" class="nuhello-btn nuhello-btn-primary nuhello-btn-sm" id="cancel-onboarding-yes">Yes</button>
        </div>
    </div>
</div>

<script>
    // Pass registration data to JavaScript
    window.nuhelloRegistrationData = {
        registrationEmail: '<?php echo esc_js($registration_email); ?>',
        registrationKey: '<?php echo esc_js($registration_key); ?>',
        storedRegistrationEmail: '<?php echo esc_js($stored_registration_email); ?>',
        storedRegistrationKey: '<?php echo esc_js($stored_registration_key); ?>',
        remainingTime: <?php echo intval($remaining_time); ?>,
        hasAuthToken: <?php echo $has_auth_token ? 'true' : 'false'; ?>
    };
</script>