<?php
/**
 * Template for the audit details header.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="audit-header-container">
    <!-- Top section: Title and Score circle -->
    <div class="audit-header-top-section">
        <!-- Left part of top section -->
        <div class="audit-header-top-left">
            <div class="audit-header-top-left-content">
                <h3 class="audit-header-title"></h3>
                <div class="audit-header-url-container">
                    <img src="" alt="Site favicon" class="audit-header-favicon">
                    <div class="audit-header-url-wrapper">
                        <p class="audit-header-url"></p>
                    </div>
                </div>
                <p class="audit-header-date"></p>
                <div class="audit-header-health">
                    <div class="audit-header-health-label">Site Health</div>
                    <div class="audit-header-health-status">
                        <!-- Health icon and label will be inserted here -->
                    </div>
                </div>
                <p class="audit-header-description">A comprehensive evaluation of your website's SEO performance, considering technical optimization, content quality, user experience, and search engine visibility. This score reflects your site's overall ability to rank effectively in search results.</p>
            </div>
        </div>
        <!-- Right part of top section (Score Circle) -->
        <div class="audit-header-top-right">
            <div class="audit-header-score-circle-wrapper">
                <div class="audit-header-score-circle">
                    <svg class="audit-header-score-svg" viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="45" stroke="currentColor" stroke-width="4" fill="transparent" class="audit-header-score-circle-bg"></circle>
                        <circle cx="50" cy="50" r="45" stroke="currentColor" stroke-width="4" fill="transparent" stroke-linecap="round" class="audit-header-score-circle-fg"></circle>
                    </svg>
                    <div class="audit-header-score-text-container">
                        <div class="audit-header-score-text"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Progress Bar section -->
    <div class="audit-header-progress-section">
        <div class="audit-header-progress-bar">
            <div class="audit-header-progress-bar-healthy"></div>
            <div class="audit-header-progress-bar-major"></div>
            <div class="audit-header-progress-bar-moderate"></div>
            <div class="audit-header-progress-bar-minor"></div>
        </div>
        <div class="audit-header-progress-legend">
            <span class="audit-header-legend-item audit-header-legend-healthy"></span>
            <span class="audit-header-legend-item audit-header-legend-major"></span>
            <span class="audit-header-legend-item audit-header-legend-moderate"></span>
            <span class="audit-header-legend-item audit-header-legend-minor"></span>
        </div>
    </div>

    <!-- Stats cards section -->
    <div class="audit-header-stats-section">
        <div class="audit-header-stat-card audit-header-stat-card-issues">
            <div class="audit-header-stat-value audit-header-stat-value-issues"></div>
            <div class="audit-header-stat-label">Issues Found</div>
        </div>
        <div class="audit-header-stat-card audit-header-stat-card-recs">
            <div class="audit-header-stat-value audit-header-stat-value-recs"></div>
            <div class="audit-header-stat-label">Recommendations</div>
        </div>
        <div class="audit-header-stat-card audit-header-stat-card-http">
            <div class="audit-header-stat-value audit-header-stat-value-http"></div>
            <div class="audit-header-stat-label">HTTP Requests</div>
        </div>
    </div>
</div>
