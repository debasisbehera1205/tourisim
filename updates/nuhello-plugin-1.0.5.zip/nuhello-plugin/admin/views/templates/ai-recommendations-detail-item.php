<?php
/**
 * Template for a single AI recommendation item in the detailed audit view.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="ai-rec-item">
    <div class="ai-rec-header">
        <div class="ai-rec-title-group">
            <span class="dashicons"></span>
            <span class="ai-rec-priority-badge"></span>
        </div>
        <div class="ai-rec-main-content">
            <h4 class="ai-rec-title"></h4>
            <p class="ai-rec-description"></p>
        </div>
    </div>
    <div class="ai-rec-solution">
        <div class="ai-rec-solution-icon-wrap">
            <span class="dashicons dashicons-lightbulb"></span>
        </div>
        <div class="ai-rec-solution-content">
            <div class="ai-rec-solution-header" style="display: flex; align-items: center; gap: 10px;">
                <h5 class="ai-rec-solution-title" style="margin: 0;">How to implement:</h5>
                <a class="ai-rec-solution-link" href="#" target="_blank" rel="noopener noreferrer" style="display: none;">Open Settings</a>
            </div>
            <div class="ai-rec-solution-steps">
            </div>
        </div>
    </div>
</div>
