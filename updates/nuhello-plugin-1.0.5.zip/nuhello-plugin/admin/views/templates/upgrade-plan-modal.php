<?php
/**
 * Upgrade Plan Modal
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
$auth_token = get_option('nuhello_auth_token', '');
$current_url = add_query_arg($_GET, admin_url('admin.php'));
?>

<div
    id="nuhello-upgrade-modal"
    class="nuhello-upgrade-modal"
    data-front-url="<?php echo esc_url(NUHELLO_FRONT_URL); ?>"
    data-auth-token="<?php echo esc_attr($auth_token); ?>"
    data-return-url="<?php echo esc_url($current_url); ?>"
    hidden
>
    <div class="nuhello-upgrade-modal__backdrop" data-close="true"></div>
    <div class="nuhello-upgrade-modal__content" role="dialog" aria-modal="true" aria-labelledby="nuhello-upgrade-modal-title">
        <div class="nuhello-upgrade-modal__header">
            <h3 id="nuhello-upgrade-modal-title">nuhello - Plans</h3>
            <button type="button" class="nuhello-upgrade-modal__close" data-close="true" title="Close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>

        <div class="nuhello-upgrade-modal__body">
            <?php
                $inline = true;
                $loader_id = 'nuhello-upgrade-loading';
                include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
            ?>

            <div id="nuhello-upgrade-standard" class="nuhello-upgrade-all-sections">
                <div class="nuhello-upgrade-current" id="nuhello-upgrade-current">
                    You are currently on <span id="nuhello-upgrade-current-plan">Free</span> plan<span id="nuhello-upgrade-current-billing" class="nuhello-upgrade-billing-type" hidden></span>.
                </div>

                <p class="nuhello-upgrade-info">
                    You can change your plan at any time. The new plan will be effective immediately and the remaining balance will be adjusted accordingly.
                </p>

                <div class="nuhello-upgrade-section">
                    <p class="nuhello-upgrade-label"><span>Choose a new plan</span> <span class="nuhello-upgrade-all-plans-link"><a href="https://nuhello.com/pricing/" target="_blank">All plans</a></span></p>
                    <div class="nuhello-upgrade-row">
                        <select id="nuhello-upgrade-plan-select" class="nuhello-upgrade-select">
                            <option value="">Select a plan</option>
                        </select>
                        <div class="nuhello-upgrade-toggle">
                            <span id="nuhello-upgrade-monthly-label" class="is-active">Monthly</span>
                            <label class="nuhello-upgrade-toggle-field">
                                <input type="checkbox" id="nuhello-upgrade-yearly" />
                                <span class="nuhello-upgrade-toggle-slider"></span>
                            </label>
                            <span id="nuhello-upgrade-yearly-label">Yearly</span>
                        </div>
                    </div>
                </div>

                <div class="nuhello-upgrade-grid" id="nuhello-upgrade-benefits"></div>

                <div class="nuhello-upgrade-price-row">
                    <span>Price</span>
                    <span id="nuhello-upgrade-price">—</span>
                </div>

                <div class="nuhello-upgrade-error" id="nuhello-upgrade-error" hidden></div>

                <div class="nuhello-upgrade-actions">
                    <button type="button" class="nuhello-upgrade-cancel" data-close="true">Cancel</button>
                    <button type="button" class="nuhello-upgrade-confirm" id="nuhello-upgrade-change-btn" disabled>Change Plan</button>
                </div>
            </div>

            <div id="nuhello-upgrade-highest" hidden>
                <div class="nuhello-upgrade-max-banner">
                    <div class="nuhello-upgrade-max-icon">⭐</div>
                    <h3 class="nuhello-upgrade-max-title">You're on our best plan!</h3>
                    <p class="nuhello-upgrade-max-subtitle">
                        You're currently on the <span id="nuhello-upgrade-max-plan">Free</span> plan<span id="nuhello-upgrade-max-billing" class="nuhello-upgrade-billing-type" hidden></span>.
                    </p>
                </div>

                <div class="nuhello-upgrade-grid" id="nuhello-upgrade-max-benefits"></div>

                <p class="nuhello-upgrade-info">
                    Need more? Contact our sales team for custom enterprise solutions tailored to your business needs.
                </p>

                <div class="nuhello-upgrade-actions">
                    <button type="button" class="nuhello-upgrade-cancel" data-close="true">Close</button>
                    <button type="button" class="nuhello-upgrade-confirm" id="nuhello-upgrade-contact-sales">Contact Sales</button>
                </div>
            </div>
        </div>
    </div>
</div>
