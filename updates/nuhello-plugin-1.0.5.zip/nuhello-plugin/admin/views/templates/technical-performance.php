<?php
/**
 * Template for the Technical & Performance section in the detailed audit view.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="detail-section-header">
    <h3 class="detail-section-title">Technical & Performance Factors</h3>
    <p class="detail-section-subtitle">
        Your website's technical performance is <span></span> items properly configured.
    </p>
</div>
<div class="detail-section-list"></div>
