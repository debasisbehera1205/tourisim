<?php
/**
 * SEO Audit Tab
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="dashboard-layout">
    <!-- Unified Header -->
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-search"></i> Brand Health</h2>
            <p class="header-description">Monitor and analyze your website's brand health, track competitors, and get recommendations.</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <button type="button" id="refresh-seo" class="nuhello-btn nuhello-btn-sm nuhello-btn-outline">
                    <i class="dashicons dashicons-update"></i> Refresh Data
                </button>
                <button type="button" id="run-seo-audit" class="nuhello-btn nuhello-btn-sm nuhello-btn-outline">
                    <i class="dashicons dashicons-update"></i> Run Brand Health Check
                </button>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="content-row">
        <div class="dashboard-left" style="width: 100%; flex: 1;">
            <div id="seo-dashboard-loading" style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 65vh;">
                <div id="seo-dashboard-loading-state" style="display: flex; flex-direction: column; align-items: center; justify-content: center;">
                    <?php
                        $inline = false;
                        $loader_id = '';
                        include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
                    ?>
                    <div class="loading-text">Loading Brand health report</div>
                </div>
                <div class="nuhello-empty-state" id="seo-empty-state" hidden>
                    <img src="<?php echo NUHELLO_PLUGIN_URL . 'assets/images/image.png'; ?>" alt="Brand health empty state" class="nuhello-empty-state__image" />
                    <h4>Brand health report not available yet</h4>
                    <p>Run a brand health audit to see insights about your site's performance, accessibility, and trust signals.</p>
                </div>
            </div>
            <div id="seo-dashboard-content" class="dashboard-content" style="display: none;">
                <!-- SEO Dashboard Layout -->
                <div class="seo-dashboard">
                    <!-- Left Column: Overall Score -->
                    <div class="seo-left-column">
                        <div class="card">
                <!-- Header -->
                <div class="card-header">
                    <div class="card-header-title">
                        <div class="card-header-icon" style="background-color: var(--indigo-100);">
                            <svg style="color: var(--indigo-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                        </div>
                        <span class="card-header-text">Overall Score</span>
                    </div>
                    <span id="overall-score-badge" class="badge"></span>
                </div>
                <!-- Score Display -->
                <div class="score-display">
                    <div class="score-circle">
                        <svg viewBox="0 0 100 100">
                            <circle class="score-circle-bg" cx="50" cy="50" r="45" stroke-width="4" fill="transparent"></circle>
                            <circle id="score-circle-progress" class="score-circle-progress" cx="50" cy="50" r="45" stroke-width="4" fill="transparent" stroke-dasharray="282.7" stroke-dashoffset="282.7"></circle>
                        </svg>
                        <div id="overall-score-text" class="score-circle-text"></div>
                    </div>
                </div>
                <!-- Website Info -->
                <div class="domain-info">
                    <h4 class="domain-info-header">Domain</h4>
                    <div class="domain-info-url">
                        <img id="favicon-img" src="" alt="favicon" width="16" height="16"/>
                        <div class="separator"></div>
                        <span id="domain-url"></span>
                    </div>
                </div>
                <!-- Audit Results -->
                <div class="audit-results">
                    <div class="audit-results-header">
                        <h4 class="audit-results-header-title">Audit Results</h4>
                        <span id="total-tests-info" class="total-tests"></span>
                    </div>
                    <div class="audit-results-grid">
                        <div class="audit-result-box passed">
                            <div id="passed-tests" class="count"></div>
                            <div class="label">Passed</div>
                        </div>
                        <div class="audit-result-box failed">
                            <div id="failed-tests" class="count"></div>
                            <div class="label">Failed</div>
                        </div>
                        <div class="audit-result-box warnings">
                            <div id="warning-tests" class="count"></div>
                            <div class="label">Warnings</div>
                        </div>
                    </div>
                        </div>
                    </div>
                    </div>

                    <!-- Right Column: SEO Metrics -->
                    <div class="seo-metrics-column">
                        <div class="metrics-grid">
                <!-- Performance -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-header-title">
                            <div class="card-header-icon" style="background-color: var(--blue-100);">
                                <svg style="color: var(--blue-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                            </div>
                            <span class="card-header-text">Performance</span>
                        </div>
                        <span id="performance-score" class="badge badge-performance"></span>
                    </div>
                    <div class="metric-list">
                        <div class="metric-item"><span class="label">Load Time</span><span id="load-time" class="value"></span></div>
                        <div class="metric-item"><span class="label">TTFB</span><span id="ttfb" class="value"></span></div>
                        <div class="metric-item"><span class="label">Page Size</span><span id="page-size" class="value"></span></div>
                    </div>
                    <div class="progress-bar"><div id="performance-progress" class="progress-bar-inner progress-bar-performance"></div></div>
                </div>
                <!-- Accessibility -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-header-title">
                            <div class="card-header-icon" style="background-color: var(--green-100);">
                                <svg style="color: var(--green-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                            </div>
                            <span class="card-header-text">Accessibility</span>
                        </div>
                        <span id="accessibility-score" class="badge badge-accessibility"></span>
                    </div>
                    <div class="metric-list">
                        <div class="metric-item"><span class="label">DOM Size</span><span id="dom-size" class="value"></span></div>
                        <div class="metric-item"><span class="label">Word Count</span><span id="word-count" class="value"></span></div>
                        <div class="metric-item"><span class="label">Text/HTML Ratio</span><span id="text-html-ratio" class="value"></span></div>
                    </div>
                    <div class="progress-bar"><div id="accessibility-progress" class="progress-bar-inner progress-bar-accessibility"></div></div>
                </div>
                <!-- Best Practices -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-header-title">
                            <div class="card-header-icon" style="background-color: var(--purple-100);">
                                <svg style="color: var(--purple-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            </div>
                            <span class="card-header-text">Best Practices</span>
                        </div>
                        <span id="best-practices-score" class="badge badge-practices"></span>
                    </div>
                    <div class="metric-list">
                        <div class="metric-item"><span class="label">HTTPS</span><span id="https-status" class="value"></span></div>
                        <div class="metric-item"><span class="label">Meta Description</span><span id="meta-desc-status" class="value"></span></div>
                        <div class="metric-item"><span class="label">Title</span><span id="title-status" class="value"></span></div>
                    </div>
                    <div class="progress-bar"><div id="best-practices-progress" class="progress-bar-inner progress-bar-practices"></div></div>
                </div>
                <!-- Security -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-header-title">
                            <div class="card-header-icon" style="background-color: var(--orange-100);">
                                <svg style="color: var(--orange-600);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                            </div>
                            <span class="card-header-text">Security</span>
                        </div>
                        <span id="security-badge" class="badge badge-security"></span>
                    </div>
                    <div class="metric-list">
                        <div class="metric-item"><span class="label">SSL Certificate</span><span id="ssl-status" class="value"></span></div>
                        <div class="metric-item"><span class="label">HTTP Requests</span><span id="http-requests" class="value"></span></div>
                        <div class="metric-item"><span class="label">Download Speed</span><span id="download-speed" class="value"></span></div>
                    </div>
                            <div class="progress-bar"><div id="security-progress" class="progress-bar-inner progress-bar-security"></div></div>
                        </div>
                        </div>
                    </div>
                </div>

                <div class="audit-details-section">
                    <!-- Tabs -->
                    <div class="seo-tabs-nav">
            <button class="seo-tab-link active" data-tab="audit-insights">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m4 6v-8M3 20l4-4m0 0l4-4m-4 4H3m14 4l4-4m0 0l-4-4m4 4h-4"></path></svg>
                Audit Insights
            </button>
            <button class="seo-tab-link" data-tab="recommendations">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path></svg>
                Recommendations
            </button>
        </div>

                    <!-- Tab Content -->
                    <div id="audit-insights" class="seo-tab-content active">
                        <div class="card" style="max-width: unset">
                            <div id="audits-list-container">
                                <!-- Audit items will be injected here by JS -->
                            </div>
                        </div>
                    </div>

                    <div id="recommendations" class="seo-tab-content">
                        <div class="card" style="max-width: unset">
                            <div class="recommendation-card-header">
                                <div class="recommendation-card-header-grid">
                                    <div>
                                        <h3 class="recommendation-card-title">Recommendations</h3>
                                        <p id="recommendations-desc" class="recommendation-card-desc"></p>
                                    </div>
                                    <span id="recommendations-count-badge" class="badge recommendation-count-badge"></span>
                                </div>
                            </div>
                            <div id="recommendations-list">
                                <!-- Recommendation items will be injected here by JS -->
                            </div>
                            <button id="toggle-recommendations" class="show-more-btn" style="display: none;">Show More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



