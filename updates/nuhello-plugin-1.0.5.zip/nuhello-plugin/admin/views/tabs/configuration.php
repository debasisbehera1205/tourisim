<?php
/**
 * Configuration Tab View
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="dashboard-layout">
    <!-- Unified Header -->
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-admin-settings"></i> Configuration</h2>
            <p class="header-description">Configure your chatbot connection, environment settings, and feature toggles</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <button type="submit" class="nuhello-btn nuhello-btn-sm nuhello-btn-primary" form="configuration-form">
                    <i class="dashicons dashicons-saved"></i> Save Changes
                </button>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="content-row">
        <!-- Settings Panel - Full Width -->
        <div class="dashboard-left" style="width: 100%; flex: 1; position: relative;">
            <div id="configuration-loader-overlay">
                <?php
                    $inline = false;
                    $loader_id = '';
                    include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
                ?>
            </div>
            <div class="settings-panel" id="configuration-settings-panel">
                <form id="configuration-form" method="post" action="">
                    <?php wp_nonce_field('nuhello_configuration_nonce', 'nuhello_config_nonce'); ?>
                    <input type="hidden" name="action" value="save_configuration">
                    
                    <div class="nuhello-card" id="env-connection-card">
                        <div class="nuhello-card-header">
                            <h3><i class="dashicons dashicons-admin-links"></i> Environment & Connection</h3>
                        </div>
                        <div class="nuhello-card-body">
                            <div id="environment-status-container" class="nuhello-status-container">
                                <div class="nuhello-status nuhello-status--neutral">
                                    <span class="nuhello-status-icon" aria-hidden="true"></span>
                                    <span class="nuhello-status-text">Select a workspace to configure environment settings.</span>
                                </div>
                            </div>
                            <div class="nuhello-grid nuhello-grid-2">
                                <div class="setting-item">
                                    <label for="chatbot-selector">Workspace</label>
                                    <div class="field-wrapper">
                                        <select id="chatbot-selector" name="chatbot_id" style="width: 100%; max-width: none;">
                                            <option value="">Select a workspace</option>
                                        </select>
                                        <small class="field-description">Select your Nuhello workspace for tracking and analytics</small>
                                    </div>
                                </div>
                                <div class="setting-item" id="production-url-container">
                                    <label>Production URL</label>
                                    <div class="field-wrapper">
                                        <div class="nuhello-field-muted">Select a workspace to load the production URL.</div>
                                    </div>
                                </div>
                            </div>
                            <div id="environment-toggle-container" class="nuhello-env-toggle"></div>
                        </div>
                    </div>

                    <div class="nuhello-card" id="feature-toggles-card">
                        <div class="nuhello-card-header">
                            <h3><i class="dashicons dashicons-admin-tools"></i> Feature Toggles</h3>
                        </div>
                        <div class="nuhello-card-body">
                            <div class="nuhello-toggle-grid">
                                <div class="nuhello-toggle-card">
                                    <div class="nuhello-toggle-info">
                                        <div class="nuhello-toggle-title">Chatbot Display</div>
                                        <div class="nuhello-toggle-description">Enable or disable the chatbot display.</div>
                                    </div>
                                    <label class="nuhello-switch">
                                        <input type="checkbox" id="display_chatbot" name="display_chatbot" value="1" <?php checked($display_chatbot, true); ?>>
                                        <span class="nuhello-slider" aria-hidden="true"></span>
                                    </label>
                                </div>

                                <div class="nuhello-toggle-card">
                                    <div class="nuhello-toggle-info">
                                        <div class="nuhello-toggle-title">Global Display</div>
                                        <div class="nuhello-toggle-description">Show chatbot on all pages or selective pages only.</div>
                                    </div>
                                    <label class="nuhello-switch">
                                        <input type="checkbox" id="show_all_pages" name="show_all_pages" value="1" <?php checked($show_all_pages, true); ?>>
                                        <span class="nuhello-slider" aria-hidden="true"></span>
                                    </label>
                                </div>

                                <div class="nuhello-toggle-card">
                                    <div class="nuhello-toggle-info">
                                        <div class="nuhello-toggle-title">Analytics</div>
                                        <div class="nuhello-toggle-description">Enable analytics tracking for chatbot interactions.</div>
                                    </div>
                                    <label class="nuhello-switch">
                                        <input type="checkbox" id="enable_analytics" name="enable_analytics" value="1" <?php checked($enable_analytics, true); ?>>
                                        <span class="nuhello-slider" aria-hidden="true"></span>
                                    </label>
                                </div>

                                <div class="nuhello-toggle-card">
                                    <div class="nuhello-toggle-info">
                                        <div class="nuhello-toggle-title">Email Validation</div>
                                        <div class="nuhello-toggle-description">Validate email addresses when users register on your site.</div>
                                    </div>
                                    <label class="nuhello-switch">
                                        <input type="checkbox" id="enable_email_validation" name="enable_email_validation" value="1" <?php checked(get_option('nuhello_enable_email_validation', false), true); ?>>
                                        <span class="nuhello-slider" aria-hidden="true"></span>
                                    </label>
                                </div>

                                <div class="nuhello-toggle-card" style="display:none;">
                                    <div class="nuhello-toggle-info">
                                        <div class="nuhello-toggle-title">Notifications</div>
                                        <div class="nuhello-toggle-description">Send push alerts.</div>
                                    </div>
                                    <label class="nuhello-switch">
                                        <input type="checkbox" id="enable_notifications" name="enable_notifications" value="1" <?php checked($enable_notifications, true); ?>>
                                        <span class="nuhello-slider" aria-hidden="true"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="nuhello-card" id="validation-rules-card" style="display: <?php echo get_option('nuhello_enable_email_validation', false) ? 'block' : 'none'; ?>;">
                        <div class="nuhello-card-header">
                            <h3><i class="dashicons dashicons-shield-alt"></i> Email Validation Rules</h3>
                        </div>
                        <div class="nuhello-card-body" id="email-validation-settings-wrapper">
                            <div class="nuhello-grid nuhello-grid-2">
                                <div class="setting-item">
                                    <label for="email_validation_allowed_statuses">Allowed Status</label>
                                    <div class="field-wrapper">
                                        <select id="email_validation_allowed_statuses" name="email_validation_allowed_statuses[]" multiple>
                                            <?php
                                            $allowed_statuses = get_option('nuhello_email_validation_allowed_statuses', array('Valid'));
                                            $status_options = array('Valid', 'Invalid', 'Catch-all', 'Unknown');
                                            foreach ($status_options as $status):
                                            ?>
                                                <option value="<?php echo esc_attr($status); ?>" <?php selected(in_array($status, $allowed_statuses)); ?>>
                                                    <?php echo esc_html($status); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <small class="field-description">Select which status values should be allowed for registration.</small>
                                    </div>
                                </div>

                                <div class="setting-item">
                                    <label for="email_validation_allowed_safe_to_send">Safe to Send</label>
                                    <div class="field-wrapper">
                                        <select id="email_validation_allowed_safe_to_send" name="email_validation_allowed_safe_to_send[]" multiple>
                                            <?php
                                            $allowed_safe_to_send = get_option('nuhello_email_validation_allowed_safe_to_send', array('yes'));
                                            $safe_to_send_options = array(
                                                'yes' => 'Yes',
                                                'risky' => 'Risky'
                                            );
                                            foreach ($safe_to_send_options as $safe_val => $safe_label):
                                            ?>
                                                <option value="<?php echo esc_attr($safe_val); ?>" <?php selected(in_array($safe_val, $allowed_safe_to_send)); ?>>
                                                    <?php echo esc_html($safe_label); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <small class="field-description">Select which safe-to-send values should be allowed.</small>
                                    </div>
                                </div>
                            </div>

                            <div class="nuhello-grid nuhello-grid-2">
                                <div class="setting-item">
                                    <label for="email_validation_blocked_types">Blocked Account Types</label>
                                    <div class="field-wrapper">
                                        <select id="email_validation_blocked_types" name="email_validation_blocked_types[]" multiple>
                                            <?php
                                            $blocked_types = get_option('nuhello_email_validation_blocked_types', array('Free Account'));
                                            $type_options = array(
                                                '__empty__' => 'Empty/Not Specified',
                                                'Free Account' => 'Free Account'
                                            );
                                            foreach ($type_options as $type_value => $type_label):
                                                $stored_value = $type_value === '__empty__' ? '__empty__' : $type_value;
                                            ?>
                                                <option value="<?php echo esc_attr($type_value); ?>" <?php selected(in_array($stored_value, $blocked_types)); ?>>
                                                    <?php echo esc_html($type_label); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <small class="field-description">Select which type values should be blocked.</small>
                                    </div>
                                </div>

                                <div class="setting-item">
                                    <label for="email_validation_error_message">Custom Error Message</label>
                                    <div class="field-wrapper">
                                        <textarea id="email_validation_error_message" name="email_validation_error_message" rows="3" placeholder="Enter custom error message for email validation failures"><?php echo esc_textarea(get_option('nuhello_email_validation_error_message', '')); ?></textarea>
                                        <small class="field-description">
                                            Supports <code>{status}</code>, <code>{safetosend}</code>, <code>{type}</code> placeholders.
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="nuhello-card nuhello-danger-zone">
                        <div class="nuhello-card-header">
                            <h3><i class="dashicons dashicons-warning"></i> Danger Zone</h3>
                        </div>
                        <div class="nuhello-card-body">
                            <div class="nuhello-danger-content">
                                <div class="nuhello-danger-info">
                                    <h4>Reset Configuration</h4>
                                    <p>This will revert all settings to default and clear local cache.</p>
                                </div>
                                <div class="nuhello-danger-actions">
                                    <button class="nuhello-btn nuhello-btn-outline nuhello-btn-sm" id="restart-onboarding" title="Reset Setup">
                                        <i class="dashicons dashicons-update"></i>
                                        Reset Setup
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Restart Onboarding Confirmation Modal -->
<div id="restart-onboarding-modal" class="nuhello-modal" style="display: none;">
    <div class="nuhello-modal-content">
        <span class="nuhello-modal-close" role="button" tabindex="0" aria-label="Close">&times;</span>
        <h3>Reset setup?</h3>
        <p>This will restart the onboarding process and reset your settings.</p>
        <div class="nuhello-danger-actions">
            <button type="button" class="nuhello-btn nuhello-btn-outline nuhello-btn-sm" id="cancel-restart-onboarding">Cancel</button>
            <button type="button" class="nuhello-btn nuhello-btn-primary nuhello-btn-sm" id="confirm-restart-onboarding">Reset Setup</button>
        </div>
    </div>
</div>

<!-- OTP Re-verification Modal -->
<div id="re-verify-otp-modal" class="nuhello-modal" style="display: none;">
    <div class="nuhello-modal-content">
        <span class="nuhello-modal-close">&times;</span>
        <h3>Re-verify Your Email</h3>
        <p>A new OTP has been sent to your email address. Please enter it below to continue.</p>
        <form id="re-verify-otp-form">
            <div class="form-group">
                <label for="re-verify-otp" style="text-align: left;">Verification Code</label>
                <div class="otp-inputs">
                    <input type="text" maxlength="1" pattern="[0-9]" required>
                    <input type="text" maxlength="1" pattern="[0-9]" required>
                    <input type="text" maxlength="1" pattern="[0-9]" required>
                    <input type="text" maxlength="1" pattern="[0-9]" required>
                    <input type="text" maxlength="1" pattern="[0-9]" required>
                    <input type="text" maxlength="1" pattern="[0-9]" required>
                </div>
            </div>
            <button type="submit" class="nuhello-btn nuhello-btn-primary">Verify OTP</button>
        </form>
    </div>
</div>

<?php if (isset($current_tab) && $current_tab === 'configuration') : ?>
<script>
jQuery(document).ready(function($) {
    // Form submission handling
    $('#configuration-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);

        var formData = {
            'action': form.find('input[name="action"]').val(),
            'nuhello_config_nonce': form.find('input[name="nuhello_config_nonce"]').val(),
            'chatbot_id': form.find('select[name="chatbot_id"]').val(),
            'is_test_env': form.find('input[name="is_test_env"]').is(':checked'),
            'disable_test_tracking': form.find('input[name="disable_test_tracking"]').is(':checked'),
            'production_url': form.find('input[name="production_url"]').val(),
            'display_chatbot': form.find('input[name="display_chatbot"]').is(':checked'),
            'show_all_pages': form.find('input[name="show_all_pages"]').is(':checked'),
            'enable_analytics': form.find('input[name="enable_analytics"]').is(':checked'),
            'enable_notifications': form.find('input[name="enable_notifications"]').is(':checked'),
            'enable_email_validation': form.find('input[name="enable_email_validation"]').is(':checked'),
            'email_validation_allowed_statuses': $('#email_validation_allowed_statuses').val() || [],
            'email_validation_allowed_safe_to_send': $('#email_validation_allowed_safe_to_send').val() || [],
            'email_validation_blocked_types': ($('#email_validation_blocked_types').val() || []).map(function(val) {
                return val === '__empty__' ? '' : val; // Convert back to empty string
            }),
            'email_validation_error_message': form.find('input[name="email_validation_error_message"]').val() || ''
        };

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: formData,
            beforeSend: function() {
                $('button[type="submit"]').prop('disabled', true).html('<i class="dashicons dashicons-update"></i> Saving...');
            },
                success: function(response) {
                if (response.success) {
                    // Show success message
                    $('<div class="notice notice-success is-dismissible"><p>' + response.data.message + '</p></div>')
                        .insertBefore('.settings-panel')
                        .delay(3000)
                        .fadeOut();
                    updateConfigurationPage(response.data);
                    
                    // Update Select2 values if email validation settings are present
                    if (response.data.email_validation_allowed_statuses) {
                        $('#email_validation_allowed_statuses').val(response.data.email_validation_allowed_statuses).trigger('change');
                    }
                    if (response.data.email_validation_allowed_safe_to_send) {
                        $('#email_validation_allowed_safe_to_send').val(response.data.email_validation_allowed_safe_to_send).trigger('change');
                    }
                    if (response.data.email_validation_blocked_types) {
                        // Convert empty strings back to __empty__ for the select
                        var blockedTypes = response.data.email_validation_blocked_types.map(function(val) {
                            return val === '' ? '__empty__' : val;
                        });
                        $('#email_validation_blocked_types').val(blockedTypes).trigger('change');
                    }
                    // Update error message field
                    if (response.data.email_validation_error_message !== undefined) {
                        $('#email_validation_error_message').val(response.data.email_validation_error_message || '');
                    }
                } else {
                    // Show error message
                    $('<div class="notice notice-error is-dismissible"><p>' + response.data.message + '</p></div>')
                        .insertBefore('.settings-panel')
                        .delay(5000)
                        .fadeOut();
                }
            },
            error: function() {
                $('<div class="notice notice-error is-dismissible"><p>An error occurred while saving the configuration.</p></div>')
                    .insertBefore('.settings-panel')
                    .delay(5000)
                    .fadeOut();
            },
            complete: function() {
                $('button[type="submit"]').prop('disabled', false).html('<i class="dashicons dashicons-saved"></i> Save Changes');
            }
        });
    });

    // Re-verify email button click
    $(document).on('click', '#re-verify-email', function() {
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_send_otp_reverify',
                nonce: '<?php echo wp_create_nonce('nuhello_nonce'); ?>'
            },
            beforeSend: function() {
                $('#re-verify-email').prop('disabled', true).text('Sending...');
            },
            success: function(response) {
                if (response.success) {
                    $('#re-verify-otp-modal').show();
                    showAlertMessage('OTP sent successfully. Please check your email.', 'success');
                } else {
                    showAlertMessage(response.data.message, 'error');
                    console.log(response.data.message);
                }
            },
            complete: function() {
                $('#re-verify-email').prop('disabled', false).text('Re-verify Email');
            }
        });
    });

    // Modal close button
    $(document).on('click', '.nuhello-modal-close', function() {
        $('#re-verify-otp-modal').hide();
    });

    // OTP verification form submission
    $(document).on('submit', '#re-verify-otp-form', function(e) {
        e.preventDefault();
        var otp = '';
        $('#re-verify-otp-form .otp-inputs input').each(function() {
            otp += $(this).val();
        });

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_re_verify_otp',
                nonce: '<?php echo wp_create_nonce('nuhello_nonce'); ?>',
                otp: otp
            },
            beforeSend: function() {
                $('#re-verify-otp-form button').prop('disabled', true).text('Verifying...');
            },
            success: function(response) {
                if (response.success) {
                    $('#re-verify-otp-modal').hide();
                    $('#production-url').prop('disabled', false);
                    $('#re-verify-email').hide();
                    $('#edit-production-url').hide();
                    showAlertMessage('OTP verified successfully.', 'success');
                } else {
                    showAlertMessage(response.data.message, 'error');
                    console.log(response.data.message);
                }
            },
            complete: function() {
                $('#re-verify-otp-form button').prop('disabled', false).text('Verify OTP');
            }
        });
    });

    // OTP input handling
    const otpInputsContainer = document.querySelector('#re-verify-otp-form .otp-inputs');
    const otpInputs = otpInputsContainer.querySelectorAll('input');

    otpInputs.forEach((input, index) => {
        input.addEventListener('input', (e) => {
            // If the input has a value, and there's a next input, focus it.
            if (input.value && index < otpInputs.length - 1) {
                otpInputs[index + 1].focus();
            }
        });

        input.addEventListener('keydown', (e) => {
            // If backspace is pressed, and the input is empty, and there's a previous input, focus it.
            if (e.key === 'Backspace' && !input.value && index > 0) {
                otpInputs[index - 1].focus();
            }
        });
    });

    // Handle pasting OTP
    otpInputsContainer.addEventListener('paste', (e) => {
        e.preventDefault();
        const paste = (e.clipboardData || window.clipboardData).getData('text');
        const pasteDigits = paste.replace(/\D/g, ''); // Remove non-digit characters
        
        if (pasteDigits.length === otpInputs.length) {
            otpInputs.forEach((input, index) => {
                input.value = pasteDigits[index] || '';
            });
            otpInputs[otpInputs.length - 1].focus(); // Focus the last input
        }
    });

    function getChatbots(selectedChatbotId) {
        const chatbotSelector = $('#chatbot-selector');
        const settingInput = chatbotSelector.closest('.setting-input');
        settingInput.addClass('loading'); // Add loading class to the parent

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_get_chatbots',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    chatbotSelector.empty(); // Clear existing options

                    if (response.data && response.data.chatbots && Array.isArray(response.data.chatbots) && response.data.chatbots.length > 0) {
                        chatbotSelector.append($('<option>', {
                            value: '',
                            text: 'Select a Workspace'
                        }));
                        response.data.chatbots.forEach(function(item) {
                            const isSelected = item.id === selectedChatbotId;
                            chatbotSelector.append($('<option>', {
                                value: item.id,
                                text: item.name,
                                selected: isSelected
                            }));
                        });
                        if(selectedChatbotId) {
                            getWebsiteDetails(selectedChatbotId);
                        }
                    } else {
                        chatbotSelector.append($('<option>', {
                            value: '',
                            text: 'No Workspaces found'
                        }));
                    }
                } else {
                    console.error('Failed to fetch chatbot data:', response.data.message);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('AJAX error', textStatus, errorThrown);
            },
            complete: function() {
                settingInput.removeClass('loading'); // Remove loading class from the parent
            }
        });
    }
    getChatbots('<?php echo esc_js($saved_chatbot_id); ?>');

    $('#chatbot-selector').on('change', function() {
        const chatbotId = $(this).val();
        if (chatbotId) {
            getWebsiteDetails(chatbotId);
        }
    });

    function urlsMatch(urlStr1, urlStr2) {
        if (!urlStr1 || !urlStr2) return false;
        try {
            const url1 = new URL(urlStr1);
            const url2 = new URL(urlStr2);
            return url1.protocol === url2.protocol && url1.hostname === url2.hostname;
        } catch (e) {
            console.error("Invalid URL for comparison:", e);
            return false;
        }
    }

    function getWebsiteDetails(chatbotId) {
        const settingInput = $('#chatbot-selector').closest('.setting-input');
        settingInput.addClass('loading');

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_get_website_details_by_chatbot',
                chatbot_id: chatbotId,
                nonce: nuhello_ajax.nonce
            },
            beforeSend: function() {
                $('#configuration-loader-overlay').show();
                $('#configuration-settings-panel').hide();
            },
            success: function(response) {
                if (response.success) {
                    const details = response.data;
                    updateConfigurationPage(details);
                    $('#configuration-settings-panel').show();
                } else {
                    console.error('Failed to fetch website details:', response.data.message);
                    $('#configuration-settings-panel').show();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('AJAX error fetching website details', textStatus, errorThrown);
                $('#configuration-settings-panel').show();
            },
            complete: function() {
                $('#configuration-loader-overlay').hide();
                settingInput.removeClass('loading');
            }
        });
    }

    function updateConfigurationPage(details) {
        const fullWebsiteUrl = details.full_website_url || '';
        const testingUrl = details.testing_url || '';
        const wordpressSiteUrl = '<?php echo site_url(); ?>';
        const wordpressSiteHostname = new URL(wordpressSiteUrl).origin;
        const statusContainer = $('#environment-status-container');
        const toggleContainer = $('#environment-toggle-container');
        const productionContainer = $('#production-url-container');

        statusContainer.empty();
        toggleContainer.empty();

        let statusHtml = '';
        let toggleHtml = '';

        if (testingUrl.length > 0 && urlsMatch(testingUrl, wordpressSiteUrl)) {
            statusHtml = `
                <div class="nuhello-status nuhello-status--success">
                    <span class="nuhello-status-icon" aria-hidden="true"></span>
                    <span class="nuhello-status-text">
                        <strong>Tracking Active</strong> - Chatbot is active in your development environment (${testingUrl}).
                    </span>
                </div>
            `;

            toggleHtml = `
                <div class="nuhello-toggle-row">
                    <div class="nuhello-toggle-info">
                        <div class="nuhello-toggle-title">Disable Chatbot (Test Environment)</div>
                        <div class="nuhello-toggle-description">Disable chatbot in your test environment.</div>
                    </div>
                    <label class="nuhello-switch">
                        <input type="checkbox" id="disable_test_tracking" name="disable_test_tracking" value="1">
                        <span class="nuhello-slider" aria-hidden="true"></span>
                    </label>
                    <input type="hidden" name="is_test_env" value="false" />
                </div>
            `;
        } else if (urlsMatch(fullWebsiteUrl, wordpressSiteUrl)) {
            statusHtml = `
                <div class="nuhello-status nuhello-status--success">
                    <span class="nuhello-status-icon" aria-hidden="true"></span>
                    <span class="nuhello-status-text">
                        <strong>Tracking Active</strong> - Nuhello will track visits on ${fullWebsiteUrl}.
                    </span>
                </div>
            `;

            toggleHtml = `<input type="hidden" name="is_test_env" value="false" />`;
        } else {
            statusHtml = `
                <div class="nuhello-status nuhello-status--warning">
                    <span class="nuhello-status-icon" aria-hidden="true"></span>
                    <span class="nuhello-status-text">
                        Your WordPress domain (${wordpressSiteHostname}) does not match the configured Nuhello URL (${fullWebsiteUrl || 'Not set'}).
                    </span>
                </div>
            `;

            toggleHtml = `
                <div class="nuhello-toggle-row">
                    <div class="nuhello-toggle-info">
                        <div class="nuhello-toggle-title">Enable chatbot(Test Environment)</div>
                        <div class="nuhello-toggle-description">Enable chatbot in your test environment.</div>
                    </div>
                    <label class="nuhello-switch">
                        <input type="checkbox" id="is_test_env" name="is_test_env" value="1">
                        <span class="nuhello-slider" aria-hidden="true"></span>
                    </label>
                </div>
            `;
        }

        const productionHtml = `
            <label for="production-url">Production URL</label>
            <div class="field-wrapper">
                <div class="nuhello-inline-field">
                    <input type="text" id="production-url" name="production_url" value="${fullWebsiteUrl}" disabled>
                    <button type="button" id="edit-production-url" class="nuhello-btn nuhello-btn-sm">Edit</button>
                    <button type="button" id="re-verify-email" class="nuhello-btn nuhello-btn-sm" style="display: none;">Verify Email</button>
                </div>
                <small class="field-description">This is the live URL where Nuhello will be active. You can edit this within 10 minutes of email verification.</small>
            </div>
        `;

        statusContainer.html(statusHtml);
        toggleContainer.html(toggleHtml);
        productionContainer.html(productionHtml);

        $(document).off('click', '#edit-production-url').on('click', '#edit-production-url', function() {
            const otpVerifiedTime = <?php echo get_option('nuhello_otp_verified_time', 0); ?>;
            const timeDiff = Math.floor(Date.now() / 1000) - otpVerifiedTime;
            const isTimeWindowActive = timeDiff < 600;

            if (isTimeWindowActive) {
                $('#production-url').prop('disabled', false);
                $(this).hide();
            } else {
                $(this).hide();
                $('#re-verify-email').show();
            }
        });

        $('input[name="display_chatbot"]').prop('checked', details.display_chatbot);
        $('input[name="show_all_pages"]').prop('checked', details.show_on_all_pages);
        $('input[name="enable_analytics"]').prop('checked', details.enable_analytics);
        $('input[name="enable_notifications"]').prop('checked', details.enable_notifications);

        /**
         * Push notification missing-file warning
         * Temporarily disabled as requested. Leaving code below commented for future use.
         */
        /*
        // Handle push notification warning
        if (details.enable_notifications) {
            checkPushNotificationFile(details);
        } else {
            $('#push-notification-warning-container').remove();
        }
        */
    }

    /*
    // Push notification helper functions - currently not in use
    function checkPushNotificationFile(details) {
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_check_wpn_file',
                nonce: nuhello_ajax.nonce,
                website_id: details.website_id,
                pixel_key: details.pixel_key
            },
            success: function(response) {
                $('#push-notification-warning-container').remove(); // Remove previous warning
                if (response.success && response.data.need_download) {
                    const warningHtml = renderMissingFileWarning(response.data.reason);
                    // The warning should be inside a setting-item to align with the grid
                    const container = $('<div class="setting-item checkbox-item"></div>').html(warningHtml);
                    $('.setting-item.checkbox-item:has(#enable_notifications)').after(container);
                    renderDownloadScript(details);
                }
            },
            error: function() {
                console.error('Failed to check nuhello_wpn.js status.');
            }
        });
    }

    function renderMissingFileWarning(reason) {
        return `
            <div class="field-wrapper">
            <div id="push-notification-warning-container" style="padding:16px 18px; background:#fff3f3; border:1px solid #f5c2c7; border-radius:6px; box-sizing: border-box;">
                <div style="color:#dc3545; font-weight:600; font-size:15px; margin-bottom:8px;">
                    <span style="display:inline-block; vertical-align:middle; margin-right:6px; font-size:18px;">&#9888;</span>
                    ${reason}
                </div>
                <div style="margin-top:6px; font-size:14px;">
                    <span style="color:#333;">Download</span>
                    <a href="#" id="download-nuhello-wpn" style="color:#0073aa; font-weight:500; text-decoration:underline;">nuhello_wpn.js</a>
                    <span style="color:#333;">file and place it in your root folder.</span>
                </div>
            </div>
            </div>
        `;
    }

    function renderDownloadScript(details) {
        const website_id = details.website_id || '';
        const pixel_key = details.pixel_key || '';
        const js_content = `let website_id = '${website_id}';\n` +
                         `let website_pixel_key = '${pixel_key}';\n` +
                         `importScripts('<?=NUHELLO_FRONT_URL?>/pixel_service_worker.js');\n`;

        $(document).off('click', '#download-nuhello-wpn').on('click', '#download-nuhello-wpn', function(e) {
            e.preventDefault();
            var blob = new Blob([js_content], { type: "application/javascript" });
            var url = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = url;
            a.download = "nuhello_wpn.js";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }
    */

    /**
     * Initialize Select2 for email validation settings
     */
    function initializeEmailValidationSelect2() {
        // Check if Select2 is available
        if (typeof $.fn.select2 === 'undefined') {
            console.warn('Select2 library is not loaded yet. Retrying in 500ms...');
            setTimeout(initializeEmailValidationSelect2, 500);
            return;
        }
        
        // Destroy existing Select2 instances if any
        if ($('#email_validation_allowed_statuses').hasClass('select2-hidden-accessible')) {
            $('#email_validation_allowed_statuses').select2('destroy');
        }
        if ($('#email_validation_allowed_safe_to_send').hasClass('select2-hidden-accessible')) {
            $('#email_validation_allowed_safe_to_send').select2('destroy');
        }
        if ($('#email_validation_blocked_types').hasClass('select2-hidden-accessible')) {
            $('#email_validation_blocked_types').select2('destroy');
        }
        
        // Initialize Select2 for Allowed Status Values
        $('#email_validation_allowed_statuses').select2({
            placeholder: 'Select status values...',
            allowClear: true,
            width: '100%',
            closeOnSelect: true,
            dropdownCssClass: 'email-validation-select2-dropdown'
        });
        
        // Initialize Select2 for Allowed Safe to Send Values
        $('#email_validation_allowed_safe_to_send').select2({
            placeholder: 'Select safe to send values...',
            allowClear: true,
            width: '100%',
            closeOnSelect: true,
            dropdownCssClass: 'email-validation-select2-dropdown'
        });
        
        // Initialize Select2 for Blocked Type Values
        $('#email_validation_blocked_types').select2({
            placeholder: 'Select type values to block...',
            allowClear: true,
            width: '100%',
            closeOnSelect: true,
            dropdownCssClass: 'email-validation-select2-dropdown'
        });
    }
    
    // Toggle email validation settings field visibility
    $(document).on('change', '#enable_email_validation', function() {
        var isChecked = $(this).is(':checked');
        $('#validation-rules-card').toggle(isChecked);
        
        // Initialize Select2 when wrapper is shown
        if (isChecked) {
            setTimeout(initializeEmailValidationSelect2, 100);
        }
    });
    
    // Set initial visibility on page load and initialize Select2
    $(document).ready(function() {
        var isEnabled = $('#enable_email_validation').is(':checked');
        $('#validation-rules-card').toggle(isEnabled);
        
        // Initialize Select2 if email validation is enabled
        if (isEnabled) {
            // Wait for Select2 library to be loaded (it's loaded via wp_enqueue_script)
            initializeEmailValidationSelect2();
        }
    });

    function showAlertMessage(message, type = 'success') {
        // Define icons and colors
        const successIcon = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11.5" fill="white" stroke="#3F215B"/>
                <path d="M9 12.5L11.5 15L17 9.5" stroke="#3F215B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
        const errorIcon = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11.5" fill="white" stroke="#D32F2F"/>
                <path d="M16 8L8 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M8 8L16 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;

        const icon = type === 'success' ? successIcon : errorIcon;
        const textColor = '#333';

        // Create message element
        const $message = $(`
            <div class="nuhello-alert-message" style="
                position: fixed;
                bottom: 30px;
                right: 20px;
                background: #fff;
                color: ${textColor};
                border-radius: 8px;
                z-index: 9999;
                display: flex;
                align-items: center;
                transform: translateY(120%);
                opacity: 0;
                transition: transform 0.4s ease, opacity 0.4s ease;
                padding: 13px;
                border: 1px solid #ededed;
                box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
                font-size: 13px;;
                gap: 8px;
            ">
                ${icon}
                <span style="font-weight: 500;">${message}</span>
            </div>
        `);

        $('body').append($message);

        // Animate in
        setTimeout(function() {
            $message.css({
                'transform': 'translateY(0)',
                'opacity': '1'
            });
        }, 10); // Small delay to ensure transition is applied

        // Remove message after 3 seconds
        setTimeout(function() {
            $message.css({
                'transform': 'translateY(120%)',
                'opacity': '0'
            });
            setTimeout(function() {
                $message.remove();
            }, 400); // Wait for animation to finish
        }, 8000);
    }
});
</script>
<?php endif; ?>
