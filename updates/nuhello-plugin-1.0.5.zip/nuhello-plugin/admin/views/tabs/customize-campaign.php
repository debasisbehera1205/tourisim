<?php
/**
 * Customize Campaign Tab View
 * 
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="dashboard-layout campaign-config">
    <!-- Header -->
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-edit"></i> Customize Campaign</h2>
            <p class="header-description">Customize your campaign details and settings.</p>
        </div>
        <div class="header-actions">
            <button type="button" id="save-campaign-settings" class="nuhello-btn nuhello-btn-sm nuhello-btn-primary">
                <i class="dashicons dashicons-saved"></i> Save Changes
            </button>
            <button type="button" id="launch-campaign-btn" class="nuhello-btn nuhello-btn-sm nuhello-btn-secondary">
                <i class="dashicons dashicons-upload"></i> Launch Campaign
            </button>
        </div>
    </div>

    <!-- Content Row -->
    <div class="content-wrapper" style="position: relative; min-height: 200px;">
        <div id="campaign-loading">
            <div class="campaign-loader"></div>
        </div>
        <div class="content-row" style="display: none;">
            <!-- Left Side - Settings Form -->
            <div class="dashboard-left">
                <div class="settings-panel">
                    <form id="customize-campaign-form">
                        <?php wp_nonce_field('nuhello_nonce', 'nuhello_nonce'); ?>
                        <input type="hidden" name="name" id="campaign-name">
                        
                        <!-- Basic Settings -->
                        <div class="settings-section">
                            <div class="section-header">
                                <h3><i class="dashicons dashicons-admin-generic"></i> Basic Settings</h3>
                                <p class="section-description">Configure the fundamental campaign settings.</p>
                            </div>
                            <div class="form-grid">
                                <div class="setting-item">
                                    <label for="campaign-title">Notification Title</label>
                                    <div class="field-wrapper">
                                        <input type="text" id="campaign-title" name="title" required>
                                        <small>Recommended length: 30-60 characters</small>
                                    </div>
                                </div>
                                <div class="setting-item">
                                    <label for="campaign-description">Description</label>
                                    <div class="field-wrapper">
                                        <textarea id="campaign-description" name="description" rows="3"></textarea>
                                        <small>Recommended length: 40-80 characters</small>
                                    </div>
                                </div>
                                <div class="setting-item">
                                    <label for="campaign-url">URL</label>
                                    <div class="field-wrapper">
                                        <input type="url" id="campaign-url" name="url">
                                    </div>
                                </div>

                                <div class="setting-item">
                                    <label for="campaign-logo">Logo</label>
                                    <div class="image-input-wrapper">
                                        <input type="url" id="campaign-logo" name="logo" value="" placeholder="Enter logo URL">
                                        <div id="campaign-logo-preview" class="image-preview-container">
                                            <img src="" alt="Logo Preview" style="display: none;">
                                            <div class="image-placeholder">
                                                <i class="dashicons dashicons-format-image"></i>
                                                <span>No icon</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="settings-section">
                            <div class="section-header">
                                <h3><i class="dashicons dashicons-admin-links"></i> Action Buttons</h3>
                                <p class="section-description">Configure primary and secondary action buttons.</p>
                            </div>
                            <div class="form-grid">
                                <!-- Primary Button -->
                                <div class="setting-item">
                                    <label for="button-title-1">Primary Button Title</label>
                                    <div class="field-wrapper">
                                        <input type="text" id="button-title-1" name="button_title_1" placeholder="e.g., View Offer">
                                        <small class="field-description">Text for the main call-to-action button.</small>
                                    </div>
                                </div>
                                <div class="setting-item">
                                    <label for="button-url-1">Primary Button URL</label>
                                    <div class="field-wrapper">
                                        <input type="url" id="button-url-1" name="button_url_1" placeholder="https://example.com/offer">
                                        <small class="field-description">URL for the primary button.</small>
                                    </div>
                                </div>
                                <!-- Secondary Button -->
                                <div class="setting-item">
                                    <label for="button-title-2">Secondary Button Title</label>
                                    <div class="field-wrapper">
                                        <input type="text" id="button-title-2" name="button_title_2" placeholder="e.g., Learn More">
                                        <small class="field-description">Text for the secondary action button.</small>
                                    </div>
                                </div>
                                <div class="setting-item">
                                    <label for="button-url-2">Secondary Button URL</label>
                                    <div class="field-wrapper">
                                        <input type="url" id="button-url-2" name="button_url_2" placeholder="https://example.com/about">
                                        <small class="field-description">URL for the secondary button.</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Segment Selection -->
                        <div class="settings-section">
                            <div class="section-header">
                                <h3><i class="dashicons dashicons-groups"></i> Segment Selection</h3>
                                <p class="section-description">Choose your target audience segment.</p>
                            </div>
                            <div class="form-grid">
                                <div class="setting-item">
                                    <label for="segment-selection">Select Segment</label>
                                    <select id="segment-selection" name="segment"></select>
                                    <small class="field-description">Select the segment to target.</small>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Right Side - Live Preview -->
            <div class="dashboard-right">
                <div class="widget-panel">
                    <div class="widget-container">
                        <div id="campaign-widget-preview" class="preview-container">
                            <!-- Preview will be rendered here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="nuhello-notification-notifications" class="nuhello-notifications"></div>

<!-- Launch Campaign Modal -->
<div id="launch-campaign-modal" class="nuhello-modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="dashicons dashicons-upload"></i> Launch Campaign</h2>
            <button type="button" class="close-modal-btn"><i class="dashicons dashicons-no"></i></button>
        </div>
        <div class="modal-body">
            <p>Configure delivery settings before sending your campaign</p>
            
            <div class="delivery-method-selector">
                <div class="delivery-option active" data-method="now">
                    <div>
                        <i class="dashicons dashicons-yes"></i>
                        <strong>Send Immediately</strong>
                    </div>
                    <span>Launch your campaign right away</span>
                </div>
                <div class="delivery-option" data-method="later">
                    <div>
                        <i class="dashicons dashicons-calendar-alt"></i>
                        <strong>Schedule for Later</strong>
                    </div>
                    <span>Set a specific date and time</span>
                </div>
            </div>

            <div id="schedule-delivery-section" style="display: none;">
                <h4>Scheduled Delivery</h4>
                <p>When should this campaign be sent?</p>
                <div class="schedule-inputs">
                    <div class="schedule-input">
                        <label for="schedule-date">Date</label>
                        <input type="date" id="schedule-date">
                    </div>
                    <div class="schedule-input">
                        <label for="schedule-time">Time</label>
                        <input type="time" id="schedule-time">
                    </div>
                </div>
                <small class="timezone-info">Will be sent at this time in <span id="user-timezone"></span></small>
            </div>

            <div class="advanced-settings-collapsible">
                <div class="collapsible-header">
                    <h3><i class="dashicons dashicons-admin-generic"></i> Advanced Settings</h3>
                    <i class="dashicons dashicons-arrow-down-alt2"></i>
                </div>
                <div class="collapsible-content" style="display: none;">
                    <div class="campaign-setting-item">
                        <div>
                            <label for="modal-is-silent">Silent notification</label>
                            <small>No sound or vibration</small>
                        </div>
                        <div class="field-wrapper">
                            <label class="switch">
                                <input type="checkbox" id="modal-is-silent">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                    <div class="campaign-setting-item">
                        <div>
                            <label for="modal-is-auto-hide">Auto hide notification</label>
                            <small>Hide after being shown</small>
                        </div>
                        <div class="field-wrapper">
                            <label class="switch">
                                <input type="checkbox" id="modal-is-auto-hide">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                    <div class="campaign-setting-item-ttl">
                        <label for="modal-ttl">Time to live</label>
                        <select id="modal-ttl">
                            <option value="3600">1 hour</option>
                            <option value="86400" selected>1 day</option>
                            <option value="604800">1 week</option>
                            <option value="2592000">1 month</option>
                        </select>
                        <small>Maximum wait time before dropping notification</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="nuhello-btn nuhello-btn-secondary close-modal-btn">Cancel</button>
            <button type="button" id="confirm-launch-btn" class="nuhello-btn nuhello-btn-primary">
                <i class="dashicons dashicons-upload"></i> <span>Send Immediately</span>
            </button>
        </div>
    </div>
</div>