jQuery(document).ready(function($) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.state = Seo.state || {
        originalRecommendations: [],
        allAudits: [],
        shouldScrollToTabs: false
    };

    function setRunAuditButtonState(isLoading, $button) {
        const $runAuditButton = $button && $button.length ? $button : $('#seo-tab #run-seo-audit');
        if (!$runAuditButton.length) return;

        if (isLoading) {
            $runAuditButton.prop('disabled', true);
            $runAuditButton.html('<i class="dashicons dashicons-update"></i> Brand Health Checking...');
        } else {
            $runAuditButton.prop('disabled', false);
            $runAuditButton.html('<i class="dashicons dashicons-update"></i> Run Brand Health Check');
        }
    }

    function isSeoPlanLimitError(response) {
        const payload = response && response.data ? response.data : response;
        const message = payload && payload.message ? payload.message : '';
        const errors = Array.isArray(payload?.errorMessages) ? payload.errorMessages.join(' ') : '';
        const combined = `${message} ${errors}`.toLowerCase();
        return payload?.statusCode === 403 || combined.includes('plan limit') || combined.includes('exceed plan limit');
    }

    function openUpgradePlanModal() {
        console.log('Opening upgrade plan modal from seo.js:', arguments, window.NuhelloUpgradeModal, typeof window.NuhelloUpgradeModal.open === 'function');
        if (window.NuhelloUpgradeModal && typeof window.NuhelloUpgradeModal.open === 'function') {
            window.NuhelloUpgradeModal.open.apply(null, arguments);
            return true;
        }
        return false;
    }

    function showNotification(message, type) {
        if (!message) return;
        if (window.Dashboard && typeof window.Dashboard.showNotification === 'function') {
            window.Dashboard.showNotification(message, type);
            return;
        }

        const successIcon = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11.5" fill="white" stroke="#3F215B"/>
                <path d="M9 12.5L11.5 15L17 9.5" stroke="#3F215B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
        const errorIcon = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11.5" fill="white" stroke="#D32F2F"/>
                <path d="M16 8L8 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M8 8L16 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
        const textColor = '#333';
        const $message = $(`
            <div class="nuhello-alert-message" style="
                position: fixed;
                bottom: 30px;
                right: 20px;
                background: #fff;
                color: ${textColor};
                border-radius: 8px;
                z-index: 9999;
                display: flex;
                align-items: center;
                transform: translateY(120%);
                opacity: 0;
                transition: transform 0.4s ease, opacity 0.4s ease;
                padding: 13px;
                border: 1px solid #ededed;
                box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
                font-size: 13px;
                gap: 8px;
            ">
                ${type === 'success' ? successIcon : errorIcon}
                <span style="font-weight: 500;">${message}</span>
            </div>
        `);

        $('body').append($message);

        setTimeout(function() {
            $message.css({
                'transform': 'translateY(0)',
                'opacity': '1'
            });
        }, 10);

        setTimeout(function() {
            $message.css({
                'transform': 'translateY(120%)',
                'opacity': '0'
            });
            setTimeout(function() {
                $message.remove();
            }, 400);
        }, 8000);
    }

    $('.seo-tabs-nav .seo-tab-link').on('click', function() {
        const tabId = $(this).data('tab');

        $('.seo-tabs-nav .seo-tab-link').removeClass('active');
        $(this).addClass('active');

        $('.seo-tab-content').removeClass('active');
        $('#' + tabId).addClass('active');

        if (tabId === 'audit-insights') {
            const recommendationsContainer = $('#recommendations-list');
            if (recommendationsContainer.hasClass('audit-detail-view')) {
                recommendationsContainer.removeClass('audit-detail-view').empty();
                $('.recommendation-card-header, #toggle-recommendations').show();
                Seo.recommendations.updateRecommendations(Seo.state.originalRecommendations);
            }
        }
    });

    $('#audits-list-container').on('click', '.audit-action-buttons button', function() {
        const auditId = $(this).data('auditId');
        const auditItem = Seo.state.allAudits.find(a => (a.id || a.auditDate) === auditId);
        if (auditItem) {
            Seo.recommendations.renderAuditDetails(auditItem);
            $('.seo-tabs-nav .seo-tab-link[data-tab="recommendations"]').click();
        }
    });

    $(document).on('click', '#refresh-seo', function() {
        $('#seo-dashboard-loading').show();
        $('#seo-dashboard-content').hide();
        Seo.audit.fetchSeoAudit();
    });

    $(document).on('click', '#seo-tab #run-seo-audit', function() {
        const $runAuditButton = $(this);
        setRunAuditButtonState(true, $runAuditButton);
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_trigger_manual_seo_audit',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                const apiMessage = response && response.data && response.data.message ? response.data.message : '';
                const apiSuccess = response && response.data && response.data.success !== undefined
                    ? response.data.success
                    : true;

                if (response.success && apiSuccess !== false) {
                    const successMessage = 'Brand health audit check started. It may take some time to appear on the dashboard, and you will receive an email when it is complete.';
                    showNotification(successMessage, 'success');
                    setTimeout(function() {
                        Seo.audit.fetchSeoAudit();
                        setRunAuditButtonState(false, $runAuditButton);
                    }, 1500);
                    return;
                }

                setRunAuditButtonState(false, $runAuditButton);
                if (isSeoPlanLimitError(response)) {
                    openUpgradePlanModal();
                    showNotification('You have reached the maximum number of brand health checks for your current plan. Please upgrade to continue.', 'error');
                    return;
                }
                showNotification(apiMessage || 'Failed to trigger brand health check.', 'error');
                console.error('Manual SEO audit failed:', response);
            },
            error: function(error) {
                setRunAuditButtonState(false, $runAuditButton);
                if (isSeoPlanLimitError(error?.responseJSON || error)) {
                    openUpgradePlanModal(error?.responseJSON?.data?.message || error?.responseJSON?.message || error?.message);
                    return;
                }
                showNotification('Failed to trigger brand health check.', 'error');
                console.error('Manual SEO audit AJAX error:', error);
            }
        });
    });

    Seo.audit.fetchSeoAudit();
});
