(function ($) {
    function setLoading(isLoading) {
        const $loading = $("#message-desk-message-loading");
        if (!$loading.length) return;
        if (isLoading) {
            $loading.removeAttr("hidden");
        } else {
            $loading.attr("hidden", "hidden");
        }
    }

    function escapeHtml(text) {
        return String(text || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function timeAgo(date) {
        const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes} minutes ago`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours} hours ago`;
        const days = Math.floor(hours / 24);
        return `${days} days ago`;
    }

    function formatTimeAgo(value) {
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return "";
        return timeAgo(date);
    }

    function renderConversation(conversation) {
        const subject = conversation?.subject || "No Subject";
        const topic = conversation?.topic || "other";
        const status = conversation?.status || "offline";
        const readStatus = conversation?.read_status || "read";
        const visitorName = conversation?.visitor_info?.name || conversation?.custom_parameters?.name || "Anonymous Visitor";
        const visitorEmail = conversation?.visitor_info?.email || conversation?.custom_parameters?.email || "";
        const location = conversation?.location?.country || conversation?.location?.country_code || "Unknown";
        const history = Array.isArray(conversation?.conversation_history) ? conversation.conversation_history : [];

        const badges = [
            `<span class="message-desk-message-badge">${escapeHtml(topic)}</span>`,
            `<span class="message-desk-message-badge">${escapeHtml(status)}</span>`,
            `<span class="message-desk-message-badge">${escapeHtml(readStatus)}</span>`
        ];

        const thread = history.map((item) => {
            const content = escapeHtml(item?.message || item?.query || item?.response || "").replace(/\n/g, "<br/>");
            const origin = item?.message_origin || item?.type || "visitor";
            const ts = item?.timestamp || item?.created_at || "";
            return `
                <div class="message-desk-message-item">
                    <div class="message-desk-message-item__meta">
                        <span>${escapeHtml(origin)}</span>
                        <span>${formatTimeAgo(ts)}</span>
                    </div>
                    <div class="message-desk-message-item__content">${content || "—"}</div>
                </div>
            `;
        });

        const html = `
            <div class="message-desk-message-header">
                <h3 class="message-desk-message-subject">${escapeHtml(subject)}</h3>
                <div class="message-desk-message-badges">${badges.join("")}</div>
            </div>
            <div class="message-desk-message-body">
                <div class="message-desk-message-meta">
                    <div><strong>Visitor:</strong> ${escapeHtml(visitorName)}${visitorEmail ? ` &lt;${escapeHtml(visitorEmail)}&gt;` : ""}</div>
                    <div><strong>Location:</strong> ${escapeHtml(location)}</div>
                </div>
                <div class="message-desk-message-thread">${thread.join("")}</div>
            </div>
        `;

        $("#message-desk-message-content").html(html);
        setLoading(false);
    }

    function fetchConversation(conversationId) {
        setLoading(true);
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: "GET",
            data: {
                action: "nuhello_get_message_desk_conversation",
                nonce: nuhello_ajax.nonce,
                conversation_id: conversationId
            },
            success: function (response) {
                const payload = response && response.success ? response.data : response;
                renderConversation(payload?.conversation || payload);
            },
            error: function () {
                $("#message-desk-message-content").html("<div class=\"message-desk-empty\">Failed to load conversation.</div>");
                setLoading(false);
            }
        });
    }

    function copyInboxEmail() {
        const $button = $(".message-desk-copy");
        const email = $button.data("copy");
        if (!email || !navigator.clipboard) return;
        navigator.clipboard.writeText(email).then(() => {
            $button.addClass("is-copied");
            setTimeout(() => $button.removeClass("is-copied"), 1500);
        });
    }

    $(document).ready(function () {
        const conversationId = $("#message-desk-message-detail").data("conversation-id");
        if (conversationId) {
            fetchConversation(conversationId);
        }
        $(".message-desk-copy").on("click", copyInboxEmail);
    });
})(jQuery);
