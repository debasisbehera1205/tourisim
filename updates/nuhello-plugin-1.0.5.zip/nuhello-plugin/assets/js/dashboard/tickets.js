(function(window, $) {
    const Dashboard = window.NuhelloDashboard = window.NuhelloDashboard || {};

    function percentChange(currentValue, previousValue) {
        const current = Number(currentValue) || 0;
        const previous = Number(previousValue) || 0;
        if (previous === 0) {
            return current > 0 ? 100 : 0;
        }
        return ((current - previous) / previous) * 100;
    }

    function normalizeCounts(counts, key) {
        if (!counts) return { current: 0, previous: 0, total: 0 };
        const periodValue = counts.periodValue || {};
        const previousPeriodValue = counts.previousPeriodValue || {};
        const totalValue = counts.value || {};

        return {
            current: periodValue[key] ?? 0,
            previous: previousPeriodValue[key] ?? 0,
            total: totalValue[key] ?? (periodValue[key] ?? 0)
        };
    }

    function cumulativeFromBaseline(baseline, dailySeries) {
        const base = Number(baseline) || 0;
        const series = Array.isArray(dailySeries) ? dailySeries : [];
        let run = base;
        return series.map(value => {
            run += Number(value) || 0;
            return run;
        });
    }

    function computeSpamScore(totalCount, spamCount) {
        const total = Number(totalCount) || 0;
        const spam = Number(spamCount) || 0;
        return total > 0 ? Math.round((spam / total) * 10) : 0;
    }

    function updateTicketsMetrics(data) {
        const counts = data.counts || {};
        const series = data.series || {};

        const totalData = normalizeCounts(counts, 'total');
        const openData = normalizeCounts(counts, 'open');
        const resolvedData = normalizeCounts(counts, 'resolved');
        const spamData = normalizeCounts(counts, 'spam');

        $('#total-tickets-value').text(totalData.total);
        Dashboard.updateMetricChange('#total-tickets-change', percentChange(totalData.current, totalData.previous));
        const totalSeries = cumulativeFromBaseline(counts.previousPeriodValue?.total, series.total);
        Dashboard.renderMiniChart('#total-tickets-chart', totalSeries, '#ef4444');

        $('#open-tickets-value').text(openData.total);
        Dashboard.updateMetricChange('#open-tickets-change', percentChange(openData.current, openData.previous));
        const openSeries = cumulativeFromBaseline(counts.previousPeriodValue?.open, series.open || []);
        Dashboard.renderMiniChart('#open-tickets-chart', openSeries, '#f59e0b');

        $('#resolved-tickets-value').text(resolvedData.total);
        Dashboard.updateMetricChange('#resolved-tickets-change', percentChange(resolvedData.current, resolvedData.previous));
        const resolvedSeries = cumulativeFromBaseline(counts.previousPeriodValue?.resolved, series.resolved || []);
        Dashboard.renderMiniChart('#resolved-tickets-chart', resolvedSeries, '#22c55e');

        const spamScoreAll = computeSpamScore(totalData.total, spamData.total);
        $('#spam-score-value').text(spamScoreAll + '/10');

        const periodSpamScore = computeSpamScore(totalData.current, spamData.current);
        const previousSpamScore = computeSpamScore(totalData.previous, spamData.previous);
        Dashboard.updateMetricChange('#spam-score-change', percentChange(periodSpamScore, previousSpamScore));

        const spamSeries = cumulativeFromBaseline(counts.previousPeriodValue?.spam, series.spam || []);
        const spamScoreSeries = totalSeries.map((total, index) => {
            const spam = Number(spamSeries[index]) || 0;
            return total > 0 ? Math.round((spam / total) * 10) : 0;
        });
        Dashboard.renderMiniChart('#spam-score-chart', spamScoreSeries, '#f97316');
    }

    function loadTicketsMetrics() {
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_get_ticket_metrics',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                if (response.success && response.data) {
                    updateTicketsMetrics(response.data);
                } else {
                    console.error('Failed to load ticket metrics:', response);
                }
            },
            error: function(error) {
                console.error('Ticket metrics AJAX error:', error);
            }
        });
    }

    Dashboard.loadTicketsMetrics = function() {
        if ($('#tickets-metrics').length > 0) {
            loadTicketsMetrics();
        }
    };
})(window, jQuery);
