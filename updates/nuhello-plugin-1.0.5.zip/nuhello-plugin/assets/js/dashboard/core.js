(function(window, $) {
    const Dashboard = window.NuhelloDashboard = window.NuhelloDashboard || {};
    let pendingAnalyticsData = null;
    let seoPollInterval = null;
    let seoPollAttempts = 0;

    Dashboard.sampleActivity = [
        {
            icon: 'dashicons-format-chat',
            title: 'New conversation started',
            description: 'User asked about pricing plans',
            time: '2 minutes ago'
        },
        {
            icon: 'dashicons-admin-users',
            title: 'User completed onboarding',
            description: 'New user successfully set up their account',
            time: '5 minutes ago'
        },
        {
            icon: 'dashicons-yes-alt',
            title: 'Query resolved',
            description: 'Customer support ticket #1234 was resolved',
            time: '12 minutes ago'
        },
        {
            icon: 'dashicons-chart-bar',
            title: 'Analytics updated',
            description: 'Daily performance metrics have been updated',
            time: '1 hour ago'
        },
        {
            icon: 'dashicons-admin-settings',
            title: 'Configuration updated',
            description: 'Chatbot settings were modified',
            time: '2 hours ago'
        }
    ];

    Dashboard.hasCardData = function(cardData, cardType) {
        if (!cardData) return false;

        switch (cardType) {
            case 'stat':
                return cardData > 0;
            case 'score':
                return cardData !== null && cardData !== undefined && cardData >= 0;
            case 'metric':
                return cardData !== null && cardData !== undefined && cardData !== '';
            case 'boolean':
                return cardData !== null && cardData !== undefined;
            case 'list':
                if (Array.isArray(cardData)) {
                    return cardData.length > 0 && cardData.some(item => (item.value || item.count || 0) > 0);
                }
                return cardData && cardData.value && cardData.value.length > 0 &&
                    cardData.value.some(item => (item.count || item.value || 0) > 0);
            case 'chart':
                if (Array.isArray(cardData)) {
                    return cardData.length > 0 && cardData.some(item => (item.count || item.value || 0) > 0);
                }
                return cardData && cardData.value && Object.keys(cardData.value).length > 0 &&
                    Object.values(cardData.value).some(val => val > 0);
            case 'map':
                return cardData.value && cardData.value.length > 0 &&
                    cardData.value.some(item => item.count > 0);
            case 'utm':
                return Object.values(cardData).some(utmData =>
                    utmData && utmData.value && utmData.value.length > 0 &&
                    utmData.value.some(item => item.count > 0)
                );
            default:
                return false;
        }
    };

    Dashboard.manageRowVisibility = function(rowSelector, cardDataArray) {
        const $row = $(rowSelector);
        if (!$row.length) return;

        const hasAnyData = cardDataArray.some(cardInfo => Dashboard.hasCardData(cardInfo.data, cardInfo.type));
        if (hasAnyData) {
            $row.show();
        } else {
            $row.hide();
        }
    };

    Dashboard.showLoading = function() {
        $('#dashboard-loading').show();
        $('#dashboard-content').hide();
    };

    Dashboard.hideLoading = function() {
        $('#dashboard-loading').hide();
        $('#dashboard-content').show();

        setTimeout(function() {
            if (typeof Dashboard.initTicketsCards === 'function') {
                Dashboard.initTicketsCards();
            }

            if (pendingAnalyticsData) {
                if (typeof Dashboard.updateAnalyticsStats === 'function') {
                    Dashboard.updateAnalyticsStats(pendingAnalyticsData);
                }
                if (typeof Dashboard.renderAnalyticsData === 'function') {
                    Dashboard.renderAnalyticsData(pendingAnalyticsData);
                }
                pendingAnalyticsData = null;
            }
        }, 100);
    };

    Dashboard.setPendingAnalyticsData = function(data) {
        pendingAnalyticsData = data;
    };

    Dashboard.setSeoAuditState = function(hasAudit) {
        const $seoSection = $('#seo-dashboard-section');
        const $runAuditButton = $('#run-seo-audit');

        if (hasAudit) {
            $seoSection.show();
        } else {
            $seoSection.hide();
        }

        if ($runAuditButton.length) {
            $runAuditButton.show();
        }
    };

    Dashboard.fetchSeoAudit = function(onComplete) {
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_get_seo_audit_by_chatbot',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                let hasAudit = false;
                if (response.success && response.data.payload && response.data.payload.length > 0) {
                    const mostRecentSuccessfulAudit = response.data.payload.find(audit => audit.status === 'SUCCESS');
                    if (mostRecentSuccessfulAudit && typeof Dashboard.updateSeoUI === 'function') {
                        Dashboard.updateSeoUI(mostRecentSuccessfulAudit.auditData);
                        hasAudit = true;
                    }
                }
                Dashboard.setSeoAuditState(hasAudit);
                if (typeof onComplete === 'function') {
                    onComplete(hasAudit);
                }
            },
            error: function(error) {
                console.error('SEO AJAX error:', error);
                Dashboard.setSeoAuditState(false);
                if (typeof onComplete === 'function') {
                    onComplete(false);
                }
            }
        });
    };

    Dashboard.startSeoAuditPolling = function() {
        const maxAttempts = 30;
        const intervalMs = 4000;

        if (seoPollInterval) {
            clearInterval(seoPollInterval);
        }
        seoPollAttempts = 0;

        seoPollInterval = setInterval(function() {
            seoPollAttempts++;
            Dashboard.fetchSeoAudit(function(hasAudit) {
                if (hasAudit || seoPollAttempts >= maxAttempts) {
                    clearInterval(seoPollInterval);
                    seoPollInterval = null;
                    Dashboard.setRunAuditButtonState(false);
                }
            });
        }, intervalMs);
    };

    Dashboard.setRunAuditButtonState = function(isLoading) {
        const $runAuditButton = $('#run-seo-audit');
        if (!$runAuditButton.length) return;

        if (isLoading) {
            $runAuditButton.prop('disabled', true);
            $runAuditButton.html('<i class="dashicons dashicons-update"></i> Brand Health Checking...');
        } else {
            $runAuditButton.prop('disabled', false);
            $runAuditButton.html('<i class="dashicons dashicons-update"></i> Run Brand Health Check');
        }
    };

    Dashboard.isSeoPlanLimitError = function(response) {
        const payload = response && response.data ? response.data : response;
        const message = payload && payload.message ? payload.message : '';
        const errors = Array.isArray(payload?.errorMessages) ? payload.errorMessages.join(' ') : '';
        const combined = `${message} ${errors}`.toLowerCase();
        return payload?.statusCode === 403 || combined.includes('plan limit') || combined.includes('exceed plan limit');
    };

    Dashboard.openUpgradePlanModal = function(message) {
        console.log('Opening upgrade plan modal:', message, window.NuhelloUpgradeModal, typeof window.NuhelloUpgradeModal.open === 'function');
        if (window.NuhelloUpgradeModal && typeof window.NuhelloUpgradeModal.open === 'function') {
            window.NuhelloUpgradeModal.open(message);
            return true;
        }
        return false;
    };

    Dashboard.showNotification = function(message, type) {
        if (!message) return;

        const successIcon = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11.5" fill="white" stroke="#3F215B"/>
                <path d="M9 12.5L11.5 15L17 9.5" stroke="#3F215B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
        const errorIcon = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11.5" fill="white" stroke="#D32F2F"/>
                <path d="M16 8L8 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M8 8L16 16" stroke="#D32F2F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;

        const textColor = '#333';
        const $message = $(`
            <div class="nuhello-alert-message" style="
                position: fixed;
                bottom: 30px;
                right: 20px;
                background: #fff;
                color: ${textColor};
                border-radius: 8px;
                z-index: 9999;
                display: flex;
                align-items: center;
                transform: translateY(120%);
                opacity: 0;
                transition: transform 0.4s ease, opacity 0.4s ease;
                padding: 13px;
                border: 1px solid #ededed;
                box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
                font-size: 13px;
                gap: 8px;
            ">
                ${type === 'success' ? successIcon : errorIcon}
                <span style="font-weight: 500;">${message}</span>
            </div>
        `);

        $('body').append($message);

        setTimeout(function() {
            $message.css({
                'transform': 'translateY(0)',
                'opacity': '1'
            });
        }, 10);

        setTimeout(function() {
            $message.css({
                'transform': 'translateY(120%)',
                'opacity': '0'
            });
            setTimeout(function() {
                $message.remove();
            }, 400);
        }, 8000);
    };

    Dashboard.loadDashboardData = function() {
        let seoLoaded = false;
        let analyticsLoaded = false;

        function checkIfComplete() {
            if (seoLoaded && analyticsLoaded) {
                Dashboard.hideLoading();
            }
        }

        if (typeof Dashboard.loadTicketsMetrics === 'function') {
            Dashboard.loadTicketsMetrics();
        }

        Dashboard.fetchSeoAudit(function() {
            seoLoaded = true;
            checkIfComplete();
        });

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_get_analytics_by_chatbot',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    Dashboard.setPendingAnalyticsData(data);

                    const updateStats = function() {
                        if ($('#dashboard-content').is(':visible') && $('#total-visitors').length > 0) {
                            if (typeof Dashboard.updateAnalyticsStats === 'function') {
                                Dashboard.updateAnalyticsStats(data);
                            }
                            if (typeof Dashboard.renderAnalyticsData === 'function') {
                                Dashboard.renderAnalyticsData(data);
                            }
                            return true;
                        }
                        return false;
                    };

                    if (!updateStats()) {
                        let retries = 0;
                        const maxRetries = 20;
                        const retryInterval = setInterval(function() {
                            retries++;
                            if (updateStats() || retries >= maxRetries) {
                                clearInterval(retryInterval);
                            }
                        }, 100);
                    }
                } else {
                    console.error('Error fetching analytics:', response.data.message);
                    if (typeof Dashboard.updateAnalyticsStats === 'function') {
                        Dashboard.updateAnalyticsStats({
                            dashboard_data: { value: [{ visitors: 0, sessions: 0 }] },
                            total_pageviews: 0,
                            bounce_rate: 0
                        });
                    }
                }
                analyticsLoaded = true;
                checkIfComplete();
            },
            error: function(error) {
                console.error('Analytics AJAX error:', error);
                if (typeof Dashboard.updateAnalyticsStats === 'function') {
                    Dashboard.updateAnalyticsStats({
                        dashboard_data: { value: [{ visitors: 0, sessions: 0 }] },
                        total_pageviews: 0,
                        bounce_rate: 0
                    });
                }
                analyticsLoaded = true;
                checkIfComplete();
            }
        });
    };

    Dashboard.init = function() {

        Dashboard.showLoading();

        setTimeout(() => {
            Dashboard.loadDashboardData();
        }, 2000);

        $(document).on('click', '#refresh-dashboard', function() {
            Dashboard.showLoading();
            setTimeout(() => {
                Dashboard.loadDashboardData();
            }, 1500);
        });

        $(document).on('click', '#run-seo-audit', function() {
            Dashboard.setRunAuditButtonState(true);
            $.ajax({
                url: nuhello_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'nuhello_trigger_manual_seo_audit',
                    nonce: nuhello_ajax.nonce
                },
                success: function(response) {
                    const apiMessage = response && response.data && response.data.message ? response.data.message : '';
                    const apiSuccess = response && response.data && response.data.success !== undefined
                        ? response.data.success
                        : true;

                    if (response.success && apiSuccess !== false) {
                        const successMessage = 'Brand health audit check started. It may take some time to appear on the dashboard, and you will receive an email when it is complete.';
                        Dashboard.showNotification(successMessage, 'success');
                        Dashboard.startSeoAuditPolling();
                        return;
                    }

                    Dashboard.setRunAuditButtonState(false);
                    if (Dashboard.isSeoPlanLimitError(response)) {
                        Dashboard.openUpgradePlanModal();
                        Dashboard.showNotification('You have reached the maximum number of brand health checks for your current plan. Please upgrade to continue.', 'error');
                        return;
                    }
                    Dashboard.showNotification(apiMessage || 'Failed to trigger brand health check.', 'error');
                    console.error('Manual SEO audit failed:', response);
                },
                error: function(error) {
                    Dashboard.setRunAuditButtonState(false);
                    if (Dashboard.isSeoPlanLimitError(error?.responseJSON || error)) {
                        Dashboard.openUpgradePlanModal(error?.responseJSON?.data?.message || error?.responseJSON?.message || error?.message);
                        return;
                    }
                    Dashboard.showNotification('Failed to trigger brand health check.', 'error');
                    console.error('Manual SEO audit AJAX error:', error);
                }
            });
        });
    };
})(window, jQuery);
