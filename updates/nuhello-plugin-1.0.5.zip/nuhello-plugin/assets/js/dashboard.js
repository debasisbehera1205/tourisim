jQuery(document).ready(function() {
    if (window.NuhelloDashboard && typeof window.NuhelloDashboard.init === 'function') {
        window.NuhelloDashboard.init();
    } else {
        console.warn('Nuhello dashboard scripts failed to initialize.');
    }
});
