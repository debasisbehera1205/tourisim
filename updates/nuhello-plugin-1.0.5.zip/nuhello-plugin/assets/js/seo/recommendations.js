(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.recommendations = Seo.recommendations || {};
    Seo.state = Seo.state || {
        originalRecommendations: [],
        allAudits: [],
        shouldScrollToTabs: false
    };

    Seo.recommendations.updateRecommendations = function(recommendations) {
        const container = $('#recommendations-list');
        container.empty();

        const count = recommendations.length;
        $('#recommendations-count-badge').text(`${count} Recommendation${count === 1 ? '' : 's'}`);
        $('#recommendations-desc').text(`We've identified ${count} recommendations to improve your website's SEO.`);

        if (count === 0) {
            container.append('<p>No recommendations found.</p>');
            return;
        }

        const priorityColors = {
            high: 'text-red-600',
            medium: 'text-orange-400',
            low: 'text-blue-600'
        };

        Seo.utils.fetchTemplate('recommendation-item', function(response) {
            if (!response.success) {
                container.append('<p>Error loading recommendations template.</p>');
                return;
            }
            const itemTemplate = response.data;

            recommendations.forEach(rec => {
                const $item = $(itemTemplate).clone();
                const priority = rec.priority.toLowerCase();
                const color = priorityColors[priority] || 'blue';

                $item.find('.dashicons-lightbulb').addClass(color);
                $item.find('.recommendation-title').text(rec.title);
                $item.find('.recommendation-priority-badge').addClass(`badge-p-${priority}`).text(rec.priority);
                $item.find('.recommendation-description').text(rec.description);

                const linkData = Seo.utils.getRecommendationLink(rec.title, rec.description);
                const $link = $item.find('.recommendation-solution-link');
                if (linkData) {
                    $link.attr('href', linkData.url).text(linkData.label).show();
                } else {
                    $link.remove();
                }

                const solutionText = $item.find('.solution-text');
                const solutionSteps = rec.solution.split(/(\d+\.)/).filter(Boolean);
                for (let i = 0; i < solutionSteps.length; i += 2) {
                    if (solutionSteps[i] && solutionSteps[i + 1]) {
                        const stepText = solutionSteps[i] + solutionSteps[i + 1].trim();
                        solutionText.append($('<p>').text(stepText));
                    }
                }

                container.append($item);
            });

            const items = container.children('.recommendation-item');
            const showMoreBtn = $('#toggle-recommendations');
            const hiddenCount = items.length - 3;

            if (items.length > 3) {
                items.slice(3).hide();
                showMoreBtn.text(`Show ${hiddenCount} More Recommendations`).show();
            } else {
                showMoreBtn.hide();
            }

            showMoreBtn.off('click').on('click', function() {
                if (items.filter(':hidden').length > 0) {
                    items.slice(3).slideDown();
                    $(this).text('Show Less');
                } else {
                    items.slice(3).slideUp();
                    $(this).text(`Show ${hiddenCount} More Recommendations`);
                }
            });
        });
    };

    Seo.recommendations.renderAiRecommendationsForDetailView = function(recommendations, container) {
        container.empty();

        Seo.utils.fetchTemplate('ai-recommendations-detail', function(response) {
            const $template = $(response.data);
            const totalRecommendations = recommendations.length;
            $template.find('.ai-recs-subtitle span').text(`${totalRecommendations} opportunities`);
            container.append($template);

            const listContainer = container.find('.ai-recs-list');
            const getPriorityDetails = (priority) => {
                switch (priority.toLowerCase()) {
                    case 'high':
                        return { text: 'High Priority', icon: 'dashicons-warning', className: 'priority-high' };
                    case 'medium':
                        return { text: 'Medium Priority', icon: 'dashicons-info', className: 'priority-medium' };
                    default:
                        return { text: 'Low Priority', icon: 'dashicons-lightbulb', className: 'priority-low' };
                }
            };

            const parseSolution = (solution) => {
                if (!solution || typeof solution !== 'string') return [];
                const trimmed = solution.trim();
                if (!trimmed) return [];
                const matches = trimmed.match(/(\d+\.\s.*?(?=\d+\.|$))/gs);
                return matches || [trimmed];
            };

            Seo.utils.fetchTemplate('ai-recommendations-detail-item', function(itemResponse) {
                const itemTemplate = itemResponse.data;
                recommendations.forEach(rec => {
                    const priorityDetails = getPriorityDetails(rec.priority);
                    const $item = $(itemTemplate).clone();

                    $item.find('.ai-rec-title-group .dashicons').addClass(priorityDetails.icon).addClass(priorityDetails.className);
                    $item.find('.ai-rec-priority-badge').addClass(priorityDetails.className).text(priorityDetails.text);
                    $item.find('.ai-rec-title').text(rec.title);
                    $item.find('.ai-rec-description').text(rec.description);

                    const linkData = Seo.utils.getRecommendationLink(rec.title, rec.description);
                    const $link = $item.find('.ai-rec-solution-link');
                    if (linkData) {
                        $link.attr('href', linkData.url).text(linkData.label).show();
                    } else {
                        $link.remove();
                    }

                    const solutionSteps = parseSolution(rec.solution);
                    if (solutionSteps.length > 0) {
                        const stepsContainer = $item.find('.ai-rec-solution-steps');
                        solutionSteps.forEach((line, index) => {
                            const stepText = line.replace(/^\d+\.\s*/, '');
                            const step = $('<div>').addClass('ai-rec-solution-step')
                                .append($('<span>').addClass('ai-rec-step-number').text(index + 1))
                                .append($('<p>').addClass('ai-rec-step-text').text(stepText));
                            stepsContainer.append(step);
                        });
                    } else {
                        $item.find('.ai-rec-solution').hide();
                    }

                    listContainer.append($item);
                });
            });
        });
    };

    Seo.recommendations.renderAuditDetails = function(auditItem, skipLoader) {
        $('.recommendation-card-header, #toggle-recommendations').hide();

        const container = $('#recommendations-list');
        container.empty().addClass('audit-detail-view');

        if (!skipLoader) {
            const loaderHtml = `
                <div id="audit-details-loader" style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 300px; padding: 40px;">
                    <div class="nuhello-loading" aria-hidden="true">
                        <svg class="pl" viewBox="0 0 64 64" width="64" height="64" xmlns="http://www.w3.org/2000/svg">
                            <circle class="pl__inner" cx="32" cy="32" r="13" fill="none" stroke="#3F215B" stroke-width="14" stroke-linecap="round" />
                            <circle class="pl__ring" cx="32" cy="32" r="27" fill="none" stroke="#49BC31" stroke-width="8" stroke-dasharray="127 82" stroke-linecap="round" transform="rotate(215)" />
                        </svg>
                    </div>
                    <div class="loading-text" style="margin-top: 15px;">Loading Seo Report</div>
                </div>
            `;
            container.html(loaderHtml);
        }

        const headerContainer = $('<div>').attr('id', 'audit-details-header-container');
        container.append(headerContainer);
        Seo.details.renderAuditDetailsHeader(auditItem, headerContainer);

        const aiRecsContainer = $('<div>').attr('id', 'ai-recommendations-detail-container');
        container.append(aiRecsContainer);
        Seo.recommendations.renderAiRecommendationsForDetailView(auditItem.aiRecommendations.recommendations, aiRecsContainer);

        const docSetupContainer = $('<div>').attr('id', 'doc-setup-detail-container');
        container.append(docSetupContainer);
        Seo.details.renderBasicDocumentSetup(auditItem.auditData, docSetupContainer);

        const onPageSeoContainer = $('<div>').attr('id', 'onpage-seo-detail-container');
        container.append(onPageSeoContainer);
        Seo.details.renderOnPageSeo(auditItem.auditData, onPageSeoContainer);

        const techPerfContainer = $('<div>').attr('id', 'tech-perf-detail-container');
        container.append(techPerfContainer);
        Seo.details.renderTechnicalPerformance(auditItem.auditData, techPerfContainer);

        const contentQualityContainer = $('<div>').attr('id', 'content-quality-detail-container');
        container.append(contentQualityContainer);
        Seo.details.renderContentQuality(auditItem.auditData, contentQualityContainer);

        const linksAnalysisContainer = $('<div>').attr('id', 'links-analysis-detail-container');
        container.append(linksAnalysisContainer);
        Seo.details.renderLinksAnalysis(auditItem.auditData, linksAnalysisContainer);

        const socialLinksContainer = $('<div>').attr('id', 'social-links-detail-container');
        container.append(socialLinksContainer);
        Seo.details.renderSocialLinks(auditItem.auditData, socialLinksContainer);
    };
})(window, jQuery);
