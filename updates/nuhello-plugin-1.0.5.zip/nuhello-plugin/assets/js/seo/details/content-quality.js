(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.details = Seo.details || {};

    Seo.details.renderContentQuality = function(auditData, container) {
        const data = auditData.data || {};

        const contentQualityItems = [
            {
                title: 'Words count',
                value: `${(data.words_count || 0).toLocaleString()} words`,
                status: (data.words_count || 0) >= 300,
                description: 'Content length is crucial for SEO. Longer, high-quality content typically performs better in search rankings.',
                warning: (data.words_count || 0) < 300 ? {
                    message: 'Content is too short.',
                    details: 'It is significant to have at least 300-500 words on your webpage. Ideally longer (1,000-2,500 words) & high quality content performs even better.'
                } : null,
                solution: 'Add more relevant, high-quality content to your page. Aim for at least 300-500 words, with 1,000-2,500 words being ideal for comprehensive topics.'
            },
            {
                title: 'Deprecated HTML tags',
                value: data.deprecated_html_tags?.length
                    ? `Found ${data.deprecated_html_tags.length} deprecated tags: ${data.deprecated_html_tags.join(', ')}`
                    : 'No deprecated tags found.',
                status: !data.deprecated_html_tags?.length,
                description: 'Deprecated HTML tags are outdated elements no longer recommended for use, as they are replaced by modern alternatives to improve web standards and functionality.',
                solution: 'Replace deprecated HTML tags with their modern equivalents. Use semantic HTML5 elements and CSS for styling instead of outdated tags.'
            }
        ];

        const passedItems = contentQualityItems.filter(item => item.status).length;
        const totalItems = contentQualityItems.length;

        container.empty();

        Seo.utils.fetchTemplate('content-quality', function(response) {
            const $template = $(response.data);
            $template.find('.detail-section-subtitle span').text(`${passedItems} out of ${totalItems}`);
            container.append($template);

            const listContainer = container.find('.detail-section-list');
            const getStatusDetails = (status) => {
                if (status === null) return { icon: 'dashicons-warning', label: 'Warning', className: 'status-warning' };
                return status ? { icon: 'dashicons-yes-alt', label: 'Pass', className: 'status-pass' } : { icon: 'dashicons-dismiss', label: 'Fail', className: 'status-fail' };
            };

            const getPriorityDetails = (status) => {
                if (status === null) return { text: 'Medium Priority', className: 'priority-medium' };
                return status ? { text: 'Low Priority', className: 'priority-low' } : { text: 'High Priority', className: 'priority-high' };
            };

            Seo.utils.fetchTemplate('content-quality-item', function(itemResponse) {
                const itemTemplate = itemResponse.data;
                contentQualityItems.forEach((item, index) => {
                    const statusDetails = getStatusDetails(item.status);
                    const priorityDetails = getPriorityDetails(item.status);
                    const $itemEl = $(itemTemplate).clone();

                    $itemEl.find('.detail-item-title-group .dashicons').addClass(statusDetails.icon).addClass(statusDetails.className);
                    $itemEl.find('.status-badge').addClass(statusDetails.className).text(statusDetails.label);
                    if (item.status !== null) {
                        $itemEl.find('.priority-badge').addClass(priorityDetails.className).text(priorityDetails.text).show();
                    }
                    $itemEl.find('.detail-item-title').text(item.title);
                    $itemEl.find('.detail-item-description').text(item.description);
                    $itemEl.find('.detail-code-value').text(item.value);

                    if (item.warning) {
                        const $warning = $itemEl.find('.detail-warning');
                        $warning.find('.detail-warning-title').text(item.warning.message);
                        $warning.find('.detail-warning-text').text(item.warning.details);
                        $warning.show();
                    }

                    if (!item.status) {
                        const $toggle = $itemEl.find('.detail-solution-toggle');
                        $toggle.show().attr('data-index', index);
                        const $solution = $itemEl.find('.detail-solution');
                        $solution.attr('id', `content-solution-${index}`);
                        $solution.find('.detail-info-box-text').text(item.solution);
                    }

                    listContainer.append($itemEl);
                });
            });
        });

        container.on('click', '.detail-solution-toggle', function() {
            const index = $(this).data('index');
            $(`#content-solution-${index}`).slideToggle();
        });
    };
})(window, jQuery);
