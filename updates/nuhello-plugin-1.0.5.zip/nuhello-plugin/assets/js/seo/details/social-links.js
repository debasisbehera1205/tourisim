(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.details = Seo.details || {};

    Seo.details.renderSocialLinks = function(auditData, container) {
        const socialLinks = auditData?.data?.social_links
            ?.filter(link => link && link.href)
            ?.map(link => ({
                type: link.type || 'link',
                href: link.href,
                title: link.title || '',
                text: link.text || ''
            })) || [];

        if (socialLinks.length === 0) {
            container.hide();
            return;
        }

        const passedItems = socialLinks.length;
        const totalItems = socialLinks.length;

        container.empty();

        Seo.utils.fetchTemplate('social-links', function(response) {
            const $template = $(response.data);
            $template.find('.detail-section-subtitle span').text(`${passedItems} out of ${totalItems}`);
            container.append($template);

            const listContainer = container.find('.detail-section-list');
            const getSocialIcon = (type) => {
                switch (type.toLowerCase()) {
                    case 'twitter':
                        return 'dashicons-twitter';
                    case 'linkedin':
                        return 'dashicons-linkedin';
                    case 'facebook':
                        return 'dashicons-facebook-alt';
                    case 'instagram':
                        return 'dashicons-instagram';
                    default:
                        return 'dashicons-admin-links';
                }
            };

            Seo.utils.fetchTemplate('social-links-item', function(itemResponse) {
                const itemTemplate = itemResponse.data;
                socialLinks.forEach(item => {
                    const $itemEl = $(itemTemplate).clone();
                    const itemTitle = item.type.charAt(0).toUpperCase() + item.type.slice(1);

                    $itemEl.find('.detail-item-title-group .dashicons').addClass(getSocialIcon(item.type));
                    $itemEl.find('.detail-item-title').text(itemTitle);
                    $itemEl.find('.detail-item-description').text(`This ${item.type} link is properly configured and accessible.`);
                    $itemEl.find('.detail-link-value').attr('href', item.href).text(item.href);

                    listContainer.append($itemEl);
                });
            });
        });
    };
})(window, jQuery);
