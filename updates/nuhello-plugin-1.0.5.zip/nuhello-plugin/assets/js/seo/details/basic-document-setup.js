(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.details = Seo.details || {};

    Seo.details.renderBasicDocumentSetup = function(auditData, container) {
        const data = auditData.data || {};

        const documentSetupItems = [
            {
                title: 'Doctype declaration',
                value: data.doctype || 'Not found',
                status: !!data.doctype,
                description: 'The doctype declaration tells the browser about what document type to expect.',
                solution: 'Add <!DOCTYPE html> at the beginning of your HTML document.'
            },
            {
                title: 'Language attribute',
                value: data.language || 'Not found',
                status: !!data.language,
                description: "The language attribute tells browsers and search engines your webpage's main language, improving accessibility and accuracy.",
                solution: 'Add lang attribute to your HTML tag: <html lang="en">'
            },
            {
                title: 'Meta charset',
                value: data.meta_charset || 'Not found',
                status: !!data.meta_charset,
                description: 'The meta charset tag ensures your website uses the correct character encoding, preventing broken or garbled text and improving user experience.',
                solution: 'Add <meta charset="UTF-8"> in your HTML head section.'
            },
            {
                title: 'Meta viewport',
                value: data.meta_viewport || 'Not found',
                status: !!data.meta_viewport,
                description: 'The meta viewport tag ensures your website adapts to different screen sizes, improving mobile usability and user experience, which are crucial for SEO and engagement.',
                solution: 'Add <meta name="viewport" content="width=device-width, initial-scale=1.0"> in your HTML head section.'
            },
            {
                title: 'Favicon',
                value: data.favicon || 'Not found',
                status: !!data.favicon,
                description: 'The favicon is a small icon that represents your website in browser tabs, bookmarks, and search results, improving branding and user recognition.',
                solution: 'Add <link rel="icon" href="/favicon.ico" type="image/x-icon"> in your HTML head section.'
            }
        ];

        const passedItems = documentSetupItems.filter(item => item.status).length;
        const totalItems = documentSetupItems.length;

        container.empty();

        Seo.utils.fetchTemplate('basic-document-setup', function(response) {
            const $template = $(response.data);
            $template.find('.detail-section-subtitle span').text(`${passedItems} out of ${totalItems}`);
            container.append($template);

            const listContainer = container.find('.detail-section-list');
            const getStatusDetails = (status) => {
                if (status === null) return { icon: 'dashicons-warning', label: 'Warning', className: 'status-warning' };
                return status ? { icon: 'dashicons-yes-alt', label: 'Pass', className: 'status-pass' } : { icon: 'dashicons-dismiss', label: 'Fail', className: 'status-fail' };
            };

            Seo.utils.fetchTemplate('basic-document-setup-item', function(itemResponse) {
                const itemTemplate = itemResponse.data;
                documentSetupItems.forEach((item, index) => {
                    const statusDetails = getStatusDetails(item.status);
                    const $itemEl = $(itemTemplate).clone();

                    $itemEl.find('.detail-item-title-group .dashicons').addClass(statusDetails.icon).addClass(statusDetails.className);
                    $itemEl.find('.status-badge').addClass(statusDetails.className).text(statusDetails.label);
                    $itemEl.find('.detail-item-title').text(item.title);
                    $itemEl.find('.detail-item-description').text(item.description);

                    if (item.title === 'Favicon' && item.status) {
                        const faviconPreview = `<img src="${item.value}" alt="Favicon" class="detail-favicon-preview" />`;
                        $itemEl.find('.detail-code-value').replaceWith(faviconPreview);
                    } else {
                        const displayValue = item.value.length > 60 ? item.value.substring(0, 60) + '...' : item.value;
                        $itemEl.find('.detail-code-value').text(displayValue);
                    }

                    if (!item.status) {
                        const $toggle = $itemEl.find('.detail-solution-toggle');
                        $toggle.show().attr('data-index', index);
                        const $solution = $itemEl.find('.detail-solution');
                        $solution.attr('id', `solution-${index}`);
                        $solution.find('.detail-info-box-text').text(item.solution);
                    }

                    listContainer.append($itemEl);
                });
            });
        });

        container.on('click', '.detail-solution-toggle', function() {
            const index = $(this).data('index');
            $(`#solution-${index}`).slideToggle();
        });
    };
})(window, jQuery);
