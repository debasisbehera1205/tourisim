(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.utils = Seo.utils || {};

    Seo.utils.hasCardData = function(cardData, cardType) {
        if (!cardData) return false;

        switch (cardType) {
            case 'score':
                return cardData !== null && cardData !== undefined && cardData >= 0;
            case 'metric':
                return cardData !== null && cardData !== undefined && cardData !== '';
            case 'boolean':
                return cardData !== null && cardData !== undefined;
            case 'list':
                return cardData && cardData.length > 0;
            case 'object':
                return cardData && Object.keys(cardData).length > 0;
            default:
                return false;
        }
    };

    Seo.utils.manageRowVisibility = function(rowSelector, cardDataArray) {
        const $row = $(rowSelector);
        if (!$row.length) return;

        const hasAnyData = cardDataArray.some(cardInfo => Seo.utils.hasCardData(cardInfo.data, cardInfo.type));
        if (hasAnyData) {
            $row.show();
        } else {
            $row.hide();
        }
    };

    Seo.utils.scrollToSeoTabsNav = function() {
        let attempts = 0;
        const maxAttempts = 10;

        const tryScroll = function() {
            const $seoTabsNav = $('.seo-tabs-nav');
            if ($seoTabsNav.length && $seoTabsNav.is(':visible')) {
                const elementTop = $seoTabsNav.offset().top;
                const scrollPosition = Math.max(0, elementTop - 100);
                $('html, body').animate({ scrollTop: scrollPosition }, 600);
                return true;
            }

            if (attempts < maxAttempts) {
                attempts++;
                setTimeout(tryScroll, 100);
                return false;
            }

            return false;
        };

        tryScroll();
    };

    Seo.utils.formatResponseTime = function(ms) {
        if (ms < 1000) return `${Math.round(ms)} ms`;
        if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
        const minutes = Math.floor(ms / 60000);
        const seconds = Math.round((ms % 60000) / 1000);
        return `${minutes}m ${seconds}s`;
    };

    Seo.utils.formatFileSize = function(bytes) {
        if (bytes < 1024) return `${Math.round(bytes)} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    };

    Seo.utils.fetchTemplate = function(templateName, callback) {
        $.get(nuhello_ajax.ajax_url, {
            action: 'nuhello_get_template',
            template: templateName,
            nonce: nuhello_ajax.nonce
        }, callback);
    };

    Seo.utils.getAdminBase = function() {
        if (window.nuhello_ajax && nuhello_ajax.ajax_url) {
            return nuhello_ajax.ajax_url.replace('admin-ajax.php', '');
        }
        return '/wp-admin/';
    };

    Seo.utils.getRecommendationLink = function(title, description) {
        const haystack = `${title || ''} ${description || ''}`.toLowerCase();
        if (!haystack.trim()) return null;

        const adminBase = Seo.utils.getAdminBase();

        if (haystack.includes('favicon') || haystack.includes('site icon')) {
            return {
                url: adminBase + 'options-general.php',
                label: 'Open Site Icon Settings'
            };
        }

        if (haystack.includes('robots')) {
            return {
                url: adminBase + 'options-reading.php',
                label: 'Open Reading Settings'
            };
        }

        if (
            haystack.includes('meta description') ||
            haystack.includes('meta keywords') ||
            haystack.includes('title') ||
            haystack.includes('canonical') ||
            haystack.includes('content length') ||
            haystack.includes('word count') ||
            haystack.includes('content')
        ) {
            return {
                url: adminBase + 'edit.php?post_type=page',
                label: 'Open Pages'
            };
        }

        return null;
    };
})(window, jQuery);
