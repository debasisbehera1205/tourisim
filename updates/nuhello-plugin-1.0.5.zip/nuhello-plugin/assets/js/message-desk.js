(function ($) {
    const take = 10;
    let currentPage = 1;
    let totalItems = 0;
    let totalPages = 1;
    let currentSearch = "";
    let activeTab = "tickets";
    const hasAnyItems = {
        tickets: false,
        messages: false,
        leads: false
    };

    const itemsByTab = {
        tickets: [],
        messages: [],
        leads: []
    };

    const panelConfig = {
        tickets: {
            list: "#message-desk-list",
            loader: "#message-desk-loading",
            searchMessage: "#message-desk-search-message",
            searchEmpty: "#message-desk-search-empty",
            searchEmptyTitle: "#message-desk-search-empty-title",
            searchEmptyDesc: "#message-desk-search-empty-desc",
            empty: "#message-desk-empty",
            emptyTitle: "#message-desk-empty-title",
            emptyDesc: "#message-desk-empty-desc",
            emptyHint: "#message-desk-empty-hint"
        },
        messages: {
            list: "#message-desk-messages-list",
            loader: "#message-desk-messages-loading",
            searchMessage: "#message-desk-messages-search-message",
            searchEmpty: "#message-desk-messages-search-empty",
            searchEmptyTitle: "#message-desk-messages-search-empty-title",
            searchEmptyDesc: "#message-desk-messages-search-empty-desc",
            empty: "#message-desk-messages-empty",
            emptyTitle: "#message-desk-messages-empty-title",
            emptyDesc: "#message-desk-messages-empty-desc",
            emptyHint: "#message-desk-messages-empty-hint"
        },
        leads: {
            list: "#message-desk-leads-list",
            loader: "#message-desk-leads-loading",
            searchMessage: "#message-desk-leads-search-message",
            searchEmpty: "#message-desk-leads-search-empty",
            searchEmptyTitle: "#message-desk-leads-search-empty-title",
            searchEmptyDesc: "#message-desk-leads-search-empty-desc",
            empty: "#message-desk-leads-empty",
            emptyTitle: "#message-desk-leads-empty-title",
            emptyDesc: "#message-desk-leads-empty-desc",
            emptyHint: "#message-desk-leads-empty-hint"
        }
    };

    function getActiveConfig() {
        return panelConfig[activeTab] || panelConfig.tickets;
    }

    function timeAgo(date) {
        const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes} minutes ago`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours} hours ago`;
        const days = Math.floor(hours / 24);
        return `${days} days ago`;
    }

    function renderList(items, tab) {
        const config = panelConfig[tab] || panelConfig.tickets;
        const $list = $(config.list);
        if ($list.length === 0) return;

        const rows = items.map((item) => {
            return `
                <div class="message-desk-item" data-id="${item.id}" data-type="${tab}">
                    <div class="message-desk-avatar">${getInitials(item.name, item.email)}</div>
                    <div class="message-desk-sender">
                        <div class="message-desk-name">${item.name}</div>
                        <div class="message-desk-email">${item.email}</div>
                    </div>
                    <div class="message-desk-subject">
                        <strong>${item.subject}</strong>
                        <span class="message-desk-preview">- ${item.message}</span>
                    </div>
                    <span class="message-desk-badge">${item.ticketType}</span>
                    <span class="message-desk-time">${timeAgo(item.receivedAt)}</span>
                </div>
            `;
        });

        $list.html(rows.join(""));
        updateFilterCount(items.length);
    }

    function filterLeads() {
        const term = ($("#message-desk-search").val() || "").toString().toLowerCase();
        const base = itemsByTab[activeTab] || [];
        const filtered = base.filter((item) => {
            return (
                item.name.toLowerCase().includes(term) ||
                item.subject.toLowerCase().includes(term) ||
                item.message.toLowerCase().includes(term)
            );
        });
        renderList(filtered, activeTab);
        if (term && filtered.length === 0) {
            setSearchEmpty("No items found on this page", "Press Enter to search all pages.");
        } else {
            clearSearchEmpty();
        }
    }

    function setActiveTab(tab) {
        activeTab = tab;
        $(".message-desk-tab").removeClass("is-active");
        $(`.message-desk-tab[data-tab="${tab}"]`).addClass("is-active");
        $(".message-desk-panel").removeClass("is-active");
        $(`.message-desk-panel[data-panel="${tab}"]`).addClass("is-active");
    }

    function copyInboxEmail() {
        const $button = $(".message-desk-copy");
        const email = $button.data("copy");
        if (!email || !navigator.clipboard) return;
        navigator.clipboard.writeText(email).then(() => {
            $button.addClass("is-copied");
            setTimeout(() => $button.removeClass("is-copied"), 1500);
        });
    }

    function setLoading(isLoading) {
        const config = getActiveConfig();
        const $loading = $(config.loader);
        if (!$loading.length) return;
        if (isLoading) {
            $loading.removeAttr("hidden");
        } else {
            $loading.attr("hidden", "hidden");
        }
    }

    function updatePagination(total, page) {
        totalItems = total || 0;
        totalPages = Math.max(1, Math.ceil(totalItems / take));
        const startIndex = totalItems === 0 ? 0 : (page - 1) * take + 1;
        const endIndex = Math.min(page * take, totalItems);
        $("#message-desk-range").text(`${startIndex}-${endIndex} of ${totalItems}`);
        $("#message-desk-prev").prop("disabled", page <= 1);
        $("#message-desk-next").prop("disabled", page >= totalPages);
    }

    function updateFilterCount(filteredCount) {
        const term = ($("#message-desk-search").val() || "").toString().trim();
        const $filterCount = $("#message-desk-filter-count");
        if (term) {
            $filterCount.text(`${filteredCount} items`);
            $filterCount.removeAttr("hidden");
        } else {
            $filterCount.attr("hidden", "hidden");
        }
    }

    function setEmptyState(isEmpty, hintText) {
        const config = getActiveConfig();
        const $empty = $(config.empty);
        if (!$empty.length) return;
        if (isEmpty) {
            $(config.emptyHint).text(hintText || "");
            $empty.removeAttr("hidden");
            $(config.list).attr("hidden", "hidden");
            $(config.searchMessage).attr("hidden", "hidden");
            $(config.searchEmpty).attr("hidden", "hidden");
        } else {
            $empty.attr("hidden", "hidden");
            $(config.list).removeAttr("hidden");
        }
    }

    function setSearchEmpty(title, description) {
        const config = getActiveConfig();
        $(config.searchEmptyTitle).text(title || "No items found");
        $(config.searchEmptyDesc).text(description || "Try a different search term.");
        $(config.searchEmpty).removeAttr("hidden");
        $(config.searchMessage).attr("hidden", "hidden");
        $(config.list).attr("hidden", "hidden");
        $(config.empty).attr("hidden", "hidden");
    }

    function clearSearchEmpty() {
        const config = getActiveConfig();
        $(config.searchEmpty).attr("hidden", "hidden");
    }

    function updateInboxAddress(inboxAddress) {
        if (!inboxAddress) return;
        $(".message-desk-inbox-text strong").text(inboxAddress);
        $(".message-desk-copy").data("copy", inboxAddress);
        $(".message-desk-copy").prop("disabled", false);
    }

    function goToDetail(type, id) {
        const url = new URL(window.location.href);
        url.searchParams.set("page", "nuhello-dashboard");
        url.searchParams.set("tab", "message-desk");
        if (type === "messages") {
            url.searchParams.set("view", "message");
            url.searchParams.set("conversation_id", id);
        } else if (type === "leads") {
            url.searchParams.set("view", "lead");
            url.searchParams.set("lead_id", id);
        } else {
            url.searchParams.set("view", "ticket");
            url.searchParams.set("ticket_id", id);
        }
        window.location.href = url.toString();
    }

    function getPanelFromUrl() {
        try {
            const params = new URLSearchParams(window.location.search);
            const panel = params.get("panel");
            return panel && panelConfig[panel] ? panel : null;
        } catch (e) {
            return null;
        }
    }

    function mapTicket(ticket) {
        const email = ticket.contact?.email || ticket.contact_form?.email || ticket.email_meta?.customer_email || "";
        return {
            id: ticket.id,
            name: ticket.contact?.name || ticket.contact?.email || "Unknown",
            email,
            subject: ticket.AI_analysis?.subject || "No Subject",
            message: ticket.AI_analysis?.summary || "",
            receivedAt: new Date(ticket.last_updated || ticket.created_at),
            status: ticket.status || "open",
            ticketType: ticket.ticket_type || ticket.ticket_source || "ticket"
        };
    }

    function mapConversation(conv) {
        const email = conv.custom_parameters?.email || conv.visitor_info?.email || "";
        const name = conv.custom_parameters?.name || conv.visitor_info?.name || "Anonymous Visitor";
        const subject = conv.subject || "No Subject";
        const message = conv.summary || "";
        return {
            id: conv.conversation_id,
            name,
            email,
            subject,
            message,
            receivedAt: new Date(conv.last_message_time || conv.created_at || Date.now()),
            status: conv.status || "offline",
            ticketType: conv.topic || "message"
        };
    }

    function mapLead(lead) {
        const email = lead.contact_form?.email || "";
        const name = lead.contact_form?.fullname || "Unknown";
        const subject = lead.lead_context || lead.context || "Lead";
        const message = lead.lead_context || lead.context || lead.contact_form?.message || "";
        return {
            id: lead._id || lead.id,
            name,
            email,
            subject,
            message,
            receivedAt: new Date(lead.received_at || lead.created_at || Date.now()),
            status: lead.status || "new",
            ticketType: lead.connection_type || "lead"
        };
    }


    function getInitials(name, email) {
        const n = (name || "").trim();
        if (n) {
            const parts = n.split(" ");
            return ((parts[0]?.[0] || "") + (parts[1]?.[0] || "")).toUpperCase() || "U";
        }
        const e = (email || "").trim();
        return (e[0] || "U").toUpperCase();
    }



    function loadTickets(options = {}) {
        const search = options.search !== undefined ? options.search : currentSearch;
        $("#message-desk-empty-title").text("No tickets or emails yet");
        $("#message-desk-empty-desc").text("Tickets and inbound emails will appear here for triage and follow-up.");
        setLoading(true);
        setEmptyState(false);
        $("#message-desk-search").prop("disabled", true);
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: "GET",
            data: {
                action: "nuhello_get_message_desk_tickets",
                nonce: nuhello_ajax.nonce,
                take,
                page: currentPage,
                search
            },
            success: function (response) {
                const payload = response && response.success ? response.data : response;
                const rawTickets = Array.isArray(payload?.tickets) ? payload.tickets : [];
                itemsByTab.tickets = rawTickets.map(mapTicket);

                const inboxAddress = rawTickets.find((ticket) => ticket.email_meta?.inbox_address)?.email_meta?.inbox_address;
                updateInboxAddress(inboxAddress);

                totalItems = payload?.total || rawTickets.length || 0;
                if (!search) {
                    hasAnyItems.tickets = totalItems > 0;
                }
                updatePagination(totalItems, currentPage);
                $("#message-desk-search").prop("disabled", !hasAnyItems.tickets && !search);

                if (rawTickets.length === 0) {
                    if (search) {
                        setSearchEmpty(`No tickets found for "${search}"`, "Try a different search term.");
                        setEmptyState(false);
                    } else {
                        setEmptyState(true, inboxAddress ? `Emails sent to ${inboxAddress} will appear here.` : "");
                    }
                } else {
                    clearSearchEmpty();
                }
                $("#message-desk-search-clear").prop("hidden", !search);
                renderList(itemsByTab.tickets, "tickets");
            },
            error: function () {
                $("#message-desk-empty-title").text("Failed to load data");
                $("#message-desk-empty-desc").text("Please check the API and try again.");
                setEmptyState(true, "");
                updatePagination(0, 1);
                $("#message-desk-search").prop("disabled", !hasAnyItems.tickets && !currentSearch);
            },
            complete: function () {
                setLoading(false);
            }
        });
    }

    function loadMessages(options = {}) {
        const search = options.search !== undefined ? options.search : currentSearch;
        $("#message-desk-messages-empty-title").text("No messages yet");
        $("#message-desk-messages-empty-desc").text("Chat conversations will appear here.");
        setLoading(true);
        setEmptyState(false);
        $("#message-desk-search").prop("disabled", true);
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: "GET",
            data: {
                action: "nuhello_get_message_desk_conversations",
                nonce: nuhello_ajax.nonce,
                take,
                page: currentPage,
                search
            },
            success: function (response) {
                const payload = response && response.success ? response.data : response;
                const raw = Array.isArray(payload?.conversations) ? payload.conversations : [];
                itemsByTab.messages = raw.map(mapConversation);
                totalItems = payload?.total_conversations || raw.length || 0;
                if (!search) {
                    hasAnyItems.messages = totalItems > 0;
                }
                updatePagination(totalItems, currentPage);
                $("#message-desk-search").prop("disabled", !hasAnyItems.messages && !search);
                if (raw.length === 0) {
                    if (search) {
                        setSearchEmpty(`No messages found for "${search}"`, "Try a different search term.");
                        setEmptyState(false);
                    } else {
                        setEmptyState(true, "");
                    }
                } else {
                    clearSearchEmpty();
                }
                $("#message-desk-search-clear").prop("hidden", !search);
                renderList(itemsByTab.messages, "messages");
            },
            error: function () {
                $("#message-desk-messages-empty-title").text("Failed to load data");
                $("#message-desk-messages-empty-desc").text("Please check the API and try again.");
                setEmptyState(true, "");
                updatePagination(0, 1);
                $("#message-desk-search").prop("disabled", !hasAnyItems.messages && !currentSearch);
            },
            complete: function () {
                setLoading(false);
            }
        });
    }

    function loadLeads(options = {}) {
        const search = options.search !== undefined ? options.search : currentSearch;
        $("#message-desk-leads-empty-title").text("No leads yet");
        $("#message-desk-leads-empty-desc").text("Leads will appear here.");
        setLoading(true);
        setEmptyState(false);
        $("#message-desk-search").prop("disabled", true);
        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: "GET",
            data: {
                action: "nuhello_get_message_desk_leads",
                nonce: nuhello_ajax.nonce,
                take,
                page: currentPage,
                search
            },
            success: function (response) {
                const payload = response && response.success ? response.data : response;
                const raw = Array.isArray(payload?.leads) ? payload.leads : payload || [];
                const rawArray = Array.isArray(raw) ? raw : [];
                itemsByTab.leads = rawArray.map(mapLead);
                totalItems = payload?.total || rawArray.length || 0;
                if (!search) {
                    hasAnyItems.leads = totalItems > 0;
                }
                updatePagination(totalItems, currentPage);
                $("#message-desk-search").prop("disabled", !hasAnyItems.leads && !search);
                if (rawArray.length === 0) {
                    if (search) {
                        setSearchEmpty(`No leads found for "${search}"`, "Try a different search term.");
                        setEmptyState(false);
                    } else {
                        setEmptyState(true, "");
                    }
                } else {
                    clearSearchEmpty();
                }
                $("#message-desk-search-clear").prop("hidden", !search);
                renderList(itemsByTab.leads, "leads");
            },
            error: function () {
                $("#message-desk-leads-empty-title").text("Failed to load data");
                $("#message-desk-leads-empty-desc").text("Please check the API and try again.");
                setEmptyState(true, "");
                updatePagination(0, 1);
                $("#message-desk-search").prop("disabled", !hasAnyItems.leads && !currentSearch);
            },
            complete: function () {
                setLoading(false);
            }
        });
    }

    function loadActiveTab(options = {}) {
        if (activeTab === "messages") {
            loadMessages(options);
            return;
        }
        if (activeTab === "leads") {
            loadLeads(options);
            return;
        }
        loadTickets(options);
    }

    $(document).ready(function () {
        $("#message-desk-search-clear").prop("hidden", true);
        const copyEmail = $(".message-desk-copy").data("copy");
        $(".message-desk-copy").prop("disabled", !copyEmail);

        const panel = getPanelFromUrl();
        if (panel) {
            setActiveTab(panel);
        }
        loadActiveTab();

        $("#message-desk-search").on("input", function () {
            filterLeads();
        });

        $("#message-desk-search").on("keydown", function (event) {
            if (event.key !== "Enter") return;
            currentSearch = $(this).val().toString().trim();
            currentPage = 1;
            $("#message-desk-search-clear").prop("hidden", currentSearch.length === 0);
            loadActiveTab({ search: currentSearch });
        });

        $("#message-desk-search-clear").on("click", function () {
            $("#message-desk-search").val("");
            $(this).prop("hidden", true);
            currentSearch = "";
            currentPage = 1;
            $(getActiveConfig().searchMessage).attr("hidden", "hidden");
            loadActiveTab({ search: "" });
        });

        $("#message-desk-prev").on("click", function () {
            if (currentPage <= 1) return;
            currentPage -= 1;
            loadActiveTab();
        });

        $("#message-desk-next").on("click", function () {
            if (currentPage >= totalPages) return;
            currentPage += 1;
            loadActiveTab();
        });

        $(document).on("click", ".message-desk-item", function (event) {
            const itemId = $(this).data("id");
            const type = $(this).data("type") || activeTab;
            if (!itemId) return;
            goToDetail(type, itemId);
        });

        $(document).on("click", ".message-desk-tab", function () {
            const tab = $(this).data("tab");
            setActiveTab(tab);
            currentPage = 1;
            $("#message-desk-search").val("");
            updateFilterCount(0);
            clearSearchEmpty();

            currentSearch = "";
            $("#message-desk-search-clear").prop("hidden", true);
            $(getActiveConfig().searchMessage).attr("hidden", "hidden");
            updatePagination(0, 1);
            setEmptyState(false);
            loadActiveTab({ search: "" });
        });

        $(document).on("click", "[data-action='refresh']", function () {
            loadActiveTab({ search: currentSearch });
        });

        $(document).on("click", ".message-desk-copy", copyInboxEmail);
    });
})(jQuery);
