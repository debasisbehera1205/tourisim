(function($){
    'use strict';

    // Only initialize if container exists
    $(document).ready(function(){
        var $container = $('.nuhello-email-verifier');
        if (!$container.length) return;

        var $singleInput = $container.find('[data-ef-single-input]');
        var $singleBtn = $container.find('[data-ef-verify-single]');
        var $bulkInput = $container.find('[data-ef-bulk-input]');
        var $bulkBtn = $container.find('[data-ef-verify-bulk]');
        var $results = $container.find('[data-ef-results]');
    var $toggleSingle = $container.find('[data-ef-toggle-single]');
    var $toggleBulk = $container.find('[data-ef-toggle-bulk]');
    var $panelSingle = $container.find('[data-ef-panel-single]');
    var $panelBulk = $container.find('[data-ef-panel-bulk]');

        function showButtonLoading($btn, text) {
            $btn.prop('disabled', true);
            $btn.data('orig-text', $btn.html());
            $btn.html('<span class="ef-spinner" aria-hidden="true"></span> ' + (text||'Verifying...'));
        }

        function hideButtonLoading($btn) {
            $btn.prop('disabled', false);
            var orig = $btn.data('orig-text');
            if (orig) $btn.html(orig);
        }

        function getConfidence(result) {
            if (!result || !result.response) return 0;
            var status = result.response.status;
            var safetosend = result.response.safetosend;
            if (status === 'Valid' && safetosend === 'Yes') return 91;
            if (status === 'Invalid' || safetosend === 'No') return 10;
            return 50;
        }

        function avatarColorClass(status) {
            if (!status) return 'ef-avatar-gray';
            status = status.toLowerCase();
            if (status === 'valid') return 'ef-avatar-green';
            if (status === 'invalid') return 'ef-avatar-red';
            return 'ef-avatar-yellow';
        }

        function iconForStatus(status) {
            if (!status) return '●';
            status = status.toLowerCase();
            if (status === 'valid') return '✔';
            if (status === 'invalid') return '✖';
            return '?';
        }

        function renderResults(dataArray) {
            $results.empty();
            if (!Array.isArray(dataArray) || dataArray.length === 0) return;

            dataArray.forEach(function(item){
                var status = item.response ? (item.response.status || 'Unknown') : 'Unknown';
                var confidence = getConfidence(item);
                var v_response = (item.response && item.response.v_response) ? item.response.v_response : 'No details';

                var $card = $(
                    '<button type="button" class="ef-result-card" data-ef-email="'+(item.verify||'')+'">' +
                        '<div class="ef-avatar '+avatarColorClass(status)+'">'+iconForStatus(status)+'</div>' +
                        '<div class="ef-result-body">' +
                            '<div class="ef-result-title">'+(item.verify||'')+' <span class="ef-badge">'+status+'</span></div>' +
                            '<div class="ef-result-meta"><span class="ef-confidence">'+confidence+'% Confidence</span> · <span class="ef-vresp">'+v_response+'</span></div>' +
                        '</div>' +
                        '<div class="ef-chevron">›</div>' +
                    '</button>'
                );

                $card.on('click', function(){
                    openDetailDialog(item);
                });

                $results.append($card);
            });
        }

        function showPanel(type) {
            if (type === 'single') {
                $panelSingle.show();
                $panelBulk.hide();
                $toggleSingle.addClass('ef-toggle-active');
                $toggleBulk.removeClass('ef-toggle-active');
            } else if (type === 'bulk') {
                $panelSingle.hide();
                $panelBulk.show();
                $toggleBulk.addClass('ef-toggle-active');
                $toggleSingle.removeClass('ef-toggle-active');
            }
        }

        // initial state: hide both panels until user toggles
        $panelSingle.hide();
        $panelBulk.hide();

        $toggleSingle.on('click', function(e){ e.preventDefault(); showPanel('single'); });
        $toggleBulk.on('click', function(e){ e.preventDefault(); showPanel('bulk'); });

        function openDetailDialog(item) {
            var status = item.response ? (item.response.status || 'Unknown') : 'Unknown';
            var safetosend = item.response ? (item.response.safetosend || '') : '';
            var mx_server = item.response ? (item.response.mx_server || '') : '';
            var mx_response = item.response ? (item.response.mx_response || '') : '';
            var type = item.response ? (item.response.type || '') : '';
            var v_response = item.response ? (item.response.v_response || '') : '';

            var $overlay = $('<div class="ef-modal-overlay"></div>');
            var $dialog = $('<div class="ef-modal"><button class="ef-modal-close">×</button></div>');

            var $content = $('<div class="ef-modal-content"></div>');
            $content.append('<h3 class="ef-modal-email">'+(item.verify||'')+'</h3>');
            $content.append('<div class="ef-modal-badges"><span class="ef-modal-badge">'+status+'</span><span class="ef-modal-badge ef-modal-confidence">'+getConfidence(item)+'%</span></div>');

            $content.append('<div class="ef-details-grid">'
                +'<div class="ef-detail"> <strong>Format</strong><div>'+(status==='Valid' ? 'Valid' : 'Invalid')+'</div></div>'
                +'<div class="ef-detail"> <strong>Type</strong><div>'+(type||'Unknown')+'</div></div>'
                +'<div class="ef-detail"> <strong>MX Server</strong><div>'+(mx_server||'No MX')+'</div></div>'
                +'<div class="ef-detail"> <strong>Deliverability</strong><div>'+(safetosend==='Yes' ? 'Safe to Send' : (safetosend==='No' ? 'Risky' : v_response||'Unknown'))+'</div></div>'
                +'</div>');

            if (mx_response) {
                $content.append('<div class="ef-server-response"><button class="ef-toggle-server">Server Response</button><pre class="ef-server-pre" style="display:none;">'+mx_response+'</pre></div>');
            }

            $dialog.append($content);
            $('body').append($overlay).append($dialog);

            function closeModal(){
                $overlay.remove();
                $dialog.remove();
            }

            $overlay.on('click', closeModal);
            $dialog.find('.ef-modal-close').on('click', closeModal);
            $dialog.find('.ef-toggle-server').on('click', function(){
                $(this).siblings('.ef-server-pre').slideToggle(150);
            });
        }

        // Single verify
        $singleBtn.on('click', function(e){
            e.preventDefault();
            var email = ($singleInput.val()||'').trim();
            if (!email) return alert('Please enter an email address');
            // basic email regex
            var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!re.test(email)) return alert('Please enter a valid email');

            showButtonLoading($singleBtn, 'Verifying...');

            $.ajax({
                url: nuhello_email_verification_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'nuhello_verify_email',
                    nonce: nuhello_email_verification_ajax.nonce,
                    email: email
                },
                dataType: 'json'
            }).done(function(resp){
                if (resp.success && resp.data) {
                    // resp.data expected to have "data" array per Flask
                    var payload = resp.data;
                    var arr = payload.data || [];
                    renderResults(arr);
                } else {
                    alert((resp.data && resp.data.message) || resp.data || 'Verification failed');
                }
            }).fail(function(xhr){
                alert('AJAX error while verifying email');
            }).always(function(){
                hideButtonLoading($singleBtn);
            });
        });

        // Bulk verify
        $bulkBtn.on('click', function(e){
            e.preventDefault();
            var raw = ($bulkInput.val()||'').trim();
            if (!raw) return alert('Please enter at least one email');

            var emails = raw.split(/[\r\n,]+/).map(function(x){return x.trim();}).filter(function(x){return x;});
            if (emails.length === 0) return alert('Please enter at least one email');
            if (emails.length > 100) return alert('Maximum 100 emails allowed');

            showButtonLoading($bulkBtn, 'Verifying...');

            $.ajax({
                url: nuhello_email_verification_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'nuhello_verify_email_bulk',
                    nonce: nuhello_email_verification_ajax.nonce,
                    emails: emails
                },
                dataType: 'json'
            }).done(function(resp){
                if (resp.success && resp.data) {
                    var payload = resp.data;
                    var arr = payload.data || [];
                    renderResults(arr);
                } else {
                    alert((resp.data && resp.data.message) || resp.data || 'Bulk verification failed');
                }
            }).fail(function(){
                alert('AJAX error while verifying emails');
            }).always(function(){
                hideButtonLoading($bulkBtn);
            });
        });

    });

})(jQuery);
