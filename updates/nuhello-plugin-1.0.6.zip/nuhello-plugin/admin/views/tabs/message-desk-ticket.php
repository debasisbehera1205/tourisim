<?php
/**
 * Message Desk Ticket Detail
 *
 * @package Nuhello_Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

$message_desk_email = get_option('nuhello_chatbot_email', '');
$has_message_desk_email = !empty($message_desk_email);
$ticket_id = isset($_GET['ticket_id']) ? sanitize_text_field($_GET['ticket_id']) : '';
?>

<div id="message-desk-ticket-root" class="dashboard-layout message-desk">
    <div class="unified-header">
        <div class="header-content">
            <h2><i class="dashicons dashicons-email-alt"></i> Message Desk</h2>
            <p class="header-description">Manage all your customer communications in one place</p>
        </div>
        <div class="header-actions">
            <div class="widget-controls">
                <div class="message-desk-inbox">
                    <span class="message-desk-inbox-icon dashicons dashicons-email-alt"></span>
                    <span class="message-desk-inbox-text">
                        <strong><?php echo $has_message_desk_email ? esc_html($message_desk_email) : 'Not set'; ?></strong>
                    </span>
                    <button type="button" class="message-desk-copy" data-copy="<?php echo esc_attr($message_desk_email); ?>" title="Copy email address" <?php echo $has_message_desk_email ? '' : 'disabled'; ?>>
                        <span class="dashicons dashicons-admin-page"></span>
                    </button>
                </div>
                <button type="button" class="nuhello-upgrade-btn" id="nuhello-upgrade-open" data-upgrade-modal-open="true">
                    Upgrade Plan
                </button>
            </div>
        </div>
    </div>

    <div class="content-row">
        <div class="message-desk-card message-desk-detail-card">
            <div class="message-desk-detail-toolbar">
                <a class="message-desk-back-link" href="<?php echo esc_url(admin_url('admin.php?page=nuhello-dashboard&tab=message-desk&panel=tickets')); ?>">
                    <span class="dashicons dashicons-arrow-left-alt2"></span>
                    Back to tickets
                </a>
            </div>

            <div id="message-desk-ticket-detail" data-ticket-id="<?php echo esc_attr($ticket_id); ?>">
                <?php
                    $inline = true;
                    $loader_id = 'message-desk-ticket-loading';
                    include NUHELLO_PLUGIN_PATH . 'admin/views/templates/loader.php';
                ?>
                <div id="message-desk-ticket-content"></div>

                <div id="message-desk-reply-card" class="message-desk-reply-card" hidden>
                    <div class="message-desk-reply-card__header">
                        <span>Reply</span>
                        <button type="button" class="message-desk-reply-close" id="message-desk-reply-close" title="Close">
                            <span class="dashicons dashicons-no-alt"></span>
                        </button>
                    </div>
                    <div class="message-desk-reply-card__fields">
                        <div class="message-desk-reply-field">
                            <span class="message-desk-reply-label">To:</span>
                            <span id="message-desk-reply-to" class="message-desk-reply-value"></span>
                        </div>
                        <div class="message-desk-reply-field">
                            <span class="message-desk-reply-label">Subject:</span>
                            <span id="message-desk-reply-subject" class="message-desk-reply-value"></span>
                        </div>
                    </div>
                    <div class="message-desk-reply-card__editor">
                        <div class="message-desk-reply-editor-wrap" id="message-desk-reply-editor-wrap">
                            <div class="message-desk-reply-toolbar" role="toolbar" aria-label="Text formatting">
                                <button type="button" class="message-desk-reply-tool" data-command="bold" data-active="false"><strong>B</strong></button>
                                <button type="button" class="message-desk-reply-tool" data-command="italic" data-active="false"><em>I</em></button>
                                <button type="button" class="message-desk-reply-tool" data-command="underline" data-active="false"><span style="text-decoration: underline;">U</span></button>
                                <span class="message-desk-reply-tool-sep">|</span>
                                <button type="button" class="message-desk-reply-tool" data-command="insertUnorderedList" data-active="false">• List</button>
                                <button type="button" class="message-desk-reply-tool" data-command="insertOrderedList" data-active="false">1. List</button>
                                <button type="button" class="message-desk-reply-tool" data-command="formatBlock" data-value="blockquote" data-active="false">" Quote</button>
                                <button type="button" class="message-desk-reply-tool" data-command="removeFormat">Clear</button>
                            </div>
                            <div id="message-desk-reply-text" class="message-desk-reply-editor" contenteditable="true" data-placeholder="Type your reply..." role="textbox" aria-multiline="true"></div>
                        </div>
                        <div id="message-desk-reply-error" class="message-desk-reply-error" hidden></div>
                    </div>
                    <div class="message-desk-reply-card__actions">
                        <button type="button" class="message-desk-reply-send" id="message-desk-reply-send" disabled>
                            <span class="dashicons dashicons-email"></span>
                            Send
                        </button>
                        <button type="button" class="message-desk-reply-discard" id="message-desk-reply-discard">
                            Discard
                        </button>
                    </div>
                </div>
                <div class="message-desk-reply-actions">
                    <button type="button" class="message-desk-reply-open" id="message-desk-reply-open">
                        <span class="dashicons dashicons-editor-break"></span>
                        Reply
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
