(function(window, $) {
    const Dashboard = window.NuhelloDashboard = window.NuhelloDashboard || {};

    Dashboard.updateMetricChange = function(selector, change) {
        const $change = $(selector);
        if (!$change.length) return;

        $change.removeClass('positive negative');

        if (change >= 0) {
            $change.addClass('positive');
            $change.find('svg').html('<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>');
        } else {
            $change.addClass('negative');
            $change.find('svg').html('<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"></path>');
        }

        $change.find('span').text(Math.abs(change).toFixed(1) + '%');
    };

    Dashboard.renderMiniChart = function(selector, data, color) {
        const $container = $(selector);
        if (!$container.length) {
            console.warn('Chart container not found:', selector);
            return;
        }

        if (typeof Chart === 'undefined') {
            console.warn('Chart.js is not loaded, retrying...');
            setTimeout(function() {
                Dashboard.renderMiniChart(selector, data, color);
            }, 200);
            return;
        }

        $container.empty();
        const canvas = $('<canvas>').appendTo($container);

        setTimeout(function() {
            let width = $container.width();
            let height = $container.height();

            if (!width || width === 0) {
                width = window.innerWidth >= 768 ? 80 : (window.innerWidth >= 640 ? 64 : 80);
            }
            if (!height || height === 0) {
                height = window.innerWidth >= 768 ? 48 : (window.innerWidth >= 640 ? 40 : 48);
            }

            canvas[0].width = width;
            canvas[0].height = height;

            const allZero = Array.isArray(data) && data.length > 0 && data.every(value => Number(value) === 0);

            const yAxis = {
                display: false,
                grid: { display: false }
            };

            if (allZero) {
                yAxis.beginAtZero = true;
                yAxis.min = 0;
            }

            try {
                new Chart(canvas[0], {
                    type: 'line',
                    data: {
                        labels: data.map((_, i) => i),
                        datasets: [{
                            data: data,
                            borderColor: color,
                            backgroundColor: color + '40',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: false,
                        maintainAspectRatio: false,
                        animation: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: { enabled: false }
                        },
                        scales: {
                            x: {
                                display: false,
                                grid: { display: false }
                            },
                            y: yAxis
                        }
                    }
                });
            } catch (error) {
                console.error('Error creating chart for', selector, ':', error);
            }
        }, 100);
    };
})(window, jQuery);
