/**
 * Notification Settings JavaScript
 * 
 * @package Nuhello_Plugin
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        const NotificationManager = {
            defaultSettings: {
                title: 'Get notified on discount campaigns 🔥',
                description: 'Once a month, no spam, unsubscribe at any time.',
                learnMoreUrl: '',
                backgroundColor: '#ffffff',
                accentColor: '#3F215B',
                titleColor: '#000000',
                textColor: '#4B5563',
                position: 'top_left',
                layout: 'classic',
                showIcon: true,
                notificationIcon: '',
                acceptButtonText: 'Subscribe',
                rejectButtonText: 'No, thanks'
            },

            init: function() {
                this.bindEvents();
                this.loadCurrentSettings();
            },

            bindEvents: function() {
                // Save settings button
                $('#save-notification-settings').on('click', this.saveSettings.bind(this));
                
                // Reset settings button
                $('#reset-notification-settings').on('click', this.resetSettings.bind(this));
                
                // Refresh preview button
                $('#refresh-notification-preview').on('click', this.refreshPreview.bind(this));
                
                // Color input updates
                $('input[type="color"]').on('change', this.updateColorValue.bind(this));
                
                // Real-time preview updates
                $('#notification-settings-form input, #notification-settings-form textarea, #notification-settings-form select').on('change', this.debounce(this.updatePreview.bind(this), 500));
                
                // Image preview updates
                $('#notification-icon').on('input', this.updateImagePreview.bind(this));
            },

            loadCurrentSettings: function() {
                $('#widget-loading').show();
                $('.content-row').hide();

                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'nuhello_get_subscriber_widget_settings',
                        nonce: nuhello_ajax.nonce
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success && response.data.widget) {
                            const widget = response.data.widget;
                            $('#notification-title').val(widget.title || NotificationManager.defaultSettings.title);
                            $('#notification-description').val(widget.description || NotificationManager.defaultSettings.description);
                            $('#learn-more-url').val(widget.learnMoreUrl || NotificationManager.defaultSettings.learnMoreUrl);
                            $('#notification-background-color').val(widget.backgroundColor || NotificationManager.defaultSettings.backgroundColor);
                            $('#notification-accent-color').val(widget.accentColor || NotificationManager.defaultSettings.accentColor);
                            $('#notification-title-color').val(widget.titleColor || NotificationManager.defaultSettings.titleColor);
                            $('#notification-text-color').val(widget.textColor || NotificationManager.defaultSettings.textColor);
                            $('#notification-position').val(widget.position || NotificationManager.defaultSettings.position);
                            $('#notification-layout').val(widget.layout || NotificationManager.defaultSettings.layout);
                            $('#show-notification-icon').prop('checked', widget.showIcon !== false); // Default to true
                            $('#notification-icon').val(widget.notificationIcon || NotificationManager.defaultSettings.notificationIcon);
                            $('#accept-button-text').val(widget.acceptButtonText || NotificationManager.defaultSettings.acceptButtonText);
                            $('#reject-button-text').val(widget.rejectButtonText || NotificationManager.defaultSettings.rejectButtonText);
                            
                            // Update color values
                            NotificationManager.updateColorValue({ target: $('#notification-background-color')[0] });
                            NotificationManager.updateColorValue({ target: $('#notification-accent-color')[0] });
                            NotificationManager.updateColorValue({ target: $('#notification-title-color')[0] });
                            NotificationManager.updateColorValue({ target: $('#notification-text-color')[0] });
                            
                            // Update image preview
                            NotificationManager.updateImagePreview({ target: $('#notification-icon')[0] });

                            NotificationManager.updatePreview();
                        } else {
                            console.error('Failed to load subscriber widget settings:', response.data.message);
                            NotificationManager.showNotification('Failed to load settings from server.', 'error');
                            // Still update preview with defaults
                            NotificationManager.updatePreview();
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', error);
                        NotificationManager.showNotification('An error occurred while loading settings.', 'error');
                        // Still update preview with defaults
                        NotificationManager.updatePreview();
                    },
                    complete: function() {
                        $('#widget-loading').hide();
                        $('.content-row').show();
                    }
                });
            },

            initializePreview: function() {
                // The preview will be initialized in loadCurrentSettings's success callback
            },

            saveSettings: function(e) {
                e.preventDefault();
                
                const $button = $(e.target);
                const originalText = $button.html();
                
                // Show loading state
                $button.html('<i class="dashicons dashicons-update"></i> Saving...').prop('disabled', true);
                
                // Collect form data
                const formData = this.collectFormData();
                
                // Validate required fields
                if (!this.validateForm(formData)) {
                    this.showNotification('Please fill in all required fields.', 'error');
                    $button.html(originalText).prop('disabled', false);
                    return;
                }
                
                // Add nonce and action
                formData.nuhello_notification_nonce = $('#nuhello_notification_nonce').val();
                formData.action = 'nuhello_update_notification_settings';
                
                // Make AJAX request
                $.ajax({
                    url: nuhello_ajax.ajax_url,
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            NotificationManager.showNotification(response.data.message, 'success');
                            NotificationManager.updatePreview();
                        } else {
                            NotificationManager.showNotification(response.data.message || 'Failed to save settings.', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', error);
                        NotificationManager.showNotification('An error occurred while saving settings.', 'error');
                    },
                    complete: function() {
                        $button.html(originalText).prop('disabled', false);
                    }
                });
            },

            resetSettings: function(e) {
                e.preventDefault();
                
                if (confirm('Are you sure you want to reset all notification settings to default values?')) {
                    // Reset form to default values
                    $('#notification-title').val(this.defaultSettings.title);
                    $('#notification-description').val(this.defaultSettings.description);
                    $('#learn-more-url').val(this.defaultSettings.learnMoreUrl);
                    $('#notification-background-color').val(this.defaultSettings.backgroundColor);
                    $('#notification-accent-color').val(this.defaultSettings.accentColor);
                    $('#notification-title-color').val(this.defaultSettings.titleColor);
                    $('#notification-text-color').val(this.defaultSettings.textColor);
                    $('#notification-position').val(this.defaultSettings.position);
                    $('#notification-layout').val(this.defaultSettings.layout);
                    $('#show-notification-icon').prop('checked', this.defaultSettings.showIcon);
                    $('#notification-icon').val(this.defaultSettings.notificationIcon);
                    $('#accept-button-text').val(this.defaultSettings.acceptButtonText);
                    $('#reject-button-text').val(this.defaultSettings.rejectButtonText);
                    
                    // Update color values
                    this.updateColorValue({ target: $('#notification-background-color')[0] });
                    this.updateColorValue({ target: $('#notification-accent-color')[0] });
                    this.updateColorValue({ target: $('#notification-title-color')[0] });
                    this.updateColorValue({ target: $('#notification-text-color')[0] });
                    
                    // Update preview
                    this.updatePreview();
                    
                    this.showNotification('Settings reset to default values.', 'info');
                }
            },

            refreshPreview: function() {
                this.updatePreview();
            },

            updatePreview: function() {
                const formData = this.collectFormData();
                this.renderSubscriberWidget(formData);
            },

            updateColorValue: function(e) {
                const colorInput = $(e.target);
                const colorValue = colorInput.siblings('.color-value');
                if (colorValue.length) {
                    colorValue.text(colorInput.val());
                }
            },

            updateImagePreview: function(e) {
                const imageUrl = $(e.target).val();
                const preview = $('#notification-icon-preview img');
                const placeholder = $('#notification-icon-preview .image-placeholder');
                
                if (imageUrl) {
                    preview.attr('src', imageUrl).show();
                    placeholder.hide();
                } else {
                    preview.hide();
                    placeholder.show();
                }
            },

            collectFormData: function() {
                const formData = {};
                
                // Basic settings
                formData.title = $('#notification-title').val();
                formData.description = $('#notification-description').val();
                formData.learnMoreUrl = $('#learn-more-url').val();
                
                // Appearance
                formData.backgroundColor = $('#notification-background-color').val();
                formData.accentColor = $('#notification-accent-color').val();
                formData.titleColor = $('#notification-title-color').val();
                formData.textColor = $('#notification-text-color').val();
                
                // Layout & Position
                formData.position = $('#notification-position').val();
                formData.layout = $('#notification-layout').val();
                
                // Icon & Buttons
                formData.showIcon = $('#show-notification-icon').is(':checked');
                formData.notificationIcon = $('#notification-icon').val();
                formData.acceptButtonText = $('#accept-button-text').val();
                formData.rejectButtonText = $('#reject-button-text').val();
                
                return formData;
            },

            validateForm: function(formData) {
                // Basic validation
                if (!formData.title.trim()) {
                    this.showNotification('Notification title is required.', 'error');
                    return false;
                }
                
                if (!formData.description.trim()) {
                    this.showNotification('Notification description is required.', 'error');
                    return false;
                }
                
                return true;
            },

            renderSubscriberWidget: function(options) {
                const previewContainer = $('#subscriber-widget-preview');
                
                // Create the subscriber widget HTML
                const widgetHtml = this.createSubscriberWidgetHTML(options);
                
                // Update the preview
                previewContainer.html(widgetHtml);
                
                // Apply the subscriber widget styles
                this.applySubscriberWidgetStyles();
            },

            createSubscriberWidgetHTML: function(options) {
                const widget = options.widget || options;

                const isColorDark = (color) => {
                    if (!color) return false;
                    const hex = color.replace("#", "");
                    const r = parseInt(hex.substring(0, 2), 16);
                    const g = parseInt(hex.substring(2, 4), 16);
                    const b = parseInt(hex.substring(4, 6), 16);
                    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
                    return brightness < 128;
                };

                const buttonTextColor = isColorDark(widget.accentColor) ? '#ffffff' : '#000000';
                
                return `
                    <div class="subscriber-notice ${widget.position || 'top_left'} ${widget.layout || 'classic'}" 
                         style="background-color: ${widget.backgroundColor || '#ffffff'}; --border-color: ${widget.accentColor || '#3F215B'};">
                        <div class="subscriber-content">
                            <div class="content-inner">
                                ${widget.showIcon ? `
                                    <div class="notification-icon" style="color: ${widget.accentColor || '#3F215B'};">
                                        ${widget.notificationIcon ? `<img src="${widget.notificationIcon}" alt="Notification Icon" data-image />` : ''}
                                    </div>
                                ` : ''}
                                <div class="content">
                                    <h3 class="title" style="color: ${widget.titleColor || '#000000'}" data-title>
                                        ${widget.title || "Get notified on discount campaigns 🔥"}
                                    </h3>
                                    <p class="description" style="color: ${widget.textColor || '#4B5563'}" data-description>
                                        ${widget.description || "Once a month, no spam, unsubscribe at any time."}
                                        ${widget.learnMoreUrl ? `
                                            <a href="${widget.learnMoreUrl}" target="_blank" rel="noopener noreferrer" 
                                               style="color: ${widget.accentColor || '#3F215B'}">Learn More</a>
                                        ` : ''}
                                    </p>
                                    <div class="action-buttons" data-buttons>
                                        <button data-subscribe class="subscribe-button" 
                                                style="background-color: ${widget.accentColor || '#3F215B'}; color: ${buttonTextColor};">
                                            ${widget.acceptButtonText || "Subscribe"}
                                        </button>
                                        <button data-close class="reject-button rounded-lg border px-4 py-2 text-sm font-medium transition-colors" 
                                                style="border-color: ${widget.accentColor || '#3F215B'}; color: ${widget.accentColor || '#3F215B'};">
                                            ${widget.rejectButtonText || "No, thanks"}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            },

            applySubscriberWidgetStyles: function() {
                // Add the subscriber widget styles if not already present
                if (!$('#subscriber-widget-styles').length) {
                    const styles = `
                        <style id="subscriber-widget-styles">
                            .subscriber-notice {
                                font-family: Arial, sans-serif;
                                max-width: 415px;
                                width: 415px;
                                z-index: 1000;
                                position: relative;
                                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                                transition: all 0.3s;
                            }
                            
                            .subscriber-notice:hover {
                                transform: translateY(-2px);
                            }
                            
                            .subscriber-notice.banner-top {
                                position: relative;
                                left: 0;
                                right: 0;
                                top: 0;
                                width: 100%;
                                max-width: none;
                                border-radius: 0;
                            }
                            
                            .subscriber-notice.banner-bottom {
                                position: relative;
                                bottom: 0;
                                left: 0;
                                right: 0;
                                width: 100%;
                                max-width: none;
                                border-radius: 0;
                            }
                            
                            .subscriber-notice.classic {
                                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                                border-radius: 8px;
                            }
                            
                            .subscriber-notice.block {
                                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                                border-radius: 0;
                            }
                            
                            .subscriber-notice.edgeless {
                                box-shadow: none;
                                border-radius: 0;
                            }
                            
                            .subscriber-notice.wire {
                                box-shadow: none;
                                border-radius: 4px;
                                border: 1px solid var(--border-color);
                            }
                            
                            .subscriber-content {
                                padding: 1rem;
                            }
                            
                            .content-inner {
                                display: flex;
                                align-items: flex-start;
                                gap: 0.75rem;
                                width: 100%;
                            }
                            
                            .notification-icon {
                                flex-shrink: 0;
                            }
                            
                            .notification-icon img {
                                display: inline-block;
                                height: 1.5rem;
                                width: 1.5rem;
                                object-fit: contain;
                            }
                            
                            .content {
                                min-width: 0;
                                flex: 1;
                                width: 100%;
                            }
                            
                            .title {
                                margin-bottom: 0.5rem;
                                margin-top: 0;
                                font-size: 1rem;
                                font-weight: 600;
                                width: 100%;
                                overflow-wrap: break-word;
                                word-wrap: break-word;
                            }
                            
                            .description {
                                margin-bottom: 1rem;
                                margin-top: 0;
                                padding-right: 0.5rem;
                                font-size: 0.875rem;
                                width: 100%;
                                overflow-wrap: break-word;
                                word-wrap: break-word;
                            }
                            
                            .action-buttons {
                                display: flex;
                                flex-wrap: wrap;
                                gap: 0.5rem;
                            }
                            
                            .subscribe-button {
                                border-radius: 0.5rem;
                                padding: 0.5rem 1rem;
                                font-size: 0.875rem;
                                font-weight: 500;
                                transition: all 0.2s;
                                border: none;
                                cursor: pointer;
                            }
                            
                            .subscribe-button:hover {
                                opacity: 0.9;
                            }
                            
                            .reject-button {
                                border-radius: 0.5rem;
                                border-width: 1px;
                                padding: 0.5rem 1rem;
                                font-size: 0.875rem;
                                font-weight: 500;
                                transition: all 0.2s;
                                background: transparent;
                                cursor: pointer;
                            }
                            
                            .reject-button:hover {
                                opacity: 0.8;
                            }
                        </style>
                    `;
                    $('head').append(styles);
                }
            },

            showNotification: function(message, type) {
                const notification = $('<div class="nuhello-notification nuhello-notification-' + type + '">' + message + '</div>');
                
                $('#nuhello-notification-notifications').append(notification);
                
                // Auto-remove after 5 seconds
                setTimeout(function() {
                    notification.fadeOut(function() {
                        $(this).remove();
                    });
                }, 5000);
            },

            debounce: function(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }
        };

        // Initialize the notification manager
        NotificationManager.init();
    });

})(jQuery);
