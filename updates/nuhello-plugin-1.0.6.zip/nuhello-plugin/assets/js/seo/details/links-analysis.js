(function(window, $) {
    const Seo = window.NuhelloSeo = window.NuhelloSeo || {};
    Seo.details = Seo.details || {};

    Seo.details.renderLinksAnalysis = function(auditData, container) {
        const data = auditData.data || {};

        const linksItems = [
            {
                title: 'Internal links',
                value: `${data.internal_links_count || 0} links`,
                status: (data.internal_links_count || 0) > 0,
                description: 'Internal links help with site navigation and SEO by connecting related pages within your website.',
                solution: 'Add relevant internal links to connect related pages and improve site navigation and SEO.'
            },
            {
                title: 'External links',
                value: `${data.external_links_count || 0} links`,
                status: (data.external_links_count || 0) > 0,
                description: "External links to reputable sources can improve your content's credibility and SEO value.",
                solution: 'Add relevant external links to authoritative sources to improve content credibility and SEO value.'
            },
            {
                title: 'Unsafe external links',
                value: `${data.unsafe_external_links_count || 0} links`,
                status: (data.unsafe_external_links_count || 0) === 0,
                description: "Unsafe external links can harm your website's security and reputation.",
                warning: (data.unsafe_external_links_count || 0) > 0 ? {
                    message: 'Unsafe links detected.',
                    details: `Found ${data.unsafe_external_links_count} unsafe external links that should be reviewed.`
                } : null,
                solution: "Review and remove or fix any unsafe external links to protect your website's security and reputation."
            }
        ];

        const passedItems = linksItems.filter(item => item.status).length;
        const totalItems = linksItems.length;

        container.empty();

        Seo.utils.fetchTemplate('links-analysis', function(response) {
            const $template = $(response.data);
            $template.find('.detail-section-subtitle span').text(`${passedItems} out of ${totalItems}`);
            container.append($template);

            const listContainer = container.find('.detail-section-list');
            const getStatusDetails = (status) => {
                if (status === null) return { icon: 'dashicons-warning', label: 'Warning', className: 'status-warning' };
                return status ? { icon: 'dashicons-yes-alt', label: 'Pass', className: 'status-pass' } : { icon: 'dashicons-dismiss', label: 'Fail', className: 'status-fail' };
            };

            const getPriorityDetails = (status) => {
                if (status === null) return { text: 'Medium Priority', className: 'priority-medium' };
                return status ? { text: 'Low Priority', className: 'priority-low' } : { text: 'High Priority', className: 'priority-high' };
            };

            Seo.utils.fetchTemplate('links-analysis-item', function(itemResponse) {
                const itemTemplate = itemResponse.data;
                linksItems.forEach((item, index) => {
                    const statusDetails = getStatusDetails(item.status);
                    const priorityDetails = getPriorityDetails(item.status);
                    const $itemEl = $(itemTemplate).clone();

                    $itemEl.find('.detail-item-title-group .dashicons').addClass(statusDetails.icon).addClass(statusDetails.className);
                    $itemEl.find('.status-badge').addClass(statusDetails.className).text(statusDetails.label);
                    if (item.status !== null) {
                        $itemEl.find('.priority-badge').addClass(priorityDetails.className).text(priorityDetails.text).show();
                    }
                    $itemEl.find('.detail-item-title').text(item.title);
                    $itemEl.find('.detail-item-description').text(item.description);
                    $itemEl.find('.detail-code-value').text(item.value);

                    if (item.warning) {
                        const $warning = $itemEl.find('.detail-warning');
                        $warning.find('.detail-warning-title').text(item.warning.message);
                        $warning.find('.detail-warning-text').text(item.warning.details);
                        $warning.show();
                    }

                    if (!item.status) {
                        const $toggle = $itemEl.find('.detail-solution-toggle');
                        $toggle.show().attr('data-index', index);
                        const $solution = $itemEl.find('.detail-solution');
                        $solution.attr('id', `links-solution-${index}`);
                        $solution.find('.detail-info-box-text').text(item.solution);
                    }

                    listContainer.append($itemEl);
                });
            });
        });

        container.on('click', '.detail-solution-toggle', function() {
            const index = $(this).data('index');
            $(`#links-solution-${index}`).slideToggle();
        });
    };
})(window, jQuery);
