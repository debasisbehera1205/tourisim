jQuery(document).ready(function($) {

    // Helper function to check if a card has meaningful data
    function hasCardData(cardData, cardType) {
        if (!cardData) {
            return false;
        }
        
        let result = false;
        
        switch (cardType) {
            case 'stat':
                // For stat cards, check if the value is greater than 0
                result = cardData > 0;
                break;
            case 'list':
                // For list cards, check if there's data with meaningful values
                result = cardData && cardData.value && cardData.value.length > 0 && 
                        cardData.value.some(item => item.count > 0);
                break;
            case 'chart':
                // For chart cards, check if there's data to display
                if (Array.isArray(cardData)) {
                    // Handle array format (like session_lengths)
                    result = cardData.length > 0 && cardData.some(item => item.count > 0);
                } else {
                    // Handle object format (like visits_over_time)
                    result = cardData.value && Object.keys(cardData.value).length > 0 && 
                            Object.values(cardData.value).some(val => val > 0);
                }
                break;
            case 'map':
                // For map cards, check if there's country data
                result = cardData.value && cardData.value.length > 0 && 
                        cardData.value.some(item => item.count > 0);
                break;
            case 'utm':
                // For UTM cards, check if any UTM type has data
                result = Object.values(cardData).some(utmData => 
                    utmData && utmData.value && utmData.value.length > 0 && 
                    utmData.value.some(item => item.count > 0)
                );
                break;
            default:
                result = false;
        }
        
        return result;
    }

    // Helper function to manage row visibility based on card data
    function manageRowVisibility(rowSelector, cardDataArray) {
        // Handle both jQuery objects and CSS selectors
        const $row = typeof rowSelector === 'string' ? $(rowSelector) : rowSelector;
        if (!$row.length) return;
        
        // Check if any card in the row has data
        const hasAnyData = cardDataArray.some(cardInfo => {
            const hasData = hasCardData(cardInfo.data, cardInfo.type);
            return hasData === true; // Only show if explicitly true
        });
        
        if (hasAnyData) {
            $row.show();
            $row.css('display', 'grid !important'); // Force grid display with !important
            $row.removeClass('hidden').addClass('visible');
        } else {
            $row.hide();
            $row.css('display', 'none !important'); // Force none display with !important
            $row.removeClass('visible').addClass('hidden');
        }
    }

    // Helper function to get icon for list items
    function getIconForItem(cardTitle, itemName) {
        if (!itemName) return null;
        const normalizedName = itemName.toLowerCase().replace(/\s+/g, '');
        switch (cardTitle.toLowerCase()) {
            case 'browsers':
                return 'dashicons dashicons-admin-site-alt3';
            case 'operating systems':
                if (normalizedName.includes('ios') || normalizedName.includes('android')) return 'dashicons dashicons-smartphone';
                return 'dashicons dashicons-admin-generic';
            case 'devices':
                 if (normalizedName.includes('mobile')) return 'dashicons dashicons-smartphone';
                 if (normalizedName.includes('tablet')) return 'dashicons dashicons-tablet';
                 return 'dashicons dashicons-desktop';
            case 'countries':
                if (itemName && itemName.length === 2) {
                    return `https://flagcdn.com/w20/${itemName.toLowerCase()}.png`;
                }
                return null; // No dashicon for flags, will be handled in render function
            default:
                return null;
        }
    }

    // Render main stat cards
    function renderStats(data) {
        $('#total-visitors').text(data.dashboard_data?.value?.[0]?.visitors || 0);
        $('#total-sessions').text(data.dashboard_data?.value?.[0]?.sessions || 0);
        $('#total-page-views').text(data.total_pageviews || 0);
        $('#bounce-rate').text(`${(data.bounce_rate || 0).toFixed(1)}%`);
    }

    // Get icon for list card titles
    function getIconForTitle(title) {
        switch (title.toLowerCase()) {
            case "operating systems": return 'dashicons dashicons-admin-generic';
            case "devices": return 'dashicons dashicons-desktop';
            case "browsers": return 'dashicons dashicons-admin-site-alt3';
            case "pages": return 'dashicons dashicons-admin-page';
            case "referrers": return 'dashicons dashicons-admin-links';
            case "countries": return 'dashicons dashicons-location-alt';
            case "screen resolutions": return 'dashicons dashicons-desktop';
            case "browser languages": return 'dashicons dashicons-translation';
            default: return 'dashicons dashicons-chart-bar';
        }
    }

    // Get background color for icons based on theme
    function getIconBackgroundColor(color) {
        switch (color) {
            case 'blue': return 'var(--blue-100)';
            case 'green': return 'var(--green-100)';
            case 'purple': return 'var(--purple-100)';
            case 'red': return 'var(--red-100)';
            default: return 'var(--gray-100)';
        }
    }

    function getIconColor(color) {
        switch (color) {
            case 'blue': return 'var(--blue-600)';
            case 'green': return 'var(--green-600)';
            case 'purple': return 'var(--purple-600)';
            case 'red': return 'var(--red-600)';
            default: return 'var(--gray-600)';
        }
    }

    // Render a single list card (e.g., Pages, OS, etc.)
    function renderListCard(cardId, cardData, color) {
        const card = $(`#${cardId}`);
        if (!card.length) return;

        const iconClass = getIconForTitle(cardData.title);
        const iconBgColor = getIconBackgroundColor(color);

        let itemsHtml = '';
        if (cardData.data && cardData.data.length > 0) {
        cardData.data.forEach(item => {
            let itemIconHtml = '';
            if (item.icon) {
                if (item.icon.startsWith('https://')) {
                    itemIconHtml = `<img src="${item.icon}" alt="${item.label}" class="item-icon">`;
                } else {
                    itemIconHtml = `<span class="${item.icon} item-icon"></span>`;
                }
            }
            itemsHtml += `
                <div class="list-item">
                    <div class="list-item-progress-bar" style="width: ${item.percentage}%;"></div>
                    <div class="list-item-content">
                        <div class="list-item-label">
                            ${itemIconHtml}
                            <span>${item.label}</span>
                        </div>
                        <span class="list-item-value">${item.value}</span>
                    </div>
                </div>
            `;
        });
        } else {
            itemsHtml = '<p>No data available.</p>';
        }

        const iconColor = getIconColor(color);
        const cardHtml = `
            <div class="list-card-header">
                <div class="list-card-icon-wrapper" style="background-color: ${iconBgColor};">
                    <span class="${iconClass}" style="color: ${iconColor};"></span>
                </div>
                <h4 class="list-card-title">${cardData.title}</h4>
            </div>
            <div class="list-items">
                ${itemsHtml}
            </div>
        `;
        card.html(cardHtml);
    }

    // Render the "Visits Over Time" bar chart
    function renderVisitsOverTimeChart(data) {
        const ctx = document.getElementById('visitsOverTimeChart').getContext('2d');
        if (window.visitsOverTimeChart instanceof Chart) {
            window.visitsOverTimeChart.destroy();
        }
        const labels = Object.keys(data.value);
        const values = Object.values(data.value);

        window.visitsOverTimeChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Conversations',
                    data: values,
                    backgroundColor: '#49BC31'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        title: { display: true, text: 'Date' },
                        grid: { display: false },
                        ticks: {
                            callback: function(value) {
                                const date = new Date(this.getLabelForValue(value));
                                return date.toLocaleDateString('en-US', {day: '2-digit', month: 'short'});
                            }
                        }
                    },
                    y: {
                        title: { display: true, text: 'Number of Visits' },
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#22281E',
                        titleColor: 'white',
                        bodyColor: 'white',
                        callbacks: {
                            title: function(context) {
                                return new Date(context[0].label).toLocaleDateString('en-US', { day: '2-digit', month: 'long', year: 'numeric' });
                            },
                            label: function(context) {
                                return `${context.raw.toLocaleString()}`;
                            }
                        }
                    }
                }
            }
        });
    }

    // Render the "Visitor Map" choropleth chart
    function renderVisitorMapChart(data) {
        const canvas = document.getElementById('visitorMapChart');
        const ctx = canvas.getContext('2d');
        if (window.visitorMapChart instanceof Chart) {
            window.visitorMapChart.destroy();
        }

        // Tooltip element
        let tooltipEl = document.getElementById('chartjs-tooltip');
        if (!tooltipEl) {
            tooltipEl = document.createElement('div');
            tooltipEl.id = 'chartjs-tooltip';
            tooltipEl.style.opacity = 0;
            tooltipEl.style.position = 'absolute';
            tooltipEl.style.pointerEvents = 'none';
            tooltipEl.style.transition = 'opacity 0.2s ease';
            tooltipEl.style.zIndex = 10;
            tooltipEl.style.transform = 'translate(-50%, -100%)';
            canvas.parentNode.appendChild(tooltipEl);
        }

        fetch('https://unpkg.com/world-atlas/countries-50m.json')
            .then(r => r.json())
            .then(world => {
                const countries = ChartGeo.topojson.feature(world, world.objects.countries).features.filter(d => d.properties.name !== 'Antarctica');
                
                const countryData = data.value.reduce((obj, item) => {
                    obj[item.name] = { count: item.count, percentage: item.percentage, code: item.name };
                    return obj;
                }, {});

                console.log( 'countryData = ' ,countryData);

                const maxVisitors = Math.max(0, ...data.value.map(c => c.count));
                
                const countryCodeToName = {
                    'IN': 'India',
                    'US': 'United States of America',
                };

                const chartData = countries.map(d => {
                    const countryName = d.properties.name;
                    const countryCode = Object.keys(countryData).find(code => countryCodeToName[code] === countryName);
                    const value = countryCode ? countryData[countryCode] : { count: 0, code: '', percentage: 0 };
                    
                    return {
                        feature: d,
                        value: value,
                        flagUrl: value.code ? `https://flagcdn.com/w20/${value.code.toLowerCase()}.png` : ''
                    };
                });

                const isMobile = window.innerWidth < 768;

                window.visitorMapChart = new Chart(ctx, {
                    type: 'choropleth',
                    data: {
                        labels: countries.map(d => d.properties.name),
                        datasets: [{
                            label: 'Countries',
                            data: chartData,
                            backgroundColor: chartData.map(d => {
                                const count = d.value.count || 0;
                                if (count === 0) return 'rgb(230,230,230)';
                                const intensity = count / maxVisitors;
                                return `rgba(73, 188, 49, ${0.2 + 0.8 * intensity})`;
                            }),
                            borderColor: 'rgba(255,255,255,1)',
                            borderWidth: isMobile ? 0.5 : 1,
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        layout: {
                            padding: {
                                left: isMobile ? 0 : 10,
                                right: isMobile ? 0 : 10,
                                top: isMobile ? 0 : 10,
                                bottom: isMobile ? 0 : 10,
                            }
                        },
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                enabled: false,
                                external: function(context) {
                                    const tooltipModel = context.tooltip;

                                    if (tooltipModel.opacity === 0) {
                                        tooltipEl.style.opacity = "0";
                                        return;
                                    }

                                    if (!tooltipModel.dataPoints || tooltipModel.dataPoints.length === 0) {
                                        tooltipEl.style.opacity = "0";
                                        return;
                                    }

                                    const dataIndex = tooltipModel.dataPoints[0].dataIndex;
                                    const tooltipData = chartData[dataIndex];

                                    const countryName = tooltipData.feature.properties.name;
                                    const flagUrl = tooltipData.flagUrl;
                                    const visitors = tooltipData.value.count || 0;

                                    const fontSize = isMobile ? '12px' : '14px';
                                    const padding = isMobile ? '6px' : '8px';

                                    const innerHtml = `
                                        <div style="background: #22281E; color: white; padding: ${padding}; border-radius: 4px; font-family: Arial, sans-serif;">
                                            <div style="display: flex; align-items: center; margin-bottom: 3px;">
                                                ${flagUrl ? `<img src="${flagUrl}" width="${isMobile ? '16' : '20'}" height="${isMobile ? '12' : '15'}" alt="${countryName} flag" style="margin-right: 5px;">` : ""}
                                                <span style="font-size: ${fontSize}; font-weight: bold;">${countryName}</span>
                                            </div>
                                            <div style="font-size: ${fontSize};">Visitors: ${visitors.toLocaleString()}</div>
                                        </div>`;

                                    tooltipEl.innerHTML = innerHtml;
                                    
                                    const position = context.chart.canvas.getBoundingClientRect();
                                    const containerWidth = context.chart.canvas.parentElement.offsetWidth;

                                    const tooltipX = isMobile ? 
                                        Math.min(Math.max(tooltipModel.caretX, 100), containerWidth - 100) : 
                                        tooltipModel.caretX;

                                    tooltipEl.style.opacity = "1";
                                    tooltipEl.style.position = "absolute";
                                    tooltipEl.style.left = `${tooltipX}px`;
                                    tooltipEl.style.top = `${tooltipModel.caretY}px`;
                                    tooltipEl.style.pointerEvents = "none";
                                }
                            }
                        },
                        scales: {
                            xy: {
                                projection: "equalEarth",
                            },
                            color: {
                                axis: "x",
                                display: false,
                            },
                        },
                        hover: {    
                          mode: null
                        },
                        elements: {
                          geodata: {
                            hover: {
                              mode: null
                            }
                          }
                        }
                    }
                });
            });
    }

    // Render the "Session Distribution" doughnut chart
    function renderSessionDistributionChart(data) {
        const ctx = document.getElementById('sessionDistributionChart').getContext('2d');
        if (window.sessionDistributionChart instanceof Chart) {
            window.sessionDistributionChart.destroy();
        }
        const labels = ["Short (0-5 mins)", "Medium (5-10 mins)", "Long (10+ mins)"];
        let seriesData;

        if (data && data.length > 0) {
            seriesData = [
                data.find(d => d.duration === "0-5")?.count || 0,
                data.find(d => d.duration === "5-10")?.count || 0,
                data.find(d => d.duration === "10+")?.count || 0
            ];
        } else {
            seriesData = [0, 0, 0];
        }

    window.sessionDistributionChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: seriesData,
                backgroundColor: ["#3f215b", "#3f215b50", "#3f215b20"],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        boxWidth: 8
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${context.raw} sessions`;
                        }
                    }
                }
            }
        }
    });
}

    // Render the UTM Analytics card with tabs
    function renderUtmCard(data) {
        const card = $('#utm-card');
        if (!card.length) return;

        const utmTypes = [
            { key: 'utm_source', label: 'Source' },
            { key: 'utm_medium', label: 'Medium' },
            { key: 'utm_campaign', label: 'Campaign' },
            { key: 'utm_content', label: 'Content' },
            { key: 'utm_term', label: 'Term' }
        ];

        const hasData = (type) => data[type]?.value && data[type].value.length > 0;
        const availableUtmTypes = utmTypes.filter(type => hasData(type.key));
        let activeTab = availableUtmTypes.length > 0 ? availableUtmTypes[0].key : null;

        const renderContent = () => {
            let itemsHtml = '';
            const activeData = activeTab ? (data[activeTab]?.value || []) : [];

            if (activeData.length > 0) {
                activeData.forEach(item => {
                    itemsHtml += `
                        <div class="list-item">
                            <div class="list-item-progress-bar" style="width: ${item.percentage}%;"></div>
                            <div class="list-item-content">
                                <span class="list-item-label">${item.name || 'Not set'}</span>
                                <span class="list-item-value">${item.count}</span>
                            </div>
                        </div>
                    `;
                });
            } else {
                itemsHtml = '<p>No data available.</p>';
            }

            const tabsHtml = utmTypes.map(type => `
                <button class="utm-tab ${activeTab === type.key ? 'active' : ''}" data-key="${type.key}" ${!hasData(type.key) ? 'disabled' : ''}>
                    <span>${type.label}</span>
                </button>
            `).join('');

            const cardHtml = `
                <div class="list-card-header">
                     <div class="list-card-icon-wrapper" style="background-color: rgba(73, 188, 49, 0.1);">
                        <span class="dashicons dashicons-tag"></span>
                    </div>
                    <h4 class="list-card-title">UTM Analytics</h4>
                </div>
                <div class="utm-tabs">${tabsHtml}</div>
                <div class="list-card-body">
                    <div class="list-header">
                        <span>VALUE</span>
                        <span>VISITORS</span>
                    </div>
                    <div class="list-items">
                        ${itemsHtml}
                    </div>
                </div>
            `;
            card.html(cardHtml);

            card.find('.utm-tab').on('click', function() {
                if (!$(this).is(':disabled')) {
                    activeTab = $(this).data('key');
                    renderContent();
                }
            });
        };

        renderContent();
    }


    // Main function to fetch and render all analytics data
    function fetchAnalytics() {
        $('#analytics-dashboard-loading').show();
        $('#analytics-dashboard-content').hide();

        $.ajax({
            url: nuhello_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nuhello_get_analytics_by_chatbot',
                nonce: nuhello_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    processAnalyticsData(response.data);
                    } else {
                    console.error('Analytics data fetch failed:', response.data);
                    $('#analytics-dashboard-loading').hide();
                    $('#analytics-dashboard-content').show();
                }
            },
            error: function(xhr, status, error) {
                console.error('Analytics AJAX error:', error);
                $('#analytics-dashboard-loading').hide();
                $('#analytics-dashboard-content').show();
            }
        });
    }

    function processAnalyticsData(data) {
        console.log('Processing analytics data:', data);
        
        renderStats(data);

        // Define card data for row visibility management
        const cardsData = [
            { id: 'pages-card', data: data.paths, title: "Pages", left: "PAGE", right: "PAGEVIEWS", color: "blue" },
            { id: 'os-card', data: data.operating_systems, title: "Operating Systems", left: "OS", right: "VISITORS", color: "red" },
            { id: 'devices-card', data: data.device_types, title: "Devices", left: "DEVICE TYPE", right: "VISITORS", color: "purple" },
            { id: 'browsers-card', data: data.browser_names, title: "Browsers", left: "BROWSER", right: "VISITORS", color: "blue" },
            { id: 'countries-card', data: data.countries, title: "Countries", left: "COUNTRY", right: "VISITORS", color: "green" },
            { id: 'resolutions-card', data: data.screen_resolutions, title: "Screen Resolutions", left: "RESOLUTION", right: "VISITORS", color: "red" },
            { id: 'languages-card', data: data.browser_languages, title: "Browser Languages", left: "LANGUAGE", right: "VISITORS", color: "purple" },
            { id: 'referrers-card', data: data.referrers, title: "Referrers", left: "DOMAIN", right: "VISITORS", color: "blue" }
        ];

        // Render cards and collect data for row visibility
        cardsData.forEach(cardInfo => {
            if (cardInfo.data && cardInfo.data.value) {
                renderListCard(cardInfo.id, {
                    title: cardInfo.title,
                    leftColumnLabel: cardInfo.left,
                    rightColumnLabel: cardInfo.right,
                    data: cardInfo.data.value.map(item => ({
                                    label: item.name || "Unknown",
                                    value: item.count,
                                    percentage: item.percentage,
                        icon: getIconForItem(cardInfo.title, item.name)
                    }))
                }, cardInfo.color);
            }
        });

        // Render charts
        if (data.visits_over_time) renderVisitsOverTimeChart(data.visits_over_time);
        if (data.countries) renderVisitorMapChart(data.countries);
        renderSessionDistributionChart(data.session_lengths);
        
                            const utmData = {
                                utm_source: data.utms_source,
                                utm_medium: data.utm_medium,
                                utm_campaign: data.utm_campaign,
                                utm_content: data.utm_content,
                                utm_term: data.utm_term
                            };
                            renderUtmCard(utmData);

        // Manage row visibility based on data availability
        const $grids = $('.analytics-grid');
        
        // Row 1: Stats Overview (4 stat cards) - First grid
        
        manageRowVisibility($grids.eq(0), [
            { data: data.dashboard_data?.value?.[0]?.visitors || 0, type: 'stat' },
            { data: data.dashboard_data?.value?.[0]?.sessions || 0, type: 'stat' },
            { data: data.total_pageviews || 0, type: 'stat' },
            { data: data.bounce_rate || 0, type: 'stat' }
        ]);

        // Row 2: Visits Over Time and Pages row - Second grid
        
        manageRowVisibility($grids.eq(1), [
            { data: data.visits_over_time, type: 'chart' },
            { data: data.paths, type: 'list' }
        ]);

        // Row 3: Visitor Locations, OS, and Devices row - Third grid
        
        manageRowVisibility($grids.eq(2), [
            { data: data.countries, type: 'map' },
            { data: data.operating_systems, type: 'list' },
            { data: data.device_types, type: 'list' }
        ]);

        // Row 4: Browsers, Countries, Screen Resolutions, Browser Languages row - Fourth grid
        
        manageRowVisibility($grids.eq(3), [
            { data: data.browser_names, type: 'list' },
            { data: data.countries, type: 'list' },
            { data: data.screen_resolutions, type: 'list' },
            { data: data.browser_languages, type: 'list' }
        ]);

        // Row 5: Referrers, UTM, Session Distribution row - Fifth grid
        
        manageRowVisibility($grids.eq(4), [
            { data: data.referrers, type: 'list' },
            { data: utmData, type: 'utm' },
            { data: data.session_lengths, type: 'chart' }
        ]);

        // Hide loading and show content
                $('#analytics-dashboard-loading').hide();
                $('#analytics-dashboard-content').show();
        
    }

    // Initial setup
    fetchAnalytics();
});