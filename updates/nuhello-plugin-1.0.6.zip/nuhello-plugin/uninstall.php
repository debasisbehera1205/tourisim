<?php
/**
 * Plugin uninstall cleanup.
 *
 * @package Nuhello_Plugin
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

$option_keys = [
    'nuhello_onboarding_completed',
    'nuhello_environment',
    'nuhello_testing_url',
    'nuhello_production_url',
    'nuhello_testing_default',
    'nuhello_production_default',
    'nuhello_display_chatbot',
    'nuhello_show_all_pages',
    'nuhello_enable_analytics',
    'nuhello_enable_notifications',
    'nuhello_email_validation_allowed_statuses',
    'nuhello_email_validation_allowed_safe_to_send',
    'nuhello_email_validation_blocked_types',
    'nuhello_email_validation_error_message',
    'nuhello_enable_email_validation',
    'nuhello_registration_key',
    'nuhello_registration_email',
    'nuhello_registration_timestamp',
    'nuhello_auth_token',
    'nuhello_user',
    'nuhello_otp_verified_time',
    'nuhello_website_details',
    'nuhello_current_website_url',
    'nuhello_chatbot_settings',
    'nuhello_campaign_details',
    'nuhello_test_environment',
    'nuhello_pixel_key',
];

foreach ($option_keys as $option_key) {
    delete_option($option_key);
}

delete_transient('nuhello_github_release');
